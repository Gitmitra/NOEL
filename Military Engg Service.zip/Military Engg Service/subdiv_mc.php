 <div id="container-content">
		    <h1>Maintenance Cell </h1>
			<hr/>
	  
	   <table width="676" border="0" align="center">
  <tr>
    <th colspan="2" valign="bottom" style="color:#0000CC" scope="row"><div align="left">Date:<strong>&nbsp;&nbsp;<?php echo date("d-M-Y");?></strong></div></th> <form name="form1" action="./subdiv.php" method="get" >
    <th colspan="7" valign="bottom" scope="row"><div align="left"><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Summary</strong>&nbsp;&nbsp; <strong>From</strong>
      <input name="sumryfm" type="text" size="10" maxlength="10" readonly="1"/>
      <input name="Submit" type="button" onclick="if(self.gfPop)gfPop.fPopCalendar(document.form1.sumryfm); return false;" value="..."/>	  
      &nbsp;<strong>To</strong>
      <input name="sumryto" type="text" size="10" maxlength="10" readonly="1"/>
      <input name="Submit2" type="button" onclick="if(self.gfPop)gfPop.fPopCalendar(document.form1.sumryto); return false;" value="..."/>
      &nbsp;&nbsp;&nbsp;
      <input type="submit" name="Summary" value="Submit" />
      &nbsp;&nbsp;&nbsp;
      <input type="submit" name="Summary" value="Preview" />	  
    </div></th>
    
    </form>
  </tr>
   <iframe width=174 height=189 name="gToday:normal:agenda.js" id="gToday:normal:agenda.js" src="/mes/scripts/ipopeng.htm" scrolling="no" frameborder="0" style="visibility:visible; z-index:999; position:absolute; top:-500px; left:-500px;"></iframe>
  <tr>
    <th colspan="9" scope="row">&nbsp;</th>
    </tr>
  <tr>
    <th width="33" valign="top" style="color:#0000CC" scope="row">&nbsp;</th>
    <th width="70" valign="top" bgcolor="#CCCCCC" style="color:#0000CC" scope="row">&nbsp;</th>
    <th valign="top" bgcolor="#E6E6E6" scope="row" style="color:#0000CC"><div align="center">Complaints Lodged </div></th>
    <td width="88" bgcolor="#CCCCCC" style="color:#0000CC"><div align="center"><strong>Work Done </strong></div></td>
    <td width="88" bgcolor="#E6E6E6" style="color:#0000CC"><div align="center"><strong>Contractor Work</strong></div></td>
    <td width="93" bgcolor="#CCCCCC" style="color:#0000CC"><div align="center"><strong>Wrong Complaints </strong></div></td>
    <td width="68" bgcolor="#E6E6E6" style="color:#0000CC"><div align="center"><strong>Store N/A </strong></div></td>
    <td width="94" bgcolor="#CCCCCC" style="color:#0000CC"><div align="center"><strong>Complaints Pending </strong></div></td>
    <td width="25" >&nbsp;</td>
  </tr>
  <tr>
    <th valign="top" style="color:#FF0000" scope="row">&nbsp;</th>
    <th valign="top" bgcolor="#CCCCCC" style="color:#FF0000" scope="row">BR</th>
    <th valign="top" bgcolor="#E6E6E6" scope="row" style="color:#FF0000"><div align="center"><?php echo $resrem[0][0]+$resrem[1][0]+$resrem[2][0]+$resrem[3][0]+$resrem[4][0]+$resrem[5][0]+$resrem[6][0]; ?></div></th>
    <td bgcolor="#CCCCCC" style="color:#FF0000"><div align="center"><strong><?php echo $resrem[0][0]+0; ?></strong></div></td>
    <td bgcolor="#E6E6E6" style="color:#FF0000"><div align="center"><strong><?php echo $resrem[1][0]+0; ?></strong></div></td>
    <td bgcolor="#CCCCCC" style="color:#FF0000"><div align="center"><strong><?php echo $resrem[2][0]+0; ?></strong></div></td>
    <td bgcolor="#E6E6E6" style="color:#FF0000"><div align="center"><strong><?php echo $resrem[3][0]+0; ?></strong></div></td>
    <td bgcolor="#CCCCCC" style="color:#FF0000"><div align="center"><strong><?php echo $resrem[4][0]+$resrem[5][0]+$resrem[6][0]; ?></strong></div></td>
    <td >&nbsp;</td>
  </tr>
  <tr>
    <th valign="top" style="color:#FF0000" scope="row">&nbsp;</th>
    <th valign="top" bgcolor="#CCCCCC" style="color:#FF0000" scope="row">EM</th>
    <th valign="top" bgcolor="#E6E6E6" scope="row" style="color:#FF0000"><?php echo $resrem[7][0]+$resrem[8][0]+$resrem[9][0]+$resrem[10][0]+$resrem[11][0]+$resrem[12][0]+$resrem[13][0]; ?></th>
    <td bgcolor="#CCCCCC" style="color:#FF0000"><div align="center"><strong><?php echo $resrem[7][0]+0; ?></strong></div></td>
    <td bgcolor="#E6E6E6" style="color:#FF0000"><div align="center"><strong><?php echo $resrem[8][0]+0; ?></strong></div></td>
    <td bgcolor="#CCCCCC" style="color:#FF0000"><div align="center"><strong><?php echo $resrem[9][0]+0; ?></strong></div></td>
    <td bgcolor="#E6E6E6" style="color:#FF0000"><div align="center"><strong><?php echo $resrem[10][0]+0; ?></strong></div></td>
    <td bgcolor="#CCCCCC" style="color:#FF0000"><div align="center"><strong><?php echo $resrem[11][0]+$resrem[12][0]+$resrem[13][0]; ?></strong></div></td>
    <td >&nbsp;</td>
  </tr>
 
  <tr>
    <th height="24" colspan="2" valign="middle" scope="row">&nbsp;</th>
    <th valign="top" scope="row">&nbsp;</th>
    <td colspan="2">&nbsp;</td>
    <td colspan="4" align="left" valign="middle" ></td>
  </tr>
  <tr>
    <th height="24" colspan="2" valign="middle" scope="row">&nbsp;</th>
	<form name="form2" action="./rem_mc.php" method="get" >
    <th colspan="7" valign="top" scope="row">Feedback from users &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>From</strong>
      <input name="fdbkfm" type="text" size="10" maxlength="10" readonly="1"/>
      <input name="Submit" type="button" onclick="if(self.gfPop)gfPop.fPopCalendar(document.form2.fdbkfm); return false;" value="..."/>	  
      &nbsp;<strong>To</strong>
      <input name="fdbkto" type="text" size="10" maxlength="10" readonly="1"/>
      <input name="Submit2" type="button" onclick="if(self.gfPop)gfPop.fPopCalendar(document.form2.fdbkto); return false;" value="..."/>
      &nbsp;&nbsp;&nbsp;
      <input type="submit" name="feedbk" value="Submit" /></th>
	  </form>
    </tr>
  <tr>
    <th height="24" colspan="2" valign="middle" scope="row">&nbsp;</th>
    <th width="79" valign="top" scope="row">&nbsp;</th>
    <td colspan="2">&nbsp;</td>
    <td colspan="4" align="left" valign="middle" ></td>
  </tr>
  <tr>
    <th height="24" colspan="2" valign="middle" scope="row"><a href="logout.php"><img src="images/logout_btn.jpg" alt="" width="58" height="19" border="0" /></a></th>
    <th valign="top" scope="row">&nbsp;</th>
    <td colspan="2"><a href="passwd.php"><img src="images/passwd.gif" width="137" height="20" border="0" /></a></td>
   
	<td colspan="4" align="left" valign="middle" ></td></tr>
</table>
      	 <hr/> 
  </div> <!-- END of container-content -->
	
