create or replace view mrss as
select l_in.`serno`,rank,rankcode,category,name,trade,unit,l_in.`torsdt` as lin_fm,l_in.`sorsdt` as lin_to,
leav.`sorsdt` as lv_fm,leav.`torsdt` as lv_to,(leav.`torsdt`-leav.`sorsdt`) as lv_tot,
td.`sorsdt` as tdfm,td.torsdt as tdto,
awl.`sorsdt` as awl_fm,awl.torsdt as awl_to,hosp.`sorsdt` as MH_fm,hosp.torsdt as MH_to
from l_in
left outer join leav on (leav.serno = l_in.serno)
left outer join td on (td.serno = l_in.serno)
left outer join awl on (awl.serno = l_in.serno)
left outer join hosp on (hosp.serno = l_in.serno)

