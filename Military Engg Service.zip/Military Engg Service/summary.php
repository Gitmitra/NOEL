<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Summary</title>
</head>
<?php
session_start();
include_once ("dao/function.php");
$host = $_SERVER['HTTP_HOST'];
$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra = 'index.php';
$username =$_SESSION['username'] ;
if(empty($_SESSION['username'])) 
{
session_destroy();
header("Location: http://$host$uri/$extra");
exit();
}
dbconnect();

$query= "Select comtype,comno `com no`,location,fault `Nature of complaint` from complaint where remarks in ('CONTRACTOR JOB','LETTER 2 WKS REQD') and comdt between str_to_date('$_GET[fm]','%d-%m-%Y') and str_to_date('$_GET[to]','%d-%m-%Y') order by comtype,comno";
$wcom= "Select comtype,comno `com no`,location,fault `Nature of complaint` from complaint where remarks = 'WRONG COMPLAINT' and comdt between str_to_date('$_GET[fm]','%d-%m-%Y') and str_to_date('$_GET[to]','%d-%m-%Y') order by comtype,comno";
$sna= "Select comtype,comno `com no`,location,fault `Nature of complaint` from complaint where remarks = 'STORE N/A' and comdt between str_to_date('$_GET[fm]','%d-%m-%Y') and str_to_date('$_GET[to]','%d-%m-%Y') order by comtype,comno";
$pend= "Select comtype,comno `com no`,location,fault `Nature of complaint` from complaint where remarks IN ('PENDING','UNDER PROGRESS','DOOR LOCKED','RAISE SEPARATE COMPLAINT','LOCATION NOT CLEAR','SHO CERTIFICATE REQD','PERIODICAL JOB','CONTACT US') and comdt between str_to_date('$_GET[fm]','%d-%m-%Y') and str_to_date('$_GET[to]','%d-%m-%Y') order by comtype,comno";

  mysql_query("create temporary table if not exists summary SELECT complaint.comtype,complaint.remarks FROM
  complaint where comdt between str_to_date('$_GET[fm]','%d-%m-%Y') and str_to_date('$_GET[to]','%d-%m-%Y') order by remarks");
  $type1 = array('BR','EM');
  $remark = array('DONE','CONTRACTOR JOB','LETTER 2 WKS REQD','WRONG COMPLAINT','STORE N/A','PENDING','UNDER PROGRESS','DOOR LOCKED','RAISE SEPARATE COMPLAINT','LOCATION NOT CLEAR','SHO CERTIFICATE REQD','PERIODICAL JOB','CONTACT US','MINOR WORKS','BSO');
 		foreach($type1 as $value)
 		{
			$comtype = $value;
  			foreach($remark as $value)
    		{
      			$remarks = $value;
	  			$array = compact("comtype","remarks");
	  			$resrem[] = fetch_row(summary,$array);
    		}
 		}
 
	 
	?>
<body>
<a href=subdiv.php><img border="0" onmouseout="this.src='images/btn_back.jpg';" onmouseover="this.src='images/btn_back_02.jpg';" src="images/btn_back.jpg" /></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=summary.pdf>Print</a>	
<?php ob_start();?>
<table width="487" height="497" border="0">
  <tr>
    <th height="28" colspan="8" scope="col"><u>SUMMARY</u></th>
  </tr>
  <tr>
    <th height="49" colspan="2" scope="row">&nbsp;</th>
    <td width="71">&nbsp;</td>
    <td colspan="5">From:-&nbsp; <?php echo $_GET['fm'];?>&nbsp;&nbsp;&nbsp;To:-&nbsp; <?php echo $_GET['to'];?></td>
  </tr>
  <tr>
    <th height="34" colspan="8" scope="row">&nbsp;</th>
  </tr>
  <tr>
    <th height="9" valign="top" scope="row">&nbsp;</th>
    <td height="9" colspan="4">&nbsp;</td>
    <td>BR</td>
    <td height="9">EM</td>
    <td height="9">&nbsp;</td>
  </tr>
  <tr>
    <th width="27" height="9" valign="top" scope="row">1</th>
    <td height="9" colspan="4">Complaints Lodged</td>
    <td width="89">: <?php echo $resrem[0][0]+$resrem[1][0]+$resrem[2][0]+$resrem[3][0]+$resrem[4][0]+$resrem[5][0]+$resrem[6][0]+$resrem[7][0]+$resrem[8][0]+$resrem[9][0]+$resrem[10][0]+$resrem[11][0]+$resrem[12][0]+$resrem[13][0]+$resrem[14][0]; ?></td>
    <td height="9"><?php echo $resrem[15][0]+$resrem[16][0]+$resrem[17][0]+$resrem[18][0]+$resrem[19][0]+$resrem[20][0]+$resrem[21][0]+$resrem[22][0]+$resrem[23][0]+$resrem[24][0]+$resrem[25][0]+$resrem[26][0]+$resrem[27][0]+$resrem[28][0]+$resrem[29][0]; ?></td>
    <td height="9">&nbsp;</td>
  </tr>
  <tr>
    <th height="9" valign="top" scope="row">2</th>
    <td height="9" colspan="4">Work Done</td>
    <td height="9">: <?php echo $resrem[0][0]+0; ?></td>
    <td height="9"><?php echo $resrem[15][0]+0; ?></td>
    <td height="9">&nbsp;</td>
  </tr>
  <tr>
    <th height="9" valign="top" scope="row">3</th>
    <td height="9" colspan="4">Contractor Work</td>
    <td height="9">: <?php echo $resrem[1][0]+$resrem[2][0]+0; ?></td>
    <td height="9"><?php echo $resrem[16][0]+$resrem[17][0]+0; ?></td>
    <td height="9">&nbsp;</td>
  </tr>
  <tr>
    <th height="9" valign="top" scope="row">4</th>
    <td height="9" colspan="4">Wrong Complaints</td>
    <td height="9">: <?php echo $resrem[3][0]+0; ?></td>
    <td height="9"><?php echo $resrem[18][0]+0; ?></td>
    <td height="9">&nbsp;</td>
  </tr>
  <tr>
    <th height="9" valign="top" scope="row">5</th>
    <td height="9" colspan="4">Store Not Available </td>
    <td height="9">: <?php echo $resrem[4][0]+0; ?></td>
    <td height="9"><?php echo $resrem[19][0]+0; ?></td>
    <td height="9">&nbsp;</td>
  </tr>
  <tr>
    <th height="9" valign="top" scope="row">6</th>
    <td height="9" colspan="4">Complaints Pending</td>
    <td height="9">: <?php echo $resrem[5][0]+$resrem[6][0]+$resrem[7][0]+$resrem[8][0]+$resrem[9][0]+$resrem[10][0]+$resrem[11][0]+$resrem[12][0]+0; ?></td>
    <td height="9"><?php echo $resrem[20][0]+$resrem[21][0]+$resrem[22][0]+$resrem[23][0]+$resrem[24][0]+$resrem[25][0]+$resrem[26][0]+$resrem[27][0]+0; ?></td>
    <td height="9">&nbsp;</td>
  </tr>
  <tr>
    <th height="9" valign="top" scope="row">7</th>
    <td height="9" colspan="4">Minor Works </td>
    <td height="9">: <?php echo $resrem[13][0]+0; ?></td>
    <td height="9"><?php echo $resrem[28][0]+0; ?></td>
    <td height="9">&nbsp;</td>
  </tr>
  <tr>
    <th height="9" valign="top" scope="row">8</th>
    <td height="9" colspan="4">BSO's</td>
    <td height="9">: <?php echo $resrem[14][0]+0; ?></td>
    <td height="9"><?php echo $resrem[29][0]+0; ?></td>
    <td height="9">&nbsp;</td>
  </tr>
  <tr>
    <th colspan="8" scope="row"><hr/></th>
  </tr>
  <tr>
    <th height="72" colspan="4" scope="row">&nbsp;</th>
    <th height="72" colspan="2"  scope="row">&nbsp;</th>
    <th height="72"  scope="row">&nbsp;</th>
    <th height="72"  scope="row">&nbsp;</th>
  </tr>
  <tr>
    <th height="10" colspan="4" scope="row">SC Base Wks Sqn    </th>
    <th height="10" colspan="2"  scope="row"><div align="left">AE, Civ</div></th>
    <th height="10"  scope="row"><div align="left">AE, Civ </div></th>
    <th height="10"  scope="row"><div align="left">EE</div></th>
  </tr>
  <tr>
    <th height="10" colspan="4" scope="row">&nbsp;</th>
    <th height="10" colspan="2"  scope="row"><div align="left">AGE(E&amp;M)</div></th>
    <th height="10"  scope="row"><div align="left">AGE(B&amp;R)</div></th>
    <th height="10"  scope="row"><div align="left">GE(AF) Bhuj </div></th>
  </tr>
  <tr>
    <th height="66" colspan="4" scope="row">&nbsp;</th>
    <th height="66" colspan="2"  scope="row">&nbsp;</th>
    <th height="66"  scope="row">&nbsp;</th>
    <th height="66"  scope="row">&nbsp;</th>
  </tr>
  <tr>
    <th height="10" colspan="4" scope="row">&nbsp;</th>
    <th height="10" colspan="2"  scope="row"><div align="left">Wg Cdr </div></th>
    <th height="10"  scope="row"><div align="left"></div></th>
    <th height="10"  scope="row"><div align="left">Gp Capt </div></th>
  </tr>
  <tr>
    <th height="10" colspan="4" scope="row">&nbsp;</th>
    <th height="10" colspan="2"  scope="row"><div align="left">C Adm O </div></th>
    <th width="101" height="10"  scope="row"><div align="left"></div></th>
    <th width="110" height="10"  scope="row"><div align="left">Stn Cdr </div></th>
  </tr>
  <tr>
    <th height="10" colspan="8" scope="row"><hr/></th>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>
<p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>
<p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>
   <?php select_table($query,1,2,"CONTRACTOR JOB"); ?>
   <p>&nbsp;</p>
   <p>&nbsp;</p>
    <?php select_table($wcom,1,2,"WRONG COMPLAINTS"); ?>
	<p>&nbsp;</p>
	<p>&nbsp;</p>
    <?php select_table($sna,1,2,"STORE N/A"); ?>
	<p>&nbsp;</p>
	<p>&nbsp;</p>
	<?php select_table($pend,1,2,"COMPLAINTS PENDING"); ?>
</body>
<?php
		 $data=ob_get_contents();
		 $fp=fopen("summary.html","w");
		 fwrite($fp,$data);
		 fclose($fp);
		 ob_end_flush();
		 //Converting HTML file format into PDF format
		 include_once("dao/html2fpdf.php");
		$pdf=new HTML2FPDF();
		$pdf->AddPage();
		$fp1 = fopen("summary.html","r");
		$strContent = fread($fp1, filesize("summary.html"));
		fclose($fp1);
		$pdf->WriteHTML($strContent);
		$pdf->Output("summary.pdf");
	
dbclose();
?>
</html>