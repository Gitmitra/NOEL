<?php 
include_once ("function.php");
//if (!preg_match("/156.84.1./", $_SERVER['REMOTE_ADDR']) && !preg_match("/155.83./", $_SERVER['REMOTE_ADDR']))
//{message("Access denied to Outstations.....!");
//exit();
//}
?>

<head>
<title>Login</title>
<script type="text/JavaScript" src="scripts/test.js"></script>
<link href="stylesheets/style.css" rel="stylesheet" type="text/css" />
<link href="images/emx_nav_left.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<table width="768" border="0" align="center" cellspacing="1">
  <tr>
    <th colspan="3" scope="col"><p>&nbsp;</p>
      <p align="center"><img src="images/drss.gif" width="504" height="62" align="top"></p>    </th>
  </tr>
  <tr>
    <td width="254" height="104">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><strong class="rollmenu">Login</strong></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="110"></td>
    <td width="290"><form name="frmlogin" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
	 <table width="222" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="12"><img src="../drss/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
          <td colspan="4" background="../drss/images/table_r1_c2.gif"><img src="../drss/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
          <td width="13"><img src="../drss/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
        </tr>
        <tr>
          <td background="../drss/images/table_r2_c1.gif">&nbsp;</td>
          <td width="58" class="success"><strong> Username</strong></td>
          <td width="5">&nbsp;</td>
          <td colspan="2"><select name="txtUnit">
            <option>-- Select --</option>
            <option>27WG</option>
            <option>37SQN</option>
            <option>108SQN</option>
            <option>2201SQN</option>
            <option>2224SQN</option>
		    <option>2254SQN</option>
            <option>171SU</option>
            <option>777SU</option>
            <option>853SU</option>
            <option>478MOF</option>
            <option>308TRU</option>
			<option>342TRU</option>
            <option>607GRDFLT</option>
            </select>          </td>
          <td background="../drss/images/table_r2_c3.gif.">&nbsp;</td>
        </tr>
        <tr>
          <td background="../drss/images/table_r2_c1.gif">&nbsp;</td>
          <td class="success"><strong>Password</strong></td>
          <td>&nbsp;</td>
          <td colspan="2">
		  <input type="password" name="txtPwd" size="18"></td>
		  
          <td background="../drss/images/table_r2_c3.gif.">&nbsp;</td>
        </tr>
        <tr>
          <td background="../drss/images/table_r2_c1.gif"><img src="../drss/images/spacer.gif" alt="" name="table_r2_c1" width="1" height="1" border="0" id="table_r2_c1" /></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td width="65"><input type="hidden" name="action" value="submitted"><img border="0" onClick="login();" onMouseOut="this.src='/drss/images/btn_submit.gif';" onMouseOver="this.src='/drss/images/btn_submit_02.gif';" src="/drss/images/btn_submit.gif" /></td>
          <td width="68"></td>
		  <td background="../drss/images/table_r2_c3.gif."><img src="../drss/images/spacer.gif" alt="" name="table_r2_c3" width="1" height="1" border="0" id="table_r2_c3" /></td>
        </tr>
        
        <tr>
          <td><img src="../drss/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
          <td colspan="4" background="../drss/images/table_r3_c2.gif"><img src="../drss/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
          <td><img src="../drss/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
        </tr>
      </table>
    </form>    </td>
    <td width="214">&nbsp;</td>
  </tr>
  
  <tr>
    <td>&nbsp;</td>
    <td class="rollmenu">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td ><strong>&nbsp;Designed &amp; Developed By: Sgt S Mitra, NET &amp; IT SQN </strong></td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
<?php
if(isset($_POST['action']) && $_POST['action'] == 'submitted')
{
	if(authenticate($_POST['txtUnit'],$_POST['txtPwd']))
	{
		switch($_SESSION['unit']) {
			case "27WG":
				$table1 = "personal_info27";
	 	 	 	$table2 = "movement27";
				break;
			case "37SQN":
				$table1 = "personal_info37";
	 	 	 	$table2 = "movement37";
				break;
			case "108SQN":
				$table1 = "personal_info108";
	 	 	 	$table2 = "movement108";
				break;
			case "2201SQN":
				$table1 = "personal_info2201";
	 	 	 	$table2 = "movement2201";
				break;
			case "2224SQN":
				$table1 = "personal_info2224";
	 	 	 	$table2 = "movement2224";
				break;
			case "2254SQN":
				$table1 = "personal_info2254";
	 	 	 	$table2 = "movement2254";
				break;
			case "171SU":
				$table1 = "personal_info171";
	 	 	 	$table2 = "movement171";
				break;
			case "777SU":
				$table1 = "personal_info777";
	 	 	 	$table2 = "movement777";
				break;
			case "853SU":
				$table1 = "personal_info853";
	 	 	 	$table2 = "movement853";
				break;
			case "478MOF":
				$table1 = "personal_info478";
	 	 	 	$table2 = "movement478";
				break;
			case "308TRU":
				$table1 = "personal_info308";
	 	 	 	$table2 = "movement308";
				break;
			case "342TRU":
				$table1 = "personal_info342";
	 	 	 	$table2 = "movement342";
				break;
			case "607GRDFLT":
				$table1 = "personal_info607";
	 	 	 	$table2 = "movement607";
				break;
			}
		
	mysql_query("delete from ".$table2." where serno in (select serno from discard where (unit = '$_SESSION[unit]') and (curdate() >= date_add(last_day(outdt), interval 5 day))) and p_t_out='Y'");
		
		mysql_query("delete from discard where curdate() >= date_add(last_day(outdt), interval 5 day) and unit = '$_SESSION[unit]'");
		
		header("Refresh: 2; URL=http://localhost/drss/index.php");
	}
}
?>

