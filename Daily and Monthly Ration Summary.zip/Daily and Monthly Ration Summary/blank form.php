
<title>Registration</title>


 <link href="stylesheets/style.css" rel="stylesheet" type="text/css">
   

<body>
<table width="352" border="0" align="center">
  
  <tr>
    <th width="523" align="center" valign="top" scope="col"><p>&nbsp;</p>
    </th>
  </tr>
  <tr class="welcome">
    <th align="center" valign="top" class="rollmenu" scope="col"><div align="left">Enter </div></th>
  </tr>
  <tr>
    <th align="center" valign="top" scope="col">&nbsp;</th>
  </tr>
  <tr>
    <th align="center" valign="top" scope="col"><form name="frmReg" action="<?php echo $_SERVER['PHP_SELF']?>" method="post" >
      <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="12"><img src="../drss/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
          <td background="../drss/images/table_r1_c2.gif"><img src="../drss/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
          <td width="13"><img src="../drss/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
        </tr>
        <tr>
          <td background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        
        <tr>
          <td><img src="../drss/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
          <td background="../drss/images/table_r3_c2.gif"><img src="../drss/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
          <td><img src="../drss/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
        </tr>
      </table>
        </form></th>
  </tr>
   <tr>
    <th align="center" valign="top" scope="col">&nbsp;</th>
  </tr>
  <tr>
    <th align="center" valign="top" scope="col"><p align="center" class="rollmenu">&nbsp;</p>    </th>
  </tr>
</table>
</body>
</html>


