   <div id="container-content">
	
		    <h1>Sub-Division of B & R Complaint</h1>
			<hr/>
	   <form id="form1" method="get" action="./prview.php">
	   <table width="673" border="0" align="center">
  <tr>
    <th width="91" scope="row"><div align="left">Date</div></th>
    <th width="5" scope="row">:</th>
    <td colspan="2"><strong><?php echo date("d-M-Y");?></strong></td>
    <td><strong>Complaints</strong></td>
    <td width="79"><strong> Complaints Pending </strong>      </td>
    <td width="80"><strong>Complaints Under Prg </strong></td>
  </tr>
  <tr>
    <th scope="row"><div align="left">Sub-Division </div></th>
    <th scope="row">:</th>
    <td colspan="2"><select name="subdiv">
	    <option value="PLASTER WORK">PLASTER WORK</option>
        <option value="CARPENTER WORK">CARPENTER WORK</option>
        <option value="WELDING WORK">WELDING WORK</option>
		<option value="PERIODICAL SERVICES">PERIODICAL SERVICES</option>
        <option value="SANITARY/DRAIN/SEWAGE">SANITARY/DRAIN/SEWAGE</option>
        <option value="INTERNAL WATER SUPPLY">INTERNAL WATER SUPPLY</option>
		<option value="MISCELLANEOUS">MISCELLANEOUS</option>
    </select></td>
    <td width="199">PLASTER WORK</td>
    <td style="color:#FF0000"><div align="center"><strong><?php echo $comp[0][0] ?></strong></div></td>
    <td style="color: #339900"><div align="center"><strong><?php echo $comp[7][0]+$comp[14][0] ?></strong></div></td>
  </tr>
  <tr>
    <th valign="top" scope="row">&nbsp;</th>
    <th valign="top" scope="row">&nbsp;</th>
    <td colspan="2">&nbsp;</td>
    <td>CARPENTER WORK</td>
    <td style="color:#FF0000"><div align="center"><strong><?php echo $comp[1][0] ?></strong></div></td>
    <td style="color: #339900"><div align="center"><strong><?php echo $comp[8][0]+$comp[15][0] ?></strong></div></td>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <th scope="row">&nbsp;</th>
    <td colspan="2">&nbsp;</td>
    <td>WELDING WORK</td>
    <td style="color:#FF0000"><div align="center"><strong><?php echo $comp[2][0] ?></strong></div></td>
    <td style="color: #339900"><div align="center"><strong><?php echo $comp[9][0]+$comp[16][0] ?></strong></div></td>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <th scope="row">&nbsp;</th>
    <td colspan="2"><a href="passwd.php"><img src="images/passwd.gif" width="137" height="20" border="0" /></a></td>
    <td>PERIODICAL SERVICES </td>
    <td style="color:#FF0000"><div align="center"><strong><?php echo $comp[3][0] ?></strong></div></td>
    <td style="color: #339900"><div align="center"><strong><?php echo $comp[10][0]+$comp[17][0] ?></strong></div></td>
  </tr>
  <tr>
    <th colspan="3" scope="row">&nbsp;</th>
    <td>&nbsp;</td>
    <td>SANITARY/DRAIN/SEWAGE</td>
    <td style="color:#FF0000"><div align="center"><strong><?php echo $comp[4][0] ?></strong></div></td>
    <td style="color: #339900"><div align="center"><strong><?php echo $comp[11][0]+$comp[18][0] ?></strong></div></td>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <th scope="row">&nbsp;</th>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>INTERNAL WATER SUPPLY</td>
    <td style="color:#FF0000"><div align="center"><strong><?php echo $comp[5][0] ?></strong></div></td>
    <td style="color: #339900"><div align="center"><strong><?php echo $comp[12][0]+$comp[19][0] ?></strong></div></td>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <th scope="row">&nbsp;</th>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>MISCELLANEOUS</td>
    <td style="color:#FF0000"><div align="center"><strong><?php echo $comp[6][0] ?></strong></div></td>
    <td style="color: #339900"><div align="center"><strong><?php echo $comp[13][0]+$comp[20][0] ?></strong></div></td>
  </tr>
  <tr>
    <th scope="row"><a href="logout.php"><img src="images/logout_btn.jpg" alt="" width="58" height="19" border="0" /></a></th>
    <th scope="row">&nbsp;</th>
    <td width="94">
      <input type="submit" name="Submit" value="Print Preview" />    </td>
    <td width="95"><input type="submit" name="Remarks" value="Block Remarks" /></td>
    <td colspan="3">
      <input name="complaint" type="submit" id="complaint" value="Remarks By Complaint No" />   </td>
    </tr>
</table>
       </form>
	 <hr/> 
  </div> <!-- END of container-content -->
	
