"""FailureReportingSystem URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from registration import views


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.user_login, name="userlogin"),
    path('faultregistration/<username>', views.failure_report, name="faultregistration"),
    path('logout/', views.user_logout, name="userlogout"),
    path('changepass/', views.user_change_pass, name="changepass"),
    path('uadmin/', views.admin_login, name="useradmin"),
    path('register/',views.registration, name="register"),
    path("savefault/<str:username>/",views.add_newfault, name="savefault"),
    path("iaidetails/<str:username>/",views.add_iaidocket, name="iaidetails"),
    path("repairdetails/<str:username>/",views.add_repair, name="repairdetails"),
    path("saverecvdcatd/<str:username>/",views.recv_catD, name="saverecvdcatd"),
    path("savecatD/<str:username>/",views.add_catD, name="savecatD"),
    path('savespares/<str:username>/',views.add_spare, name="savespares"),
    path('home/', views.home, name="home"),
    path('update/<str:username>/',views.update_user, name="updateuser"),
    path('delete/<int:username>/',views.delete_user, name="deleteuser"),
    path('catd/', views.CatDView.as_view(), name="catd"),
    path('pdf/', views.GeneratePdf, name="generatepdf"),
    path('selectFRpdf/<str:username>/', views.selectFR_pdf, name="selectFRpdf"),
    path('frdetails/', views.fr_details, name="frdetails"),
    path('catddetails/', views.catD_details, name="catddetails"),
    path('sparedetails/', views.spare_details, name="sparedetails"),
    path('faultcompendium/', views.fault_compendium, name="faultcompendium"),
    path('openfrs/<str:username>/', views.open_FRs, name="openfrs"),
    path('openfrcmd/', views.openFRs_cmd, name="openfrcmd"),
]
