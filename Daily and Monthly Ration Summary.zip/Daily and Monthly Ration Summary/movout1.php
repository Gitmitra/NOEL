<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>27WG:: Movement In</title>

<link href="stylesheets/style.css" rel="stylesheet" type="text/css">
<?php 
session_start();
include_once ("index.php");
include_once ("function.php");
dbconnect();
		switch($_SESSION['unit']) {
			case "27WG":
				$table1 = "personal_info27";
	 	 	 	$table2 = "movement27";
				break;
			case "37SQN":
				$table1 = "personal_info37";
	 	 	 	$table2 = "movement37";
				break;
			case "108SQN":
				$table1 = "personal_info108";
	 	 	 	$table2 = "movement108";
				break;
			case "2201SQN":
				$table1 = "personal_info2201";
	 	 	 	$table2 = "movement2201";
				break;
			case "2224SQN":
				$table1 = "personal_info2224";
	 	 	 	$table2 = "movement2224";
				break;
			case "2254SQN":
				$table1 = "personal_info2254";
	 	 	 	$table2 = "movement2254";
				break;
			case "171SU":
				$table1 = "personal_info171";
	 	 	 	$table2 = "movement171";
				break;
			case "777SU":
				$table1 = "personal_info777";
	 	 	 	$table2 = "movement777";
				break;
			case "853SU":
				$table1 = "personal_info853";
	 	 	 	$table2 = "movement853";
				break;
			case "478MOF":
				$table1 = "personal_info478";
	 	 	 	$table2 = "movement478";
				break;
			case "308TRU":
				$table1 = "personal_info308";
	 	 	 	$table2 = "movement308";
				break;
			case "342TRU":
				$table1 = "personal_info342";
	 	 	 	$table2 = "movement342";
				break;
			case "607GRDFLT":
				$table1 = "personal_info607";
	 	 	 	$table2 = "movement607";
				break;
			}
		 
if(isset($_POST['moveout']) && $_POST['moveout'] == 'submitted')
{
 	$serno = $_POST['serno'];
	$movcode = $_POST['movcode'];
	$sorsdt = $_POST['sorsdt'];
	$movout	= 'Y';	
	$p_t_out = 'Y';
	$outdt=$_POST['outdt'];
	
		if ($_POST['movcode'] == 'CTD')
		{
			$array=compact("serno","sorsdt","p_t_out","outdt");
			if (update_row($table2,$array,"sorsdt is null and serno=$serno"))
			{	message("inf.png","SORS is taken for $serno...!!"); 
				mysql_query("update ".$table1." set movcode = 'CTD',type = 'CTD',p_out_dt='$sorsdt',outdt='$outdt' where serno = $serno");
				mysql_query("update ".$table2." set movin = null,movout = null,outdt = null,p_t_out = 'Y' where serno = $serno");
				mysql_query("insert into discard select * from ".$table1." where serno = $serno");
				mysql_query("delete from ".$table1." where serno = $serno");
			}
		}
		else
		{ 
			$array=compact("serno","movcode","sorsdt","movout","outdt");
			if (insert_row($table2,$array))
			{
				message("inf.png","SORS is taken for $serno...!!"); 
		 		mysql_query("update ".$table1." set movcode = '$movcode' where serno = $serno");
			} 
		}		
} 

if(isset($_POST['lout']) && $_POST['lout'] == 'submitted') 
{
	$serno = $_POST['serno'];
	$movcode = $_POST['status'];
	$torsdt = $_POST['ldt'];
	$movin = 'Y';
	$indt = $_POST['outdt'];
		
	$array=compact("serno","movcode","torsdt","movin","indt");
	if (insert_row($table2,$array))
		{
		   message("inf.png","$serno is permitted to Live Out...!!");
		}
	mysql_query("update ".$table2." set sorsdt = '$torsdt',movin = null,movout=null,outdt='$indt' where sorsdt is null and serno = $serno and movcode = 'L_IN'");
	mysql_query("update ".$table1." set status = '$movcode' where serno = $serno"); 
}

if(isset($_POST['postedout']) && $_POST['postedout'] == 'submitted') 
{
	$serno = $_POST['serno'];
	$type = $_POST['type'];
	$movcode = $_POST['type'];
	$p_out_dt = $_POST['p_out_dt'];
	$outdt = $_POST['outdt'];
	
	$array=compact("serno","type","movcode","p_out_dt","outdt");
		if (update_row($table1,$array,"serno=$serno and type = 'POSTED_IN'"))
		{
			message("inf.png","$serno is $movcode...!!");
			mysql_query("update ".$table2." set p_t_out='Y' where serno = $serno");
			mysql_query("insert into discard select * from ".$table1." where serno = $serno");
			mysql_query("delete from ".$table1." where serno = $serno");
		}
}

if(isset($_POST['onleave']) && $_POST['onleave'] == 'submitted')
{
	$serno = $_POST['serno'];
	$movcode = $_POST['movcode'];
	$sorsdt = $_POST['sorsdt'];
	$torsdt = $_POST['torsdt']; 
	$movout = 'Y';
	$outdt=$_POST['outdt'];

	$array=compact("serno","movcode","sorsdt","torsdt","movout","outdt");
	if (insert_row($table2,$array))
	{
		message("inf.png","SORS is taken for $serno...!!"); 
		mysql_query("update ".$table1." set movcode = '$movcode' where serno = $serno");
	} 
}

if(isset($_POST['mail']) && $_POST['mail'] == 'Send')
{
	function LoadUploadedFile($fileattname) 
	{
    	move_uploaded_file($_FILES["uploaded_file"]["tmp_name"], "uploads/" . $fileattname);
    	return true;
	}

	function GetUploadedFileInfo() 
	{ 
   		$file_info[] = basename($_FILES['uploaded_file']['name']);
   		$file_info[] = substr($file_info[0], strrpos($file_info[0], '.') + 1);
   		$file_info[] = $_FILES["uploaded_file"]["size"]/1024;
   		return $file_info;
	}

	function Validate($name_of_uploaded_file, $type_of_uploaded_file, $size_of_uploaded_file, $max_allowed_file_size, 	$allowed_extension) 
	{
   		$type_of_uploaded_file = strtoupper($type_of_uploaded_file);
   		if($size_of_uploaded_file>$max_allowed_file_size ) 
		{
      		message("err.png","Size of file is greater than" . $max_allowed_file_size . " KB.");
       		return false;
   		}
   		
   		if(!(in_array($type_of_uploaded_file,$allowed_extension))) 
   		{  message("err.png","You have uploaded a file with an extension of " . $type_of_uploaded_file . " . This type is not 	allowed. Please upload file with htm or html or pdf or txt extensions");    
   		return false; } 

	return true; 
	}

list($name_of_uploaded_file, $type_of_uploaded_file, $size_of_uploaded_file) = GetUploadedFileInfo(); 

$max_allowed_file_size = "300"; // this is size in KB 
$allowed_extension = array("HTM", "HTML", "PDF", "TXT");

if(!Validate($name_of_uploaded_file, $type_of_uploaded_file, $size_of_uploaded_file, $max_allowed_file_size, $allowed_extension)) 
{ 
   exit();
}

//Declare the necessary variables
$mail_to=$_POST['txtto'];
$mail_from=$_POST['txtfrom'];
$mail_sub=$_POST['txtsub'];

$fileattname= basename($_FILES['uploaded_file']['name']);
LoadUploadedFile($fileattname);
$fileatt = "uploads/" . $fileattname;

$headers .= "From: $mail_from\n";
$file = fopen($fileatt, 'rb');
$data = fread($file,filesize($fileatt));
fclose($file);

$semi_rand = md5( time() );
$mime_boundary = "==Multipart_Boundary_X{$semi_rand}X";
$headers .= "\nMIME-Version: 1.0\n".
			"Content-Type: multipart/mixed;\n" .
			"boundary=\"{$mime_boundary}\"";
$mail_mesg = "--{$mime_boundary}\n".
			"Content-Type: text/plain; charset=\"iso-8859-1\"\n" . 
           	"Content-Transfer-Encoding: 7bit\n\n" . 
            $_POST['txtmsg'] . "\n\n";

$data = chunk_split(base64_encode( $data ));
$mail_mesg .="--{$mime_boundary}\n" .			
			"Content-Type: text/html;\n" . 
			 "name =\"{$fileattname}\"\n" .
			 "Content-Disposition: attachment;\n".
			 "filename=\"$fileattname\"\n".
			 "Content-Transfer-Encoding: base64\n\n" . 
			 $data . "\n\n".
			"--{$mime_boundary}\n";

//Check for success/failure of delivery 
 if(mail($mail_to,$mail_sub,$mail_mesg,$headers))
{message("inf.png","e-mail has been sent successfully to $mail_to");}
else
{message("err.png","Failed to send the mail to $mail_to");}
}

if($_REQUEST['movdel'] == 'deleted')
{		
	switch($_POST['movcode'])
	{
		case "TD":
		case "LEAVE":
		case "HOSP":
				mysql_query("delete from ".$table2." where movid = $_REQUEST[movid]");
				if($_REQUEST['type'] == 'POSTED_IN')
				{mysql_query("update ".$table1." set movcode = null where serno = $_REQUEST[serno]");}
				else
				{mysql_query("update ".$table1." set movcode = 'ATTACHMENT' where serno = $_REQUEST[serno]");}
				break;	
		case "AWL":
				$resultawl=mysql_query("select serno,movid from ".$table2." where movcode = 'LEAVE' and serno = $_POST[serno] and torsdt = (select sorsdt from ".$table2." where movid = $_REQUEST[movid])") or die(mysql_error());
				$rowawl = mysql_fetch_array($resultawl);
				$numrows = mysql_num_rows($resultawl);
				if($numrows == 1)
				{
					mysql_query("update ".$table1." set movcode = 'LEAVE' where serno = $_POST[serno]");
					mysql_query("update ".$table2." set movin = null,movout = 'Y'  where movid = $rowawl[movid]");
					mysql_query("delete from ".$table2." where movid = $_REQUEST[movid]");
				}
				else
				{	mysql_query("delete from ".$table2." where movid = $_REQUEST[movid]");
					if($_REQUEST['type'] == 'POSTED_IN')
					{mysql_query("update ".$table1." set movcode = null where serno = $_REQUEST[serno]");}
					else
					{mysql_query("update ".$table1." set movcode = 'ATTACHMENT' where serno = $_REQUEST[serno]");}
				}
				break;	
					
		case "L_IN":
				mysql_query("delete from ".$table2." where movid = $_REQUEST[movid]");
				mysql_query("update ".$table1." set status = 'L_OUT' where serno = $_POST[serno]");
				mysql_query("update ".$table2." set sorsdt = null,outdt = null where serno = $_POST[serno] and movcode = 'L_OUT'");
				break;
		case "L_OUT":
				mysql_query("delete from ".$table2." where movid = $_REQUEST[movid]");
				mysql_query("update ".$table1." set status = 'L_IN' where serno = $_POST[serno]");
				mysql_query("update ".$table2." set sorsdt = null,outdt = null where serno = $_POST[serno] and movcode = 'L_IN'");
				break;
		
	}		
		message("inf.png","Movement of ".$_REQUEST['serno']." is deleted...!!");
}

if($_REQUEST['del'] == 'deleted')
{
	$serno = $_REQUEST['serno'];
	if(delete_row($table1,"serno=$serno"))
	if(delete_row($table2,"serno=$serno"))
	{message("inf.png","Record of ".$_REQUEST['serno']." is deleted successfully...!");}
}

dbclose();
header("Refresh: 2; URL=http://localhost/drss/index.php"); /* Redirect browser */

?>