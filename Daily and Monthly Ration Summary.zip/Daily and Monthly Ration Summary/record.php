<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
<title>27WG:: Movement In</title>
<link href="stylesheets/style.css" rel="stylesheet" type="text/css">

<?php 
include_once("index.php");
include_once("function.php");

session_start();
dbconnect();

$type1 = array('POSTED_IN','TD');
$movcode1 = array('ATTACHMENT','LEAVE','TD','HOSP','AWL');

$unit = $_SESSION['unit'];
		switch($unit) {
			case "27WG":
				$table1 = "personal_info27";
	 	 	 	break;
			case "37SQN":
				$table1 = "personal_info37";
	 	 	 	break;
			case "108SQN":
				$table1 = "personal_info108";
	 	 	 	break;
			case "2201SQN":
				$table1 = "personal_info2201";
	 	 	 	break;
			case "2224SQN":
				$table1 = "personal_info2224";
	 	 	 	break;
			case "2254SQN":
				$table1 = "personal_info2254";
	 	 	 	break;
			case "171SU":
				$table1 = "personal_info171";
	 	 	 	break;
			case "777SU":
				$table1 = "personal_info777";
	 	 	 	break;
			case "853SU":
				$table1 = "personal_info853";
	 	 	 	break;
			case "478MOF":
				$table1 = "personal_info478";
	 	 	 	break;
			case "308TRU":
				$table1 = "personal_info308";
	 	 	 	break;
			case "342TRU":
				$table1 = "personal_info342";
	 	 	 	break;
			case "607GRDFLT":
				$table1 = "personal_info607";
	 	 	 	break;
			}
		
foreach($type1 as $value)
{	
	$type = $value;
	$array = compact("unit","type");
	$str[]= record($table1,$array);
}

foreach($movcode1 as $value)
{
	$movcode = $value;
	$array = compact("unit","movcode");
	$rec[]= record($table1,$array);
}



$result=mysql_query("select count(*) from ".$table1." where movcode is null and unit = '$_SESSION[unit]' and category in ('AIRMEN','SNCOs')");
$rec1 = mysql_fetch_row($result);

dbclose();
?>
<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	left:1px;
	top:156px;
	width:422px;
	height:45px;
	padding: 0px;
	margin: 0px;
}
#Layer2 {
	position:absolute;
	left:49px;
	top:265px;
	width:888px;
	height:104px;
	z-index:1;
}
.style1 {
	color: #0000CC;
	font-weight: bold;
}
-->
</style>
<body>
<div id="Layer1">
<table width="423" border="0" align="center">
  <tr>
    <td width="417">&nbsp;</td>
  </tr>
  <tr>
    <td><table width="81%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="12"><img src="../drss/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
          <td colspan="7" background="../drss/images/table_r1_c2.gif"><img src="../drss/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
          <td width="13"><img src="../drss/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
        </tr>
        <tr>
          <td height="25" background="../drss/images/table_r2_c1.gif"></td>
          <td width="43"><div align="center"><strong>P/STR</strong></div></td>
          <td width="42"><div align="center"><strong>ATT</strong></div></td>
          <td width="55"><div align="center"><strong>PRESENT</strong></div></td>
          <td width="46"><div align="center"><strong>LEAVE</strong></div></td>
          <td width="42"><div align="center"><strong>TD</strong></div></td>
          <td width="42"><div align="center"><strong>HOSP</strong></div></td>
          <td width="42"><div align="center"><strong>AWL</strong></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td background="../drss/images/table_r2_c1.gif"></td>
          <td><div align="center"><?php echo $str[0][0];?></div></td>
          <td><div align="center"><?php echo $str[1][0];?></div></td>
          <td><div align="center"><?php echo $rec1[0] + $rec[0][0];?></div></td>
          <td><div align="center"><?php echo $rec[1][0];?></div></td>
          <td><div align="center"><?php echo $rec[2][0];?></div></td>
          <td><div align="center"><?php echo $rec[3][0];?></div></td>
          <td><div align="center"><?php echo $rec[4][0];?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        
        <tr>
          <td><img src="../drss/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
          <td colspan="7" background="../drss/images/table_r3_c2.gif"><img src="../drss/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
          <td><img src="../drss/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
        </tr>
</table></td>
  </tr>
</table>
</div>
<?php 
dbclose();
?>
<div id="Layer2">
  <table width="877" border="0">
    <tr>
      <td height="33" colspan="4" nowrap="nowrap"><span class="body"><strong><u>Bar Chart Format</u></strong></span> </td>
    </tr>
    <tr>
      <td width="62" nowrap="nowrap"><span class="style1">Total Str </span></td>
      <td width="28" nowrap="nowrap"><?php echo $str[0][0]+$str[1][0]; ?></td>
      <td width="20" nowrap="nowrap"><?php echo '100%' ?></td>
      <td width="749" nowrap="nowrap">
	  <?php 
	  for($i=0;$i<($str[0][0]+$str[1][0]);$i++)
	  {
	  echo "<img src=../drss/images/bar2.gif />"; 
	  }
	  ?></td>
    </tr>
    <tr>
      <td><span class="style1">Present</span></td>
      <td><?php echo $rec1[0] + $rec[0][0];?></td>
      <td><?php echo round((($rec1[0] + $rec[0][0])*100/($str[0][0]+$str[1][0])),2)."%" ?></td>
      <td nowrap="nowrap"> <?php 
	  for($i=0;$i<($rec1[0] + $rec[0][0]);$i++)
	  {
	  echo "<img src=../drss/images/bar2.gif />"; 
	  }
	  ?></td>
    </tr>
    <tr>
      <td><span class="style1">Leave</span></td>
      <td><?php echo $rec[1][0]; ?></td>
      <td><?php echo round((($rec[1][0])*100/($str[0][0]+$str[1][0])),2)."%" ?></td>
      <td nowrap="nowrap"><?php 
	  for($i=0;$i<$rec[1][0];$i++)
	  {
	   echo "<img src=../drss/images/bar2.gif />"; 
	  }
	  ?></td>
    </tr>
    <tr>
      <td><span class="style1">TD</span></td>
      <td><?php echo $rec[2][0]; ?></td>
      <td><?php echo round((($rec[2][0])*100/($str[0][0]+$str[1][0])),2)."%" ?></td>
      <td nowrap="nowrap"><?php 
	  for($i=0;$i<$rec[2][0];$i++)
	  {
		echo "<img src=../drss/images/bar2.gif />"; 
	  }
	  ?></td>
    </tr>
    <tr>
      <td><span class="style1">Hospital</span></td>
      <td><?php echo $rec[3][0]; ?></td>
      <td><?php echo round((($rec[3][0])*100/($str[0][0]+$str[1][0])),2)."%" ?></td>
      <td nowrap="nowrap"><?php 
	  for($i=0;$i<$rec[3][0];$i++)
	  {
	   echo "<img src=../drss/images/bar2.gif />"; 
	  }
	  ?></td>
    </tr>
    <tr>
      <td><span class="style1">AWL</span></td>
      <td><?php echo $rec[4][0]; ?></td>
      <td><?php echo round((($rec[4][0])*100/($str[0][0]+$str[1][0])),2)."%" ?></td>
      <td nowrap="nowrap"><?php 
	  for($i=0;$i<$rec[4][0];$i++)
	  {
	  echo "<img src=../drss/images/bar2.gif />"; 
	  }
	  ?></td>
    </tr>
  </table>
</div>
