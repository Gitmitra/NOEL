<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Rank Matrix Nominal Roll</title>
</head>
<?php 
session_start();
if(empty($_SESSION['unit'])) 
{
	$host = $_SERVER['HTTP_HOST'];
	$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
	$extra = 'login.php';
	session_destroy();
	header("Location: http://$host$uri/$extra");
	exit();
}

include_once ("function.php");
dbconnect();
$unit = $_SESSION['unit'];
	switch($unit) {
			case "27WG":
				mysql_query("call matrix27()");
	 	 	 	break;
			case "37SQN":
				mysql_query("call matrix37()");
	 	 	 	break;
			case "108SQN":
				mysql_query("call matrix108()");
	 	 	 	break;
			case "2201SQN":
				mysql_query("call matrix2201()");
	 	 	 	break;
			case "2224SQN":
				mysql_query("call matrix2224()");
	 	 	 	break;
			case "2254SQN":
				mysql_query("call matrix2254()");
	 	 	 	break;
			case "171SU":
				mysql_query("call matrix171()");
	 	 	 	break;
			case "777SU":
				mysql_query("call matrix777()");
	 	 	 	break;
			case "853SU":
				mysql_query("call matrix853()");
	 	 	 	break;
			case "478MOF":
				mysql_query("call matrix478()");
	 	 	 	break;
			case "308TRU":
				mysql_query("call matrix308()");
	 	 	 	break;
			case "342TRU":
				mysql_query("call matrix342()");
				break;
			case "607GRDFLT":
				mysql_query("call matrix607()");
	 	 	 	break;
			}


$rank="select trade,ac,lac,cpl,sgt,jwo,wo,mwo,(ac+lac+cpl+sgt+jwo+wo+mwo) TOTAL from matrix";
ob_start();		 
?>
<body>
<table width="613" border="0">
  <tr>
    <td colspan="9"><div align="center" class="style1">
      <h2>RANK MATRIX  <?php echo date("d-M-Y"); ?></h2>
    </div></td>
  </tr>
  <tr>
    <td width="116"><?php echo $_SESSION['unit'];?></td>
    <td width="67"><img border="0" onclick="history.back();" onmouseout="this.src='/drss/images/btn_back.jpg';" onmouseover="this.src='/drss/images/btn_back_02.jpg';" src="/drss/images/btn_back.jpg" /></td>
    <td width="68">&nbsp;</td>
    <td width="66">&nbsp;</td>
    <td width="48">&nbsp;</td>
    <td width="48">&nbsp;</td>
    <td width="48">&nbsp;</td>
    <td width="49">&nbsp;</td>
    <td width="40"><?php echo "<a href=rank$_SESSION[unit].pdf>Print Preview</a>"; ?></td>
  </tr>
  <tr>
    <td colspan="9"><?php select_to_table($rank,2,2); ?></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
    <td colspan="7">&nbsp;</td>
  </tr>
</table>
</body>
<?php
$data=ob_get_contents();
		 $fp=fopen("rank$_SESSION[unit].html","w");
		 fwrite($fp,$data);
		 fclose($fp);
		 ob_end_flush();
		 //Converting HTML file format into PDF format
		 include_once("scripts/html2fpdf.php");
		$pdf=new HTML2FPDF();
		$pdf->AddPage();
		$fp1 = fopen("rank$_SESSION[unit].html","r");
		$strContent = fread($fp1, filesize("rank$_SESSION[unit].html"));
		fclose($fp1);
		$pdf->WriteHTML($strContent);
		$pdf->Output("rank$_SESSION[unit].pdf");
?>
</html>
