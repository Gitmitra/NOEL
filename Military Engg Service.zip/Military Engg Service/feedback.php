<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
session_start();
if(empty($_SESSION['start'])) 
{
session_destroy();
session_destroy();
$host = $_SERVER['HTTP_HOST'];
$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra = 'index.php';
header("Location: http://$host$uri/$extra");
exit();
}
include_once("dao/function.php");
/*if ((!preg_match("/156.84.1./", $_SERVER['REMOTE_ADDR'])) and (!preg_match("/155.83./",$_SERVER['REMOTE_ADDR']))) 
{message("Access denied to Outstations.....!");
 exit();
}*/
?>
<head>
    <title>On-line MES Complaint</title>
	<meta http-equiv="Content-Language" content="English" />
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
    <meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="expires" content="-1" />
<script type="text/JavaScript" src="dao/test.js"></script>
<script language="JavaScript" type="text/JavaScript">
	javascript:window.history.forward(1);
</script>
	<link href="mes.css" rel="stylesheet" type="text/css" />
     <style type="text/css">
<!--
.style4 {color: #006AC3; font-weight: bold; }
-->
</style>
</head>
<body>
<div id="container">
   <div id="container-header"><div id="container-name"><span>On-line </span>MES Complaint </div></div>
   <div id="container-eyecatcher"><img src="images/business_eyecatcher.jpg" width="668" height="138" /></div>
   <div id="container-content">
		
		  <h1>Your Remarks </h1> 
		  <hr/>
		  <font color="#FF0000">Pls Note:- You can give feedback when your complaint is not attended or physically done, whereas MES has given remarks as "DONE".</font>
			 <form id="form1"  name="frmstatus" method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
           	<table width="469" border="0" align="center">
  <tr>
    <th width="104" scope="row"><div align="left">Complaint No </div></th>
    <th width="10" scope="row">:</th>
    <td width="144"><input type="text" name="txtvalue" /></td>
    <td width="102"><input type="hidden" name="comno" value="Submit" />
      <img border="0" onclick="chkval();" onmouseout="this.src='images/btn_submit.gif';" onmouseover="this.src='images/btn_submit_02.gif';" src="images/btn_submit.gif" /></td>
    <td width="87"><a href="index.php"><img border="0" onmouseout="this.src='images/btn_back.jpg';" onmouseover="this.src='images/btn_back_02.jpg';" src="images/btn_back.jpg" /></a></td>
  </tr>
</table>
		 </form>
		
		
	<?php
	dbconnect();
	if(isset($_POST['comno']) && $_POST['comno'] == 'Submit')
	{
	  $query = "select comno from complaint where comno = '$_POST[txtvalue]' and remarks = 'DONE'";
	  $result = mysql_query($query);
	  $row = mysql_fetch_array($result);
	  $rows = mysql_num_rows($result);
	  if($rows == 1)
	  {
	  ?>
	    
			 <form id="form1"  name="frmfeed" method="post" action="./process.php?comno=<?php echo $row[comno]; ?>">
           	<table width="378" border="0" align="center">
  <tr>
    <th width="104" scope="row"><div align="left">Feedback</div></th>
    <th width="10" scope="row">:</th>
    <td width="144"><textarea name="feedback" cols="50" rows="4"></textarea></td>
    <td width="102"><input type="hidden" name="urremarks" value="Submit" />
      <img border="0" onclick="chkval1();" onmouseout="this.src='images/btn_submit.gif';" onmouseover="this.src='images/btn_submit_02.gif';" src="images/btn_submit.gif" /></td>
    </tr>
</table>
		 </form>
		 <hr/>
	  <?php 
	    }
	}
	dbclose();
	?>
	  </div> <!-- END of container-content -->

	<div id="container-footer">
           <div id="footer">
               <div id="footer-copyright">Copyright &copy; 27wg, NET &amp; IT SQN- all rights reserved.
			   
			   </div>
      </div>
	  
	</div> <!-- END of container-footer -->

</div> <!-- END of container -->
</body>
</html>
