<?php 
session_start();
include_once ("function.php");
if($_SESSION['unit'] != '27WG' || empty($_SESSION['unit'])) 
{
	include_once("index.php");
	message("err.png","You are not authorised");
	$host = $_SERVER['HTTP_HOST'];
	$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
	$extra = 'index.php';
	header("Refresh: 2; URL=http://$host$uri/$extra");
	exit();
}
else
{
dbconnect();

$type1 = array('POSTED_IN','TD');
$movcode1 = array('LEAVE','TD','HOSP','AWL');
$category1 = array('SNCOs','AIRMEN','NCs(E)');
$unit1 = array('27WG','37SQN','108SQN','2201SQN','2224SQN','2254SQN','171SU','777SU','853SU','478MOF','308TRU','607GRDFLT');

//values for Posted Strength and TD column 
foreach($type1 as $value)
{	
	$type = $value;
	foreach($unit1 as $value)
	{
		$unit = $value;
		switch($unit) {
			case "27WG":
				$table1 = "personal_info27";
	 	 	 	break;
			case "37SQN":
				$table1 = "personal_info37";
	 	 	 	break;
			case "108SQN":
				$table1 = "personal_info108";
	 	 	 	break;
			case "2201SQN":
				$table1 = "personal_info2201";
	 	 	 	break;
			case "2224SQN":
				$table1 = "personal_info2224";
	 	 	 	break;
			case "2254SQN":
				$table1 = "personal_info2254";
	 	 	 	break;
			case "171SU":
				$table1 = "personal_info171";
	 	 	 	break;
			case "777SU":
				$table1 = "personal_info777";
	 	 	 	break;
			case "853SU":
				$table1 = "personal_info853";
	 	 	 	break;
			case "478MOF":
				$table1 = "personal_info478";
	 	 	 	break;
			case "308TRU":
				$table1 = "personal_info308";
	 	 	 	break;
			case "607GRDFLT":
				$table1 = "personal_info607";
	 	 	 	break;
			}
		foreach($category1 as $value)
		{
			$category = $value;
			$array = compact("type","unit","category");
			$tots[]= fetch_row($table1,$array);
		}
	}
}
//values for Leave,TD,Hosp and AWL column 
foreach($movcode1 as $value)
{
	$movcode = $value;
	foreach($unit1 as $value)
	{
		$unit = $value;
		switch($unit) {
			case "27WG":
				$table1 = "personal_info27";
	 	 	 	break;
			case "37SQN":
				$table1 = "personal_info37";
	 	 	 	break;
			case "108SQN":
				$table1 = "personal_info108";
	 	 	 	break;
			case "2201SQN":
				$table1 = "personal_info2201";
	 	 	 	break;
			case "2224SQN":
				$table1 = "personal_info2224";
	 	 	 	break;
			case "2254SQN":
				$table1 = "personal_info2254";
	 	 	 	break;
			case "171SU":
				$table1 = "personal_info171";
	 	 	 	break;
			case "777SU":
				$table1 = "personal_info777";
	 	 	 	break;
			case "853SU":
				$table1 = "personal_info853";
	 	 	 	break;
			case "478MOF":
				$table1 = "personal_info478";
	 	 	 	break;
			case "308TRU":
				$table1 = "personal_info308";
	 	 	 	break;
			case "607GRDFLT":
				$table1 = "personal_info607";
	 	 	 	break;
			}
		foreach($category1 as $value)
		{
			$category = $value;
			$array1 = compact("movcode","unit","category");
			$ne[] = fetch_row($table1,$array1);
		}
	}
}
//values for Total(posetd+Att) and TotalNE(Leave+TD+Hosp+AWL) and Effective Strength column 
$totps = 0;
$totlv = 0;
for ($i = 0; $i < 36; $i++)
{
	$tot[$i] = $tots[$i][0] + $tots[36 + $i][0];
	$totne[$i] = $ne[$i][0] + $ne[36 + $i][0] + $ne[72 + $i][0] + $ne[108 + $i][0];
	$eff[$i] = $tot[$i] - $totne[$i];
	$totps = $totps + $tots[$i][0];
	$totlv = $totlv + $ne[$i][0];
}

//grandtotal
$gtot = 0;
for ($i = 0; $i < 36; $i++)
{
	$gtot = $gtot + $tot[$i];
	$gtotne = $gtotne + $totne[$i];
	$geff = $geff + $eff[$i];
}

//Total of attachment and TD column
$totatt = 0;
$tottd = 0;
for ($i = 36; $i < 72; $i++)
{
	$totatt = $totatt + $tots[$i][0];
	$tottd = $tottd + $ne[$i][0];
}

//Total of hospital column
$tothp = 0;
for ($i = 72; $i < 108; $i++)
{
	$tothp = $tothp + $ne[$i][0];
}

//Total of awl column
$totawl = 0;
for ($i = 108; $i < 144; $i++)
{
	$totawl = $totawl + $ne[$i][0];
}

?>
<title>PARADE STATE</title>
<body>

<table width="749" border="0" align="left">
  
  <tr>
    <th height="21" colspan="2" align="center" valign="top" scope="col">&nbsp;</th>
  </tr>
  <tr>
    <th height="31" colspan="2" align="center" valign="top" scope="col"><p><u>DAILY PARADE STATE : 27WG &amp; ITS LODGER UNITS </u></p>    </th>
  </tr>
  <tr>
    <th colspan="2" align="center" valign="top" scope="col"></th>
  </tr>
  <tr>
    <th width="596" align="center" valign="top" scope="col"></th>
    <th width="143" align="center" valign="top" scope="col"><p align="left">Date: <?php echo $_POST['dtdrss']; ?></p>    </th>
  </tr>
  <tr>
    <th colspan="2" align="center" valign="top" scope="col">
      <table width="100%" border="0" align="left" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="12"><img src="../drss/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
          <td colspan="11" background="../drss/images/table_r1_c2.gif"><img src="../drss/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
          <td width="13"><img src="../drss/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
        </tr>
        <tr>
          <td height="29" background="../drss/images/table_r2_c1.gif"></td>
          <td width="92"><div align="left"><strong>UNITS</strong></div></td>
          <td width="76"><div align="left"><strong>DETAILS</strong></div></td>
          <td width="55"><div align="center"><strong>P / STR </strong></div></td>
          <td width="64"><div align="center"><strong>ATT</strong></div></td>
          <td width="63"><div align="center"><strong>TOTAL</strong></div></td>
          <td width="60"><div align="center"><strong>LEAVE</strong></div></td>
          <td width="55"><div align="center"><strong>TD</strong></div></td>
          <td width="55"><div align="center"><strong>HOSP</strong></div></td>
          <td width="55"><div align="center"><strong>AWL</strong></div></td>
          <td width="54"><div align="center"><strong>NE</strong></div></td>
          <td width="88"><div align="center"><strong>EFFECTIVE</strong></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td bgcolor="#D8D8D8">27WG</td>
          <td bgcolor="#D8D8D8">SNCOs</td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[0][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[36][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tot[0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[0][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[36][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[72][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[108][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $totne[0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $eff[0]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>AIRMEN</td>
          <td><div align="center"><?php echo $tots[1][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[37][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[1]; ?></div></td>
          <td><div align="center"><?php echo $ne[1][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[37][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[73][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[109][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[1]; ?></div></td>
          <td><div align="center"><?php echo $eff[1]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>NCs(E)</td>
          <td><div align="center"><?php echo $tots[2][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[38][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[2]; ?></div></td>
          <td><div align="center"><?php echo $ne[2][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[38][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[74][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[110][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[2]; ?></div></td>
          <td><div align="center"><?php echo $eff[2]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td bgcolor="#D8D8D8">37SQN</td>
          <td bgcolor="#D8D8D8">SNCOs</td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[3][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[39][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tot[3]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[3][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[39][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[75][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[111][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $totne[3]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $eff[3]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>AIRMEN</td>
          <td><div align="center"><?php echo $tots[4][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[40][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[4]; ?></div></td>
          <td><div align="center"><?php echo $ne[4][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[40][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[76][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[112][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[4]; ?></div></td>
          <td><div align="center"><?php echo $eff[4]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>NCs(E)</td>
          <td><div align="center"><?php echo $tots[5][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[41][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[5]; ?></div></td>
          <td><div align="center"><?php echo $ne[5][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[41][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[77][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[113][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[5]; ?></div></td>
          <td><div align="center"><?php echo $eff[5]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td bgcolor="#D8D8D8">108SQN</td>
          <td bgcolor="#D8D8D8">SNCOs</td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[6][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[42][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tot[6]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[6][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[42][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[78][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[114][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $totne[6]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $eff[6]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>AIRMEN</td>
          <td><div align="center"><?php echo $tots[7][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[43][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[7]; ?></div></td>
          <td><div align="center"><?php echo $ne[7][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[43][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[79][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[115][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[7]; ?></div></td>
          <td><div align="center"><?php echo $eff[7]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>NCs(E)</td>
          <td><div align="center"><?php echo $tots[8][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[44][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[8]; ?></div></td>
          <td><div align="center"><?php echo $ne[8][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[44][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[80][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[116][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[8]; ?></div></td>
          <td><div align="center"><?php echo $eff[8]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td bgcolor="#D8D8D8">2201SQN</td>
          <td bgcolor="#D8D8D8">SNCOs</td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[9][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[45][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tot[9]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[9][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[45][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[81][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[117][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $totne[9]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $eff[9]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>AIRMEN</td>
          <td><div align="center"><?php echo $tots[10][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[46][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[10]; ?></div></td>
          <td><div align="center"><?php echo $ne[10][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[46][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[82][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[118][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[10]; ?></div></td>
          <td><div align="center"><?php echo $eff[10]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>NCs(E)</td>
          <td><div align="center"><?php echo $tots[11][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[47][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[11]; ?></div></td>
          <td><div align="center"><?php echo $ne[11][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[47][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[83][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[119][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[11]; ?></div></td>
          <td><div align="center"><?php echo $eff[11]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td bgcolor="#D8D8D8">2224SQN</td>
          <td bgcolor="#D8D8D8">SNCOs</td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[12][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[48][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tot[12]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[12][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[48][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[84][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[120][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $totne[12]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $eff[12]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>AIRMEN</td>
          <td><div align="center"><?php echo $tots[13][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[49][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[13]; ?></div></td>
          <td><div align="center"><?php echo $ne[13][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[49][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[85][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[121][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[13]; ?></div></td>
          <td><div align="center"><?php echo $eff[13]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>NCs(E)</td>
          <td><div align="center"><?php echo $tots[14][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[50][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[14]; ?></div></td>
          <td><div align="center"><?php echo $ne[14][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[50][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[86][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[122][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[14]; ?></div></td>
          <td><div align="center"><?php echo $eff[14]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td bgcolor="#D8D8D8">2254SQN</td>
          <td bgcolor="#D8D8D8">SNCOs</td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[15][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[51][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tot[15]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[15][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[51][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[87][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[123][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $totne[15]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $eff[15]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>AIRMEN</td>
          <td><div align="center"><?php echo $tots[16][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[52][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[16]; ?></div></td>
          <td><div align="center"><?php echo $ne[16][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[52][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[88][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[124][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[16]; ?></div></td>
          <td><div align="center"><?php echo $eff[16]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>NCs(E)</td>
          <td><div align="center"><?php echo $tots[17][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[53][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[17]; ?></div></td>
          <td><div align="center"><?php echo $ne[17][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[53][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[89][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[125][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[17]; ?></div></td>
          <td><div align="center"><?php echo $eff[17]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td bgcolor="#D8D8D8">171SU</td>
          <td bgcolor="#D8D8D8">SNCOs</td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[18][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[54][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tot[18]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[18][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[54][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[90][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[126][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $totne[18]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $eff[18]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>AIRMEN</td>
          <td><div align="center"><?php echo $tots[19][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[55][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[19]; ?></div></td>
          <td><div align="center"><?php echo $ne[19][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[55][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[91][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[127][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[19]; ?></div></td>
          <td><div align="center"><?php echo $eff[19]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>NCs(E)</td>
          <td><div align="center"><?php echo $tots[20][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[56][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[20]; ?></div></td>
          <td><div align="center"><?php echo $ne[20][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[56][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[92][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[128][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[20]; ?></div></td>
          <td><div align="center"><?php echo $eff[20]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td bgcolor="#D8D8D8">777SU</td>
          <td bgcolor="#D8D8D8">SNCOs</td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[21][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[57][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tot[21]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[21][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[57][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[93][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[129][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $totne[21]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $eff[21]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>AIRMEN</td>
          <td><div align="center"><?php echo $tots[22][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[58][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[22]; ?></div></td>
          <td><div align="center"><?php echo $ne[22][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[58][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[94][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[130][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[22]; ?></div></td>
          <td><div align="center"><?php echo $eff[22]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>NCs(E)</td>
          <td><div align="center"><?php echo $tots[23][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[59][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[23]; ?></div></td>
          <td><div align="center"><?php echo $ne[23][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[59][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[95][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[131][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[23]; ?></div></td>
          <td><div align="center"><?php echo $eff[23]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td bgcolor="#D8D8D8">853SU</td>
          <td bgcolor="#D8D8D8">SNCOs</td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[24][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[60][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tot[24]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[24][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[60][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[96][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[132][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $totne[24]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $eff[24]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>AIRMEN</td>
          <td><div align="center"><?php echo $tots[25][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[61][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[25]; ?></div></td>
          <td><div align="center"><?php echo $ne[25][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[61][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[97][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[133][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[25]; ?></div></td>
          <td><div align="center"><?php echo $eff[25]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>NCs(E)</td>
          <td><div align="center"><?php echo $tots[26][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[62][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[26]; ?></div></td>
          <td><div align="center"><?php echo $ne[26][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[62][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[98][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[134][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[26]; ?></div></td>
          <td><div align="center"><?php echo $eff[26]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td bgcolor="#D8D8D8">478MOF</td>
          <td bgcolor="#D8D8D8">SNCOs</td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[27][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[63][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tot[27]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[27][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[63][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[99][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[135][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $totne[27]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $eff[27]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>AIRMEN</td>
          <td><div align="center"><?php echo $tots[28][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[64][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[28]; ?></div></td>
          <td><div align="center"><?php echo $ne[28][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[64][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[100][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[136][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[28]; ?></div></td>
          <td><div align="center"><?php echo $eff[28]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>NCs(E)</td>
          <td><div align="center"><?php echo $tots[29][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[65][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[29]; ?></div></td>
          <td><div align="center"><?php echo $ne[29][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[65][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[101][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[137][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[29]; ?></div></td>
          <td><div align="center"><?php echo $eff[29]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../drss/images/table_r2_c1.gif"></td>
          <td bgcolor="#D8D8D8">308TRU</td>
          <td bgcolor="#D8D8D8">SNCOs</td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[30][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[66][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tot[30]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[30][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[66][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[102][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[138][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $totne[30]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $eff[30]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="26" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>AIRMEN</td>
          <td><div align="center"><?php echo $tots[31][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[67][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[31]; ?></div></td>
          <td><div align="center"><?php echo $ne[31][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[67][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[103][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[139][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[31]; ?></div></td>
          <td><div align="center"><?php echo $eff[31]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="26" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>NCs(E)</td>
          <td><div align="center"><?php echo $tots[32][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[68][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[32]; ?></div></td>
          <td><div align="center"><?php echo $ne[32][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[68][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[104][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[140][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[32]; ?></div></td>
          <td><div align="center"><?php echo $eff[32]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="26" background="../drss/images/table_r2_c1.gif"></td>
          <td bgcolor="#D8D8D8">342TRU</td>
          <td bgcolor="#D8D8D8">SNCOs</td>
          <td bgcolor="#D8D8D8">&nbsp;</td>
          <td bgcolor="#D8D8D8">&nbsp;</td>
          <td bgcolor="#D8D8D8">&nbsp;</td>
          <td bgcolor="#D8D8D8">&nbsp;</td>
          <td bgcolor="#D8D8D8">&nbsp;</td>
          <td bgcolor="#D8D8D8">&nbsp;</td>
          <td bgcolor="#D8D8D8">&nbsp;</td>
          <td bgcolor="#D8D8D8">&nbsp;</td>
          <td bgcolor="#D8D8D8">&nbsp;</td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="26" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>AIRMEN</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="26" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>NCs(E)</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="26" background="../drss/images/table_r2_c1.gif"></td>
          <td bgcolor="#D8D8D8">607GRDFLT</td>
          <td bgcolor="#D8D8D8">SNCOs</td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[33][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tots[69][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $tot[33]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[33][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[69][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[105][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $ne[141][0]; ?></div></td>
          <td bgcolor="#D8D8D8"><div align="center"><?php echo $totne[33]; ?></div></td>
         <td bgcolor="#D8D8D8"><div align="center"><?php echo $eff[33]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="26" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>AIRMEN</td>
          <td><div align="center"><?php echo $tots[34][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[70][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[34]; ?></div></td>
          <td><div align="center"><?php echo $ne[34][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[70][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[106][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[142][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[34]; ?></div></td>
          <td><div align="center"><?php echo $eff[34]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="26" background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td>NCs(E)</td>
          <td><div align="center"><?php echo $tots[35][0]; ?></div></td>
          <td><div align="center"><?php echo $tots[71][0]; ?></div></td>
          <td><div align="center"><?php echo $tot[35]; ?></div></td>
          <td><div align="center"><?php echo $ne[35][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[71][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[107][0]; ?></div></td>
          <td><div align="center"><?php echo $ne[143][0]; ?></div></td>
          <td><div align="center"><?php echo $totne[35]; ?></div></td>
          <td><div align="center"><?php echo $eff[35]; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="29" background="../drss/images/table_r2_c1.gif"></td>
          <td colspan="2" bgcolor="#FFFFCC"><div align="center"><strong>TOTAL</strong></div></td>
          <td bgcolor="#FFFFCC"><div align="center"><?php echo $totps; ?></div></td>
          <td bgcolor="#FFFFCC"><div align="center"><?php echo $totatt; ?></div></td>
          <td bgcolor="#FFFFCC"><div align="center"><?php echo $gtot; ?></div></td>
          <td bgcolor="#FFFFCC"><div align="center"><?php echo $totlv; ?></div></td>
          <td bgcolor="#FFFFCC"><div align="center"><?php echo $tottd; ?></div></td>
          <td bgcolor="#FFFFCC"><div align="center"><?php echo $tothp; ?></div></td>
          <td bgcolor="#FFFFCC"><div align="center"><?php echo $totawl; ?></div></td>
          <td bgcolor="#FFFFCC"><div align="center"><?php echo $gtotne; ?></div></td>
          <td bgcolor="#FFFFCC"><div align="center"><?php echo $geff; ?></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        
        <tr>
          <td><img src="../drss/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
          <td colspan="11" background="../drss/images/table_r3_c2.gif"><img src="../drss/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
          <td><img src="../drss/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
        </tr>
      </table>    </th>
  </tr>
   <tr>
    <th align="center" valign="bottom" scope="col"><div align="left"><img src="/drss/images/btn_back.jpg" border="0" align="bottom" onClick="history.back();" onMouseOver="this.src='/drss/images/btn_back_02.jpg';" onMouseOut="this.src='/drss/images/btn_back.jpg';" />
    </div></th>
    <th align="center" valign="bottom" scope="col"><div align="left"><img src="icons/print.png" width="32" height="27" align="bottom" onClick="window.print();">Print</div></th>
  </tr>
</table>

<?php } ?>
</body>



