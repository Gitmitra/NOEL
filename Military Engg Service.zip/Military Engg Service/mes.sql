# SQL Manager 2005 for MySQL 3.6.5.1
# ---------------------------------------
# Host     : localhost
# Port     : 3306
# Database : mes


SET FOREIGN_KEY_CHECKS=0;

DROP DATABASE IF EXISTS `mes`;

CREATE DATABASE `mes`
    CHARACTER SET 'latin1'
    COLLATE 'latin1_swedish_ci';

USE `mes`;

#
# Structure for the `complaint` table : 
#

DROP TABLE IF EXISTS `complaint`;

CREATE TABLE `complaint` (
  `cid` double(15,0) NOT NULL auto_increment,
  `comdt` date NOT NULL,
  `no` int(11) default NULL,
  `comno` varchar(15) default NULL,
  `serno` int(10) NOT NULL default '0',
  `area` varchar(25) default NULL,
  `sqn` varchar(25) default NULL,
  `location` varchar(25) default NULL,
  `fault` varchar(900) default NULL,
  `comtype` varchar(10) default NULL,
  `subdiv` varchar(50) default NULL,
  `reminder` int(10) default NULL,
  `reminderdt` date default NULL,
  `rectifydt` date default NULL,
  `remarks` varchar(100) default NULL,
  `rem_by_user` varchar(100) default NULL,
  PRIMARY KEY  (`cid`),
  UNIQUE KEY `cid` (`cid`),
  UNIQUE KEY `comp` (`comdt`,`serno`,`fault`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Data for the `complaint` table  (LIMIT 0,500)
#

INSERT INTO `complaint` (`cid`, `comdt`, `no`, `comno`, `serno`, `area`, `sqn`, `location`, `fault`, `comtype`, `subdiv`, `reminder`, `reminderdt`, `rectifydt`, `remarks`, `rem_by_user`) VALUES 
  (1,'2008-11-12',1,'08-1',750150,'RESIDENTIAL',NULL,'918/2','Q','EM',NULL,0,'2008-11-14',NULL,'TEST',NULL),
  (58,'2009-01-02',7,'09-7',24114,'RESIDENTIAL','108SQN','964/1','plaster of wall','BR','PLASTER WORK',0,'2009-01-02','2009-01-02','UNDER PROGRESS',NULL),
  (9,'2008-10-14',5,'08-5',750150,'RESIDENTIAL',NULL,'918/2','TUBELIGHT US','EM','ELECTRICAL WORK',1,'2008-11-14','2008-11-17','DONE',NULL),
  (50,'2008-12-09',31,'08-31',12345,'TECHNICAL','STNHQ','P-163','5 amp switch is u/s. Needs to be replaced','EM','ELECTRICAL WORK',0,'2008-12-09','2008-12-09','DONE',NULL),
  (34,'2008-12-06',30,'08-30',101011,'TECHNICAL','2201SQN','123','Technical electrical fault','EM','ELECTRICAL WORK',0,'2008-12-06','2008-12-09','DONE',NULL),
  (51,'2008-12-19',32,'08-32',750150,'RESIDENTIAL',NULL,'876/2','tubelight us','EM','ELECTRICAL WORK',0,'2008-12-19','2009-01-06','DONE','Tubelight was not changed.'),
  (52,'2009-01-01',1,'09-1',23432,'RESIDENTIAL',NULL,'401/2','fixing of pelmets','BR','CARPENTER WORK',0,'2009-01-01','2009-01-01','UNDER PROGRESS',NULL),
  (53,'2009-01-01',2,'09-2',24114,'RESIDENTIAL',NULL,'963/2','color wash &painting','BR','PERIODICAL SERVICES',0,'2009-01-01','2009-01-01','CONTRACTOR JOB',NULL),
  (54,'2009-01-01',3,'09-3',754213,'RESIDENTIAL','37SQN','458','li9il,.l','EM','EXTERNAL WATER SUPPLY',0,'2009-01-01',NULL,'PENDING',NULL),
  (55,'2009-01-01',4,'09-4',789456,'RESIDENTIAL',NULL,'78945','hrhhrhbi ikkgmjgjkm  jgk','EM','EXTERNAL WATER SUPPLY',0,'2009-01-01',NULL,'PENDING',NULL),
  (56,'2009-01-01',5,'09-5',789456,'RESIDENTIAL',NULL,'789/4','door broken','BR','WELDING WORK',0,'2009-01-01',NULL,'PENDING',NULL),
  (57,'2009-01-01',6,'09-6',789456,'RESIDENTIAL',NULL,'789/9','no water supply','EM','EXTERNAL WATER SUPPLY',0,'2009-01-01',NULL,'PENDING',NULL);

COMMIT;

#
# Structure for the `location` table : 
#

DROP TABLE IF EXISTS `location`;

CREATE TABLE `location` (
  `location` varchar(30) NOT NULL,
  PRIMARY KEY  (`location`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Data for the `location` table  (LIMIT 0,500)
#

INSERT INTO `location` (`location`) VALUES 
  ('108SQN'),
  ('171SU'),
  ('2201SQN'),
  ('2254SQN'),
  ('37SQN'),
  ('478MOF'),
  ('607GDFLT'),
  ('777SU'),
  ('853SU'),
  ('ADMIN SP GP'),
  ('MAINT SP GP'),
  ('OPS SP GP'),
  ('STNHQ');

COMMIT;

#
# Structure for the `user` table : 
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `username` varchar(20) default NULL,
  `password` varchar(20) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Data for the `user` table  (LIMIT 0,500)
#

INSERT INTO `user` (`username`, `password`) VALUES 
  ('BR','123mitra'),
  ('EM','123mitra'),
  ('cdr','123mitra'),
  ('MC','123mitra');

COMMIT;

