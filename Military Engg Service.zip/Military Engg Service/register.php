<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
session_start();
$host = $_SERVER['HTTP_HOST'];
$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra = 'index.php';
if(empty($_SESSION['points']) || empty($_SESSION['start'])) 
{
session_destroy();
header("Location: http://$host$uri/$extra");
exit();
}
include_once("dao/function.php");
/*if ((!preg_match("/156.84.1./", $_SERVER['REMOTE_ADDR'])) and (!preg_match("/155.83./",$_SERVER['REMOTE_ADDR']))) 
{message("Access denied to Outstations.....!");
 exit();
}*/
dbconnect();
$locresult=mysql_query("select * from location");
dbclose();
?>
<head>
    <title>On-line MES Complaint</title>
	<meta http-equiv="Content-Language" content="English" />
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
	<meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="expires" content="-1" />
<script type="text/JavaScript" src="dao/test.js"></script>
<script language="JavaScript" type="text/JavaScript">
	javascript:window.history.forward(1);
</script>
    	<link href="mes.css" rel="stylesheet" type="text/css" />
        <style type="text/css">
<!--
.style1 {color: #FF0000}
.style3 {font-size: 9}
-->
        </style>
</head>
<body>
<div id="container">
   <div id="container-header"><div id="container-name"><span>On-line </span>MES Complaint </div></div>
   <div id="container-eyecatcher"><img src="images/business_eyecatcher.jpg" width="668" height="138" /></div>
   <div id="container-content">
	
		    <h1>Registration of MES Complaint </h1>
			<hr/>
   	   <form id="form1" name="frmreg" method="post" action="./process.php">
	   <table width="559" border="0" align="center">
  <tr>
    <th width="46" scope="row"><div align="left">Date</div></th>
    <th width="6" scope="row">:</th>
    <td colspan="4" style="color:#0000CC"><strong><?php echo date("d-M-Y");?></strong></td>
  </tr>
  <tr>
    <th valign="bottom" scope="row"><div align="left">Type</div></th>
    <th valign="bottom" scope="row">:</th>
    <td width="218"><label>
      <input name="type" type="radio" value="EM" checked="checked" />
      <strong>E &amp; M</strong> 
      <select name="EM">
	    <option value="ELECTRICAL WORK">ELECTRICAL WORK</option>
        <option value="ACs">ACs</option>
        <option value="EXTERNAL WATER SUPPLY">EXTERNAL WATER SUPPLY</option>
        <option value="GYSER">GYSER</option>
		<option value="MISCELLANEOUS">MISCELLANEOUS</option>
      </select>
    </label></td>
    <td colspan="3"><label>
      <input name="type" type="radio" value="BR" />
      <strong> B &amp; R</strong><br />
      <select name="BR">
        <option value="PLASTER WORK">PLASTER WORK</option>
        <option value="CARPENTER WORK">CARPENTER WORK</option>
        <option value="WELDING WORK">WELDING WORK</option>
		<option value="PERIODICAL SERVICES">PERIODICAL SERVICES</option>
        <option value="SANITARY/DRAIN/SEWAGE">SANITARY/DRAIN/SEWAGE</option>
        <option value="INTERNAL WATER SUPPLY">INTERNAL WATER SUPPLY</option>
		<option value="MISCELLANEOUS">MISCELLANEOUS</option>
      </select>
    </label></td>
  </tr>
  <tr>
    <th scope="row"><div align="left"><strong>Ser no </strong></div></th>
    <th scope="row">:</th>
    <td><input name="serno" type="text" maxlength="9"/></td>
    <td width="54"><div align="left"><strong>Area</strong></div></td>
    <td width="144"><select name="area">
	  <option value="">--Select--</option>
      <option value="RESIDENTIAL">RESIDENTIAL</option>
      <option value="TECHNICAL">TECHNICAL</option>
        </select></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <th scope="row"><div align="left">Location</div></th>
    <th scope="row">:</th>
    <td><select name="sqn" id="select" ><option value="">--Select--</option>
			  <?php while ($location=mysql_fetch_array($locresult)) {
			?>
			
            <option value="<?php printf("%s", $location[0]);?>"><?php printf("%s", $location[0]);?></option>
            <?php } ?>
          </select></td>
    <td><div align="left"><strong>Bldg No </strong></div></td>
    <td><input type="text" name="location" /></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <th valign="top" scope="row"><div align="left">Fault</div></th>
    <th valign="top" scope="row">:</th>
    <td colspan="4"><textarea name="fault" cols="50" rows="4"></textarea></td>
  </tr>
  <tr>
    <td colspan="3" scope="row"><span class="style1">* Choose either E&amp;M / B&amp;R then select type. </span></td>
    <td>&nbsp;</td>
    <td><input type="hidden" name="Submit" value="Register" />
      <img border="0" onclick="addSave();" onmouseout="this.src='images/btn_submit.gif';" onmouseover="this.src='images/btn_submit_02.gif';" src="images/btn_submit.gif" /></td>
    <td width="65"><a href="index.php"><img border="0" onmouseout="this.src='images/btn_back.jpg';" onmouseover="this.src='images/btn_back_02.jpg';" src="images/btn_back.jpg" /></a></td>
  </tr>
</table>
       </form>
	 <hr/> 
  </div> <!-- END of container-content -->
	<div id="container-footer">
           <div id="footer">
               <div id="footer-copyright">Copyright &copy; 27wg, NET & IT SQN- all rights reserved.</div>
               </div>
    </div> <!-- END of container-footer -->

</div> <!-- END of container -->
</body>
</html>
