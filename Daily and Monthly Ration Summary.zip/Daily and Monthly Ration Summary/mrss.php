<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<?php 
session_start();
if(empty($_SESSION['unit'])) 
{
	$host = $_SERVER['HTTP_HOST'];
	$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
	$extra = 'login.php';
	session_destroy();
	header("Location: http://$host$uri/$extra");
	exit();
}
include_once ("function.php");
dbconnect();
		switch($_SESSION['unit']) {
			case "27WG":
				$table1 = "personal_info27";
	 	 	 	$table2 = "movement27";
				break;
			case "37SQN":
				$table1 = "personal_info37";
	 	 	 	$table2 = "movement37";
				break;
			case "108SQN":
				$table1 = "personal_info108";
	 	 	 	$table2 = "movement108";
				break;
			case "2201SQN":
				$table1 = "personal_info2201";
	 	 	 	$table2 = "movement2201";
				break;
			case "2224SQN":
				$table1 = "personal_info2224";
	 	 	 	$table2 = "movement2224";
				break;
			case "2254SQN":
				$table1 = "personal_info2254";
	 	 	 	$table2 = "movement2254";
				break;
			case "171SU":
				$table1 = "personal_info171";
	 	 	 	$table2 = "movement171";
				break;
			case "777SU":
				$table1 = "personal_info777";
	 	 	 	$table2 = "movement777";
				break;
			case "853SU":
				$table1 = "personal_info853";
	 	 	 	$table2 = "movement853";
				break;
			case "478MOF":
				$table1 = "personal_info478";
	 	 	 	$table2 = "movement478";
				break;
			case "308TRU":
				$table1 = "personal_info308";
	 	 	 	$table2 = "movement308";
				break;
			case "342TRU":
				$table1 = "personal_info342";
	 	 	 	$table2 = "movement342";
				break;
			case "607GRDFLT":
				$table1 = "personal_info607";
	 	 	 	$table2 = "movement607";
				break;
			}
if(isset($_POST['action']) && $_POST['action'] == 'submitted')
{
$mon = array('01'=>'JAN','02'=>'FEB','03'=>'MAR','04'=>'APR','05'=>'MAY','06'=>'JUN','07'=>'JUL','08'=>'AUG','09'=>'SEP','10'=>'OCT','11'=>'NOV','12'=>'DEC');
foreach($mon as $key => $value)
	{
		if ($_POST['mnth'] == $value)
		{$m = "$key";}
	}
$y = $_POST['yr'];
$result1 = mysql_query("select last_day(concat('$y','-','$m','-','01'))");
$row1 = mysql_fetch_row($result1);

//All personnel who became L_IN during the month and personnel who were continuing as L_IN since torsdt and not yet posted/CTD out
mysql_query("create or replace view l_in as
select distinct a.serno,rank,rankcode,category,name,trade,b.movcode,b.type,sorsdt,torsdt,unit from ".$table2." a, ".$table1." b
where (left(sorsdt,7) = left('$row1[0]',7) or left(torsdt,7) = left('$row1[0]',7))
and a.movcode = 'L_IN' and a.serno = b.serno and p_t_out is null
union
select distinct a.serno,rank,rankcode,category,name,trade,b.movcode,b.type,sorsdt,torsdt,unit from ".$table2." a, ".$table1." b
where a.movcode = 'L_IN' and p_t_out is null and sorsdt is null and a.serno = b.serno and left(a.torsdt,7) < left('$row1[0]',7)
union 
select distinct a.serno,rank,rankcode,category,name,trade,b.movcode,b.type,sorsdt,torsdt,unit from ".$table2." a, discard b
where a.movcode = 'L_IN' and p_t_out = 'Y' and a.serno = b.serno and left(b.outdt,7) = left('$row1[0]',7)"); 

mysql_query("create or replace view leav as
select distinct a.serno,a.sorsdt,a.torsdt from ".$table2." a,l_in b
where (left(a.sorsdt,7) = left('$row1[0]',7) or left(a.torsdt,7) = left('$row1[0]',7))
and a.movcode = 'LEAVE' and a.serno = b.serno");

mysql_query("create or replace view td as
select distinct a.serno,a.sorsdt,a.torsdt from ".$table2." a,l_in b
where (left(a.sorsdt,7) = left('$row1[0]',7) or left(a.torsdt,7) = left('$row1[0]',7))
and a.movcode = 'TD' and a.serno = b.serno");

mysql_query("create or replace view hosp as
select distinct a.serno,a.sorsdt,a.torsdt from ".$table2." a,l_in b
where (left(a.sorsdt,7) = left('$row1[0]',7) or left(a.torsdt,7) = left('$row1[0]',7))
and a.movcode = 'HOSP' and a.serno = b.serno");

mysql_query("create or replace view awl as
select distinct a.serno,a.sorsdt,a.torsdt from ".$table2." a,l_in b
where (left(a.sorsdt,7) = left('$row1[0]',7) or left(a.torsdt,7) = left('$row1[0]',7))
and a.movcode = 'AWL' and a.serno = b.serno and a.regular is null");

mysql_query("create or replace view mrss as
select l_in.serno,rank,rankcode,category,name,trade,unit,movcode,type,
l_in.torsdt as lin_fm,l_in.sorsdt as lin_to,(l_in.sorsdt-l_in.torsdt) as lin_tot,
leav.sorsdt as lv_fm,leav.torsdt as lv_to,(leav.torsdt-leav.sorsdt) as lv_tot,
td.sorsdt as td_fm,td.torsdt as td_to,(td.torsdt-td.sorsdt) as td_tot,
awl.sorsdt as awl_fm,awl.torsdt as awl_to,(awl.torsdt-awl.sorsdt) as awl_tot,
hosp.sorsdt as MH_fm,hosp.torsdt as MH_to,(hosp.torsdt-hosp.sorsdt) as MH_tot
from l_in
left outer join leav on (leav.serno = l_in.serno)
left outer join td on (td.serno = l_in.serno)
left outer join awl on (awl.serno = l_in.serno)
left outer join hosp on (hosp.serno = l_in.serno)");

if($_POST['radiobtn'] == 'POSTED STRENGTH')
{
mysql_query("create temporary table if not exists tempmrss (lv_to date,td_to date,awl_to date,MH_to date) select serno,rank,rankcode,category,name,trade,unit,movcode,type,lin_fm,lin_to,lin_tot,lv_fm,subdate(lv_to,1) as lv_to,lv_tot,td_fm,subdate(td_to,1) as td_to,td_tot,awl_fm,subdate(awl_to,1) as awl_to,awl_tot,MH_fm,subdate(MH_to,1) as MH_to,MH_tot from mrss where category = '$_POST[status]' and unit='$_SESSION[unit]' and type in ('POSTED_IN','POSTED_OUT','DISCHARGE') order by serno");
}elseif ($_POST['radiobtn'] == 'ATTACHMENT')
{
mysql_query("create temporary table if not exists tempmrss (lv_to date,td_to date,awl_to date,MH_to date) select serno,rank,rankcode,category,name,trade,unit,movcode,type,lin_fm,lin_to,lin_tot,lv_fm,subdate(lv_to,1) as lv_to,lv_tot,td_fm,subdate(td_to,1) as td_to,td_tot,awl_fm,subdate(awl_to,1) as awl_to,awl_tot,MH_fm,subdate(MH_to,1) as MH_to,MH_tot from mrss where category = '$_POST[status]' and unit='$_SESSION[unit]' and type in ('TD','CTD') order by serno");
}

$alter ="alter table tempmrss add slno INT UNSIGNED AUTO_INCREMENT, ADD INDEX(slno)"; 
mysql_query($alter) or die (mysql_error());

	
mysql_query("update tempmrss set lin_fm = subdate(last_day('$row1[0]'),day(last_day('$row1[0]')-1)),lin_tot=(lin_to-lin_fm) where left(lin_fm,7) < left('$row1[0]',7)");
mysql_query("update tempmrss set lin_to = '$row1[0]',lin_tot = (lin_to-lin_fm)+1 where lin_to is null or (left(lin_to,7) > left('$row1[0]',7))");

mysql_query("update tempmrss set lv_fm = subdate(last_day('$row1[0]'),day(last_day('$row1[0]')-1)),lv_to = '$row1[0]',lv_tot =(lv_to-lv_fm)+1 where movcode ='LEAVE' and lv_fm is null and lv_to is null");
mysql_query("update tempmrss set lv_fm = null, lv_to = null,lv_tot = 0 where lv_fm > lin_to or lv_to < lin_fm");
mysql_query("update tempmrss set lv_fm = subdate(last_day('$row1[0]'),day(last_day('$row1[0]')-1)),lv_tot =(lv_to-lv_fm)+1 where (left(lv_fm,7) < left('$row1[0]',7)) and (left(lv_to,7) = left('$row1[0]',7))");
mysql_query("update tempmrss set lv_to = '$row1[0]',lv_tot =(lv_to-lv_fm)+1 where (left(lv_fm,7) = left('$row1[0]',7)) and (left(lv_to,7) > left('$row1[0]',7))");
mysql_query("update tempmrss set lv_tot = (lv_to-lv_fm)+1");

mysql_query("update tempmrss set td_fm = subdate(last_day('$row1[0]'),day(last_day('$row1[0]')-1)),td_to='$row1[0]',td_tot =(td_to-td_fm)+1 where movcode ='TD' and td_fm is null and td_to is null");
mysql_query("update tempmrss set td_fm = null, td_to = null,td_tot = 0 where td_fm > lin_to or td_to < lin_fm");
mysql_query("update tempmrss set td_fm = subdate(last_day('$row1[0]'),day(last_day('$row1[0]')-1)),td_tot =(td_to-td_fm)+1 where (left(td_fm,7) < left('$row1[0]',7)) and (left(td_to,7) = left('$row1[0]',7))");
mysql_query("update tempmrss set td_to = '$row1[0]',td_tot = (td_to-td_fm)+1 where (left(td_fm,7) = left('$row1[0]',7)) and (left(td_to,7) > left('$row1[0]',7) or td_to is null)");

mysql_query("update tempmrss set awl_fm = subdate(last_day('$row1[0]'),day(last_day('$row1[0]')-1)),awl_to = '$row1[0]',awl_tot =(awl_to-awl_fm)+1 where movcode ='AWL' and awl_fm is null and awl_to is null");
mysql_query("update tempmrss set awl_fm = null, awl_to = null,awl_tot = 0 where awl_fm > lin_to or awl_to < lin_fm");
mysql_query("update tempmrss set awl_fm = subdate(last_day('$row1[0]'),day(last_day('$row1[0]')-1)),awl_tot =(awl_to-awl_fm)+1 where (left(awl_fm,7) < left('$row1[0]',7)) and (left(awl_to,7) = left('$row1[0]',7))");
mysql_query("update tempmrss set awl_to = '$row1[0]',awl_tot =(awl_to-awl_fm)+1 where (left(awl_fm,7) = left('$row1[0]',7)) and (left(awl_to,7) > left('$row1[0]',7) or awl_to is null)");

mysql_query("update tempmrss set MH_fm = subdate(last_day('$row1[0]'),day(last_day('$row1[0]')-1)),MH_to ='$row1[0]',MH_tot =(MH_to-MH_fm)+1 where movcode ='HOSP' and MH_fm is null and MH_to is null");
mysql_query("update tempmrss set MH_fm = null, MH_to = null,MH_tot = 0 where MH_fm > lin_to or MH_to < lin_fm");
mysql_query("update tempmrss set MH_fm = subdate(last_day('$row1[0]'),day(last_day('$row1[0]')-1)),MH_tot =(MH_to-MH_fm)+1 where (left(MH_fm,7) < left('$row1[0]',7)) and (left(MH_to,7) = left('$row1[0]',7))");
mysql_query("update tempmrss set MH_to = '$row1[0]',MH_tot =(MH_to-MH_fm)+1 where (left(MH_fm,7) = left('$row1[0]',7)) and (left(MH_to,7) > left('$row[0]',7) or MH_to is null)");

mysql_query("update tempmrss set lv_tot = 0 where lv_tot is null");
mysql_query("update tempmrss set td_tot = 0 where td_tot is null");
mysql_query("update tempmrss set awl_tot = 0 where awl_tot is null");
mysql_query("update tempmrss set MH_tot = 0 where MH_tot is null");

$query = "select slno,serno,rank,name,trade,lv_fm as `Leave Fm`,lv_to as `Leave To`,lv_tot as Tot,
td_fm as `TD  Fm`,td_to as `TD  To`,td_tot as Tot,awl_fm as `AWL Fm`,awl_to as `AWL To`,awl_tot as Tot,MH_fm as `HOSP Fm`,MH_to as `HOSP To`,MH_tot as Tot, (lin_tot - (lv_tot + td_tot + awl_tot + MH_tot)) as `Ration Drawn` from tempmrss
where lin_tot > 0
order by slno";
}

?>
<title>MRSS</title>
<style type="text/css">
<!--
.style1 {
	font-family: Verdana;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<table width="1000" border="0">
  <tr>
    <td colspan="2"><div align="center" class="style1">
      <h2>RATION SUMMARY FOR THE MONTH OF <?php echo $_POST['mnth']."-".$y; ?></h2>
    </div></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" class="style1"><div align="center">L/IN : <?php echo $_POST['status'];?> ON <?php echo $_POST['radiobtn'];?></div></td>
  </tr>
  <tr>
    <td colspan="2"><?php echo $_SESSION['unit'];?></td>
  </tr>
  <tr>
    <td colspan="2"><?php select_to_table($query,2,2); ?></td>
  </tr>
  <tr>
    <td width="672"><img border="0" onClick="history.back();" onMouseOut="this.src='/drss/images/btn_back.jpg';" onMouseOver="this.src='/drss/images/btn_back_02.jpg';" src="/drss/images/btn_back.jpg" /></td>
    <td width="318"><img src="icons/print.png" width="32" height="27" onclick="window.print();" /><strong>Print</strong></td>
  </tr>
</table>
<?php
mysql_free_result($result1);
dbclose();
?>
</body>
</html>
