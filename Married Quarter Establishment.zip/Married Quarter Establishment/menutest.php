<?php
session_start();
$username=$_SESSION['user_logged'];
if(empty($username)) 
{
session_destroy();
header("Location: http://156.84.1.136/status/login.php");
exit();
}
?>
<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="File-List" href="menutest_files/filelist.xml">
<title>Title</title>
<script language="JavaScript">
<!--
function mmLoadMenus() {
  if (window.mm_menu_0806085929_0) return;
  window.mm_menu_0806085929_0 = new Menu("root",80,23,"Verdana, Arial, Helvetica, sans-serif",11,"#000000","#FFFFFF","#99CCFF","#FFCC33","left","middle",3,0,300,-5,7,true,true,true,2,false,false);
  mm_menu_0806085929_0.addMenuItem("Registration","window.open('chose.php', '_self');");
  mm_menu_0806085929_0.addMenuItem("Edit&nbsp;Data","window.open('editser.php', '_self');");
  mm_menu_0806085929_0.addMenuItem("Delete&nbsp;Data","window.open('delser.php', '_self');");
   mm_menu_0806085929_0.hideOnMouseOut=true;
   mm_menu_0806085929_0.bgColor='#FF99CC';
   mm_menu_0806085929_0.menuBorder=2;
   mm_menu_0806085929_0.menuLiteBgColor='#FFCC99';
   mm_menu_0806085929_0.menuBorderBgColor='#CCCCCC';

    window.mm_menu_0806090244_0 = new Menu("root",80,25,"Verdana, Arial, Helvetica, sans-serif",11,"#000000","#FFFFFF","#99CCFF","#FFCC33","left","middle",3,0,300,-5,7,true,true,true,2,false,false);
  mm_menu_0806090244_0.addMenuItem("Registration","window.open('chose.php', '_self');");
  mm_menu_0806090244_0.addMenuItem("Edit&nbsp;Record","window.open('editser.php', '_self');");
  mm_menu_0806090244_0.addMenuItem("Del&nbsp;Record","window.open('delser.php', '_self');");
   mm_menu_0806090244_0.hideOnMouseOut=true;
   mm_menu_0806090244_0.bgColor='#CCCCCC';
   mm_menu_0806090244_0.menuBorder=1;
   mm_menu_0806090244_0.menuLiteBgColor='#CCCCCC';
   mm_menu_0806090244_0.menuBorderBgColor='#CCCCCC';

  window.mm_menu_0806091215_0 = new Menu("root",80,25,"Verdana, Arial, Helvetica, sans-serif",11,"#000000","#FFFFFF","#99CCFF","#FFCC33","left","middle",3,0,300,-5,7,true,true,true,2,false,false);
  mm_menu_0806091215_0.addMenuItem("Allotment","window.open('allotser.php', '_self');");
  mm_menu_0806091215_0.addMenuItem("Vacation","window.open('vacateser.php', '_self');");
  mm_menu_0806091215_0.addMenuItem("Waiting&nbsp;List","window.open('qtrview.php', '_self');");
   mm_menu_0806091215_0.hideOnMouseOut=true;
   mm_menu_0806091215_0.bgColor='#CCCCCC';
   mm_menu_0806091215_0.menuBorder=1;
   mm_menu_0806091215_0.menuLiteBgColor='#CCCCCC';
   mm_menu_0806091215_0.menuBorderBgColor='#CCCCCC';

        window.mm_menu_0806091436_0 = new Menu("root",76,25,"Verdana, Arial, Helvetica, sans-serif",11,"#000000","#FFFFFF","#99CCFF","#FFCC33","left","middle",3,0,300,-5,7,true,true,true,2,false,false);
  mm_menu_0806091436_0.addMenuItem("Monthly","window.open('return.php', '_self');");
  mm_menu_0806091436_0.addMenuItem("Send&nbsp;Mail","window.open('mail.php', '_self');");
   mm_menu_0806091436_0.hideOnMouseOut=true;
   mm_menu_0806091436_0.bgColor='#CCCCCC';
   mm_menu_0806091436_0.menuBorder=1;
   mm_menu_0806091436_0.menuLiteBgColor='#CCCCCC';
   mm_menu_0806091436_0.menuBorderBgColor='#CCCCCC';

mm_menu_0806091436_0.writeMenus();
} // mmLoadMenus()

function FP_preloadImgs() {//v1.0
 var d=document,a=arguments; if(!d.FP_imgs) d.FP_imgs=new Array();
 for(var i=0; i<a.length; i++) { d.FP_imgs[i]=new Image; d.FP_imgs[i].src=a[i]; }
}

function FP_swapImg() {//v1.0
 var doc=document,args=arguments,elm,n; doc.$imgSwaps=new Array(); for(n=2; n<args.length;
 n+=2) { elm=FP_getObjectByID(args[n]); if(elm) { doc.$imgSwaps[doc.$imgSwaps.length]=elm;
 elm.$src=elm.src; elm.src=args[n+1]; } }
}

function FP_getObjectByID(id,o) {//v1.0
 var c,el,els,f,m,n; if(!o)o=document; if(o.getElementById) el=o.getElementById(id);
 else if(o.layers) c=o.layers; else if(o.all) el=o.all[id]; if(el) return el;
 if(o.id==id || o.name==id) return o; if(o.childNodes) c=o.childNodes; if(c)
 for(n=0; n<c.length; n++) { el=FP_getObjectByID(id,c[n]); if(el) return el; }
 f=o.forms; if(f) for(n=0; n<f.length; n++) { els=f[n].elements;
 for(m=0; m<els.length; m++){ el=FP_getObjectByID(id,els[n]); if(el) return el; } }
 return null;
}
// -->
</script>
<!--[if !mso]>
<style>
v\:*         { behavior: url(#default#VML) }
o\:*         { behavior: url(#default#VML) }
.shape       { behavior: url(#default#VML) }
</style>
<![endif]-->
<script language="JavaScript" src="mm_menu.js"></script>
<!--[if gte mso 9]>
<xml><o:shapedefaults v:ext="edit" spidmax="1027"/>
</xml><![endif]-->
</head>

<body onLoad="FP_preloadImgs(/*url*/'button11.jpg', /*url*/'button12.jpg', /*url*/'menubtns/button3.jpg', /*url*/'menubtns/button4.jpg', /*url*/'menubtns/button5.jpg', /*url*/'menubtns/button6.jpg', /*url*/'menubtns/buttonB.jpg', /*url*/'menubtns/buttonC.jpg', /*url*/'menubtns/buttonE.jpg', /*url*/'menubtns/buttonF.jpg', /*url*/'menubtns/button11.jpg', /*url*/'menubtns/button12.jpg')">
<script language="JavaScript1.2">mmLoadMenus();</script>
<div style="position: absolute; width: 964px; height: 77px; z-index: 1; left: 15px; top: 25px" id="layer1" align="center"> <img border="0" src="images/mdbox.jpg" width="964" height="78"></div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div style="position: absolute; width: 161px; height: 28px; z-index: 3; left: 824px; top: 119px" id="layer3"> 
	<a href="passwd.php"><img src="menubtns/buttonD.jpg" alt="" name="img4" width="80" height="26" border="0" id="img4" onMouseDown="FP_swapImg(1,0,/*id*/'img4',/*url*/'menubtns/buttonF.jpg')" onMouseUp="FP_swapImg(0,0,/*id*/'img4',/*url*/'menubtns/buttonE.jpg')" onMouseOver="FP_swapImg(1,0,/*id*/'img4',/*url*/'menubtns/buttonE.jpg')" onMouseOut="FP_swapImg(0,0,/*id*/'img4',/*url*/'menubtns/buttonD.jpg')" fp-style="fp-btn: Glow Tab 3; fp-font-size: 9; fp-font-color-normal: #0000FF; fp-font-color-hover: #00FFFF" fp-title="Password"></a><a href="logout.php"><img border="0" id="img5" src="menubtns/button10.jpg" height="26" width="80" alt="" onMouseOver="FP_swapImg(1,0,/*id*/'img5',/*url*/'menubtns/button11.jpg')" onMouseOut="FP_swapImg(0,0,/*id*/'img5',/*url*/'menubtns/button10.jpg')" onMouseDown="FP_swapImg(1,0,/*id*/'img5',/*url*/'menubtns/button12.jpg')" onMouseUp="FP_swapImg(0,0,/*id*/'img5',/*url*/'menubtns/button11.jpg')" fp-style="fp-btn: Glow Tab 3; fp-font-size: 9; fp-font-color-normal: #0000FF; fp-font-color-hover: #00FFFF" fp-title="Logout"></a></div>
<p>&nbsp;</p>
<p></p>
<div style="position: absolute; width: 241px; height: 28px; z-index: 2; left: 20px; top: 118px" id="layer2"> 
	<img src="menubtns/button7.jpg" alt="" name="image1" width="80" height="26" border="0" id="img1" onMouseDown="FP_swapImg(1,0,/*id*/'img1',/*url*/'menubtns/button4.jpg')" onMouseUp="FP_swapImg(0,0,/*id*/'img1',/*url*/'menubtns/button3.jpg')" onMouseOver="FP_swapImg(1,0,/*id*/'img1',/*url*/'menubtns/button3.jpg');MM_showMenu(window.mm_menu_0806090244_0,0,30,null,'image1')" onMouseOut="FP_swapImg(0,0,/*id*/'img1',/*url*/'menubtns/button7.jpg');MM_startTimeout();" fp-style="fp-btn: Glow Tab 3; fp-font-size: 9; fp-font-color-normal: #0000FF; fp-font-color-hover: #00FFFF" fp-title="Registration"><img src="menubtns/button8.jpg" alt="" name="image2" width="80" height="26" border="0" id="img2" onMouseDown="FP_swapImg(1,0,/*id*/'img2',/*url*/'menubtns/button6.jpg')" onMouseUp="FP_swapImg(0,0,/*id*/'img2',/*url*/'menubtns/button5.jpg')" onMouseOver="FP_swapImg(1,0,/*id*/'img2',/*url*/'menubtns/button5.jpg');MM_showMenu(window.mm_menu_0806091215_0,0,30,null,'image2')" onMouseOut="FP_swapImg(0,0,/*id*/'img2',/*url*/'menubtns/button8.jpg');MM_startTimeout();" fp-style="fp-btn: Glow Tab 3; fp-font-size: 9; fp-font-color-normal: #0000FF; fp-font-color-hover: #00FFFF" fp-title="Quarter"><img src="menubtns/buttonA.jpg" alt="" name="image3" width="80" height="26" border="0" id="img3" onMouseDown="FP_swapImg(1,0,/*id*/'img3',/*url*/'menubtns/buttonC.jpg')" onMouseUp="FP_swapImg(0,0,/*id*/'img3',/*url*/'menubtns/buttonB.jpg')" onMouseOver="FP_swapImg(1,0,/*id*/'img3',/*url*/'menubtns/buttonB.jpg');MM_showMenu(window.mm_menu_0806091436_0,0,30,null,'image3')" onMouseOut="FP_swapImg(0,0,/*id*/'img3',/*url*/'menubtns/buttonA.jpg');MM_startTimeout();" fp-style="fp-btn: Glow Tab 3; fp-font-size: 9; fp-font-color-normal: #0000FF; fp-font-color-hover: #00FFFF" fp-title="Returns"></div>
<p>&nbsp;</p>
<p>
  <!--[if gte vml 1]><v:line id="_x0000_s1026"
 style='position:absolute;left:0;text-align:left;top:0;z-index:3' from="15.75pt,110.25pt"
 to="738pt,111.75pt" strokecolor="#88b8e8" strokeweight="4.5pt">
 <v:stroke linestyle="thickThin"/>
</v:line><![endif]--><![if !vml]><span style='mso-ignore:vglayout;position:
absolute;z-index:3;left:18px;top:144px;width:969px;height:8px'><img width=969
height=8 src="menutest_files/image001.gif" v:shapes="_x0000_s1026"></span><![endif]></p>
</body>

</html>
