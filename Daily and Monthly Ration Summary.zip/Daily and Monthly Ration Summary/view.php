<?php 
session_start();
include_once ("index.php");
include_once ("function.php");
dbconnect();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>View:: Personal Info</title>

<script type="text/JavaScript" src="scripts/test.js"></script>
 <link href="stylesheets/style.css" rel="stylesheet" type="text/css">
   
<style type="text/css">
    <!--

#Layer1 {
	position:relative;
	left:267px;
	top:0px;
	width:458px;
	height:180px;
	padding: 0px;
	margin: 0px;
}

#srch {
	position:absolute;
	left:11px;
	top:172px;
	width:226px;
	height:85px;
	padding: 0px;
	margin: 0px;
}
 -->
</style>
</head>
<body>
<?php
include_once("search.php");
	switch($_SESSION['unit']) {
			case "27WG":
				$table1 = "personal_info27";
	 	 	 	$table2 = "movement27";
				break;
			case "37SQN":
				$table1 = "personal_info37";
	 	 	 	$table2 = "movement37";
				break;
			case "108SQN":
				$table1 = "personal_info108";
	 	 	 	$table2 = "movement108";
				break;
			case "2201SQN":
				$table1 = "personal_info2201";
	 	 	 	$table2 = "movement2201";
				break;
			case "2224SQN":
				$table1 = "personal_info2224";
	 	 	 	$table2 = "movement2224";
				break;
			case "2254SQN":
				$table1 = "personal_info2254";
	 	 	 	$table2 = "movement2254";
				break;
			case "171SU":
				$table1 = "personal_info171";
	 	 	 	$table2 = "movement171";
				break;
			case "777SU":
				$table1 = "personal_info777";
	 	 	 	$table2 = "movement777";
				break;
			case "853SU":
				$table1 = "personal_info853";
	 	 	 	$table2 = "movement853";
				break;
			case "478MOF":
				$table1 = "personal_info478";
	 	 	 	$table2 = "movement478";
				break;
			case "308TRU":
				$table1 = "personal_info308";
	 	 	 	$table2 = "movement308";
				break;
			case "342TRU":
				$table1 = "personal_info342";
	 	 	 	$table2 = "movement342";
				break;
			case "607GRDFLT":
				$table1 = "personal_info607";
	 	 	 	$table2 = "movement607";
				break;
			}

if(isset($_POST['action']) && $_POST['action'] == 'submitted')
{
$query = "select * from ".$table1." where serno = '$_POST[txtserno]' and unit = '$_SESSION[unit]'";
$result=mysql_query($query) or die(mysql_error());
$row = mysql_fetch_array($result);	
$rows = mysql_num_rows($result);
  if ($rows == 1){
  
  $query1 = "select serno SERVICE,movcode MOVEMENT,sorsdt SORS,torsdt TORS from ".$table2." where serno = $_POST[txtserno] order by movid";

?>
<div id="Layer1">
  <table width="410" border="0" align="center">
  
    <tr class="welcome">
      <th width="404" align="center" valign="top" class="rollmenu" scope="col"><div align="left"> Personal Information &amp; Movements </div></th>
    </tr>
    <tr>
      <th align="center" valign="top" scope="col"><form action="/drss/view.php" method="post" name="frmview" id="frmview" >
          <table width="394" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td width="13" height="12"><img src="/drss/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
              <td colspan="6" background="/drss/images/table_r1_c2.gif"><img src="/drss/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
              <td width="13"><img src="/drss/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
            </tr>
            <tr>
              <td rowspan="6" background="/drss/images/table_r2_c1.gif"><img src="/drss/images/spacer.gif" alt="" name="table_r2_c1" width="1" height="1" border="0" id="table_r2_c1" /></td>
              <td height="24">&nbsp;</td>
              <td><div align="left"><strong>Service No </strong></div></td>
              <td width="75" ><div align="left"><input name="serno" value="<?php echo $row[serno];?>" type="text" size="9" readonly="1" tabindex="1"/></div></td>
              <td width="13">&nbsp;</td>
              <td width="83"><div align="left">Check Sfx </div></td>
              <td width="116"><div align="left"><input name="chksfx" value="<?php echo $row[chksfx];?>" type="text" size="1" readonly="1" tabindex="2"/></div></td>
              <td rowspan="6" background="/drss/images/table_r2_c3.gif."><img src="/drss/images/spacer.gif" alt="" name="table_r2_c3" width="1" height="1" border="0" id="table_r2_c3" /></td>
            </tr>
            <tr>
              <td width="4">&nbsp;</td>
              <td width="77"><div align="left"><strong>Rank</strong></div></td>
              <td><div align="left">
                <input name="rank" value="<?php echo $row[rank];?>" type="text" id="rank" tabindex="3" size="10" readonly="1" />
              </div></td>
              <td>&nbsp;</td>
              <td width="83"><div align="left"><strong>Name</strong></div></td>
              <td width="116"><div align="left"><input name="name" value="<?php echo $row[name];?>" type="text" id="name" tabindex="4" size="20" readonly="1"/></div></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td><div align="left"><strong>Trade</strong></div></td>
              <td><div align="left"><input name="trade" value="<?php echo $row[trade];?>" type="text" id="trade" tabindex="5"  size="10" readonly="1"/></div></td>
              <td>&nbsp;</td>
              <td width="83"><div align="left"><strong>Unit</strong></div></td>
              <td width="116"><div align="left"><input name="unit" value="<?php echo $row[unit];?>" type="text" id="unit" tabindex="6" size="10" readonly="1"/></div></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td><div align="left">status</div></td>
              <td><div align="left">
                <input name="status" value="<?php echo $row[status];?>" type="text" size="10" readonly="1" tabindex="7"/>
             </div></td>
              <td>&nbsp;</td>
              <td width="83"><div align="left">Strength</div></td>
              <td width="116"><div align="left"><input name="type" type="text" size="10" value="<?php echo $row[type];?>" /></div></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td><div align="right"><input name="view" type="hidden" value="viewed" /><img  onclick="submit();"  onmouseout="this.src='/drss/images/btn_submit.gif';" onmouseover="this.src='/drss/images/btn_submit_02.gif';" src="/drss/images/btn_submit.gif" border="0"/></div></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td><img src="/drss/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
              <td colspan="6" background="/drss/images/table_r3_c2.gif"><img src="/drss/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
              <td><img src="/drss/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
            </tr>
          </table>
      </form></th>
    </tr>
  </table>
  </div>

<?php
select_to_goodtable($query1,0,'---'); 
 } 
 else 
 {message("warn.png","Record not available...!!");}
}
dbclose();
?>


