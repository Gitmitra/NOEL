<div id="moleave">
  <table width="621" border="0" align="center">
  
    <tr class="welcome">
      <th width="638" align="center" valign="top" class="rollmenu" scope="col"><div align="left">Movement Out :Leave </div></th>
    </tr>
    <tr>
      <th align="center" valign="top" scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th align="center" valign="top" scope="col"><form action="/drss/movout1.php" method="post" name="frmmovout" id="frmmovout" >
          <table width="566" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td width="13" height="12"><img src="/drss/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
              <td colspan="7" background="/drss/images/table_r1_c2.gif"><img src="/drss/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
              <td width="13"><img src="/drss/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
            </tr>
            <tr>
              <td rowspan="5" background="/drss/images/table_r2_c1.gif"><img src="/drss/images/spacer.gif" alt="" name="table_r2_c1" width="1" height="1" border="0" id="table_r2_c1" /></td>
              <td height="24">&nbsp;</td>
              <td><div align="left"><strong>Service No </strong></div></td>
              <td width="102" ><div align="left"><input name="serno" type="text" id="serno" tabindex="1" size="10" maxlength="10" readonly="1" value="<?php echo $row[serno];?>" /></div></td>
              <td width="90"><div align="left"><strong>Rank</strong></div></td>
              <td width="110"><div align="left"><input name="rank" value="<?php echo $row[rank];?>" type="text" id="rank" tabindex="3" size="10" readonly="1" /></div></td>
              <td width="42"><div align="left"><strong>Name</strong></div></td>
              <td width="114"><div align="left"><input name="name" value="<?php echo $row[name];?>" type="text" id="name" tabindex="4" size="15" readonly="1"/>
              </div></td>
              <td rowspan="5" background="/drss/images/table_r2_c3.gif."><img src="/drss/images/spacer.gif" alt="" name="table_r2_c3" width="1" height="1" border="0" id="table_r2_c3" /></td>
            </tr>
            <tr>
              <td width="6">&nbsp;</td>
              <td width="76"><div align="left">
                <div align="left"><strong>Trade</strong></div>
              </div></td>
              <td><div align="left">
               <input name="trade" value="<?php echo $row[trade];?>" type="text" id="trade" tabindex="5"  size="10" readonly="1"/>
              </div></td>
              <td><div align="left"><strong>Unit</strong></div></td>
              <td width="110"><div align="left"><input name="unit" value="<?php echo $row[unit];?>" type="text" id="unit" tabindex="6" size="10" readonly="1"/></div></td>
              <td width="42"><div align="left">status</div></td>
              <td width="114"><div align="left"><input name="status" value="<?php echo $row[status];?>" type="text" size="10" readonly="1" tabindex="7"/></div></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td><div align="left">Movement</div></td>
              <td><div align="left">
                <input name="movcode" type="text" size="7" readonly="1" value="<?php echo $_POST['movcode'];?>"/>
              </div></td>
              <td><div align="left">From (SORS)</div></td>
              <td width="110"><div align="left"><input name="sorsdt" type="text" size="10" readonly="1"/><input name="Submit" type="button" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frmmovout.sorsdt); return false;" value="..."/>
			  </div></td>
              <td width="42"><div align="left">TORS</div></td>
              <td width="114"><div align="left"><input name="torsdt" type="text" size="10" readonly="1"/><input name="Submit" type="button" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frmmovout.torsdt); return false;" value="..."/></div></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td colspan="6"><div align="left"></div></td>
            </tr>
            
            <tr>
              <td>&nbsp;</td>
              <td colspan="2"><div align="left">Mov Date
                <input name="outdt" type="text" size="10" readonly="1"/>
                <input name="Submit" type="button" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frmmovout.outdt); return false;" value="..."/>
              </div></td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td colspan="2"><div align="right">
                <input name="onleave" type="hidden" value="submitted" />
               	<img border="0" onclick="addmovol();" onmouseout="this.src='/drss/images/btn_save.jpg';" onmouseover="this.src='/drss/images/btn_save_02.jpg';" src="/drss/images/btn_save.jpg" /></div></td>
            </tr>
            <tr>
              <td><img src="/drss/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
              <td colspan="7" background="/drss/images/table_r3_c2.gif"><img src="/drss/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
              <td><img src="/drss/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
            </tr>
          </table>
      </form></th>
    </tr>

    <tr>
      <th align="center" valign="top" scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th align="center" valign="top" scope="col"><p align="center" class="rollmenu">&nbsp;</p></th>
    </tr>
  </table>
</div>

