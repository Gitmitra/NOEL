<?php
session_start();
include_once ("./dao/function.php");
$host = $_SERVER['HTTP_HOST'];
$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra = 'index.php';
$username =$_SESSION['username'] ;
if(empty($_SESSION['user_password'])) 
{
session_destroy();
header("Location: http://$host$uri/$extra");
exit();
}
dbconnect();
if(isset($_GET['complaint']) || $_GET['complaint'] == 'Remarks By Complaint No')
{
	$subdiv = $_GET['subdiv'];
	include_once ("rem_comp.php"); 
	if(isset($_GET['complaint_no']) && $_GET['complaint_no'] == 'send')
	{
		$comno = $_GET['comno'];	
		$remarks = $_GET['remarks'];
		include_once("compno.php");
	}
} 
else 
{
	if(isset($_GET['Remarks']) || $_GET['Remarks'] == 'Block Remarks')
	{
	 $subdiv = $_GET['subdiv'];
	 include_once ("comon_updt.php");
	} 
	else 
	{
	?>
<style type="text/css">
<!--
.style2 {font-size: 12px}
-->
</style>


<table width="650" border="0">
<?php
if(empty($_GET['offset']))
{$offset=0;}
else
{$offset=$_GET['offset'];}
 
$subdiv=$_GET['subdiv'];

$result = mysql_query("select comno,serno,area,sqn,location,fault,subdiv,reminder from complaint where comtype = '$username' and subdiv = '$subdiv' and remarks = 'PENDING' order by no limit $offset, ". 3);
while($row = mysql_fetch_array($result))
{
?>
  <tr>
    <th colspan="10" scope="col"><u>COMPLAINT SLIP</u></th>
  </tr>
  <tr>
    <th colspan="10" scope="row">&nbsp;</th>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <th colspan="4" scope="row"><div align="left"><?php echo $row['subdiv']; ?></div></th>
    <th width="68" scope="row">&nbsp;</th>
    <th colspan="3" scope="row">Reminder:-</th>
    <th scope="row"><div align="left"><?php echo $row['reminder']; ?></div></th>
  </tr>
  <tr>
    <th width="7" scope="row">&nbsp;</th>
    <th width="109" scope="row">&nbsp;</th>
    <td width="61">&nbsp;</td>
    <td width="21">&nbsp;</td>
    <td width="100"><strong>Area:-</strong></td>
    <td colspan="3"><div align="left"><?php echo $row['area']; ?></div></td>
    <td width="81"><strong>Location:-</strong></td>
    <td width="150"><div align="left"><?php echo $row['sqn']; ?></div></td>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <th scope="row"><div align="left">Complaint No:-</div></th>
    <td colspan="2"><?php echo $row['comno']; ?></td>
    <td><strong>Raised By :-</strong> </td>
    <td colspan="2"><?php echo $row['serno']; ?></td>
    <td width="12">&nbsp;</td>
    <td><strong>Bldg No:-</strong></td>
    <td><?php echo $row['location'];?></td>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <th scope="row"><div align="left">Complaint:-</div></th>
    <td colspan="8" rowspan="3" valign="top"><?php echo $row['fault']; ?></td>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <th scope="row">&nbsp;</th>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <th scope="row">&nbsp;</th>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <th scope="row">&nbsp;</th>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <th valign="top" scope="row">&nbsp;</th>
    <th valign="top" scope="row"><div align="left">Signature</div></th>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2"><strong>User Sig</strong> </td>
    <td colspan="2">&nbsp;</td>
    <td><span class="style2">27WG, NET &amp; IT SQN </span></td>
  </tr>
  <tr>
    <th height="26" scope="row">&nbsp;</th>
    <th height="26" colspan="9" scope="row"><hr/></th>
  </tr>
  <tr>
    <th height="3" colspan="10" scope="row"></th>
  </tr>
<?php
 
}
mysql_free_result($result);
?>
</table>
<?php

nav($offset,$username,$subdiv);

}
}
dbclose();
?>