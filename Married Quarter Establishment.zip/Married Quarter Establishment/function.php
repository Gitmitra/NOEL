<?php

function insert_row($table="", $atts="")
{
	if(empty($table) || !is_array($atts))
	{return FALSE;}
	else
	{
		while(list($col,$val) = each($atts))
		{
			//if null go to next array item
			if($val=="")
			{continue;}
			$col_str .= $col . ",";
			if(is_int($val) || is_double($val))
			{
				$val_str .= $val . ",";
			}
			else
			{
				$val_str .= "'$val',";
			}
		}
		$query = "insert into $table ($col_str) values ($val_str)";
		//trimming trailing comma from both strings
		$query = str_replace(",)", ")", $query);
		$result=mysql_query($query) or die(mysql_error());
		return mysql_affected_rows();
		
	}
}

function delete_row($table="",$where="")
{
if(empty($table) || empty($where))
{return FALSE;}
$query = "delete from $table where $where";
mysql_query($query) or die(mysql_error());
return mysql_affected_rows();
}


function update_row($table="", $atts="", $where="")
{
	if (empty($table) || !is_array($atts))
	{ return FALSE; }
	else
	{
		while(list($col,$val) = each($atts))
		{
			if($val=="")
			{continue;}
			if(is_int($val) || is_double($val))
			{
			 $str .= $col ."=" .$val .",";
			}
			elseif($val=="NULL" || $val =="null")
			{
			 $str .= $col ."=NULL,";
			}
			else
			{
			 $str .= $col ."='$val',";
			}
			
		}
	 $str = substr($str, 0, -1);
	 $query = "update $table set $str";
	 if(!empty($where))
	 {
	 $query .= "where $where";
	 }
	 $result=mysql_query($query) or die (mysql_error());
	 return mysql_affected_rows();
	}
}

function select_to_table($query)
{
	$result=mysql_query($query);
	$rows = mysql_num_rows($result);
	if($rows == NULL) {
	echo "<br>\n";
	echo "<table align = center>";
	echo "<tr bgcolor=#00CCFF><td>No records available";
	echo "</td></tr></table>";
	
	} else {
	$number_cols = mysql_num_fields($result);
	echo "<br> \n";
	echo "<table border = 1 align = center bgcolor=#CCFFFF>";
	echo "<tr align=center bgcolor=#00CCFF>\n";
	for ($i=0; $i<$number_cols; $i++)
	{
		$dbfield = strtoupper(mysql_field_name($result,$i));
		echo "<th>".$dbfield. "</th>\n";
	}
	echo "</tr>\n";
	while ($row = mysql_fetch_row($result))
	{
		echo "<tr align=left>\n";
		for ($i=0; $i<$number_cols; $i++)
		{
		echo "<td>";
			if(!isset($row[$i]))
			{echo "NULL";}
			else
			{echo $row[$i];}
			echo "</td>\n";
		}echo "</tr>\n";
	}echo "</table>";
 }
}


function delete_from_table($query)
{
	$result=mysql_query($query);
	$number_cols = mysql_num_fields($result);
	echo "<br> \n";
	echo "<br> \n";
	echo "<br> \n";
	echo "<br> \n";
	echo "<table border = 1 align = center bgcolor=#CCFFFF>";
	echo "<tr align=center bgcolor=#00CCFF>\n";
	for ($i=0; $i<$number_cols; $i++)
	{
		$dbfield = strtoupper(mysql_field_name($result,$i));
		echo "<th>".$dbfield. "</th>\n";
	}
	echo "<th>";
	echo "DELETE";
	echo "</th>\n";
	echo "</tr>\n";
	while ($row = mysql_fetch_array($result))
	{
		echo "<tr align=left>\n";
		for ($i=0; $i<$number_cols; $i++)
		{
			echo "<td>";
			if(!isset($row[$i]))
			{echo "NULL";}
			else
			{echo $row[$i];}
			echo "</td>\n";
		}
		echo "<td><input type=checkbox name=regno[] value=".$row[regno].">Yes, allot to".$row[regno]."</td>\n";
		echo "</tr>\n";
	}echo "</table>";	
}

function message($pic="",$str="")
{
	for($i=0;$i<7;$i++)
	{
		echo "<br>\n";
	}
	 	echo "<table align = center>";
        echo "<tr><td><img src=icons/".$pic." align=middle/></td><td><strong>".$str;
		echo "</strong></td></tr></table>";
}

?>