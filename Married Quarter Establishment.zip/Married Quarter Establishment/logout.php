<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Logout</title>
</head>

<body>
</body>
</html>
<?php
include_once("conn.php");
session_start();

			$UpdateRecords = "UPDATE user SET last_logout = NOW()";
 			$result = mysql_query($UpdateRecords) or die(mysql_error());

// Unset all of the session variables.
$_SESSION = array();

// If it's desired to kill the session, also delete the session cookie.
// Note: This will destroy the session, and not just the session data!
if (isset($_COOKIE[session_name()])) {
   setcookie(session_name(), '', time()-42000, '/');
}


	// Destroy Sessions
			setcookie ("USERNAME", "",0,'/');
			setcookie ("PASSWORD", "",0,'/');
        	$USERNAME ="";
        	$PASSWORD ="";

// Finally, destroy the session.
session_destroy();
mysql_close($con);
header("Location: http://www.27wg.iaf.in/");
exit;
?>