
<div id="movement">
  <table width="525" border="0" align="center">
  
    <tr class="welcome">
      <th width="464" align="center" valign="top" class="rollmenu" scope="col"><div align="left">Movement In </div></th>
    </tr>
    <tr>
      <th align="center" valign="top" scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th align="center" valign="top" scope="col"><form action="/drss/movin1.php" method="post" name="frmmovin" id="frmmovin" >
          <table width="541" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td width="13" height="12"><img src="/drss/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
              <td colspan="7" background="/drss/images/table_r1_c2.gif"><img src="/drss/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
              <td width="13"><img src="/drss/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
            </tr>
            <tr>
              <td rowspan="6" background="/drss/images/table_r2_c1.gif"><img src="/drss/images/spacer.gif" alt="" name="table_r2_c1" width="1" height="1" border="0" id="table_r2_c1" /></td>
              <td height="24">&nbsp;</td>
              <td><div align="left"><strong>Service No </strong></div></td>
              <td width="93" ><div align="left"><input name="serno" type="text" id="serno" tabindex="1" size="10" maxlength="10" readonly="1" value="<?php echo $row[serno];?>"/></div></td>
              <td width="45"><div align="left"><strong>Rank</strong></div></td>
              <td width="114"><div align="left"><input name="rank" value="<?php echo $row[rank];?>" type="text" id="rank" tabindex="3" size="10" readonly="1" /></div></td>
              <td width="69"><div align="left"><strong>Name</strong></div></td>
              <td width="110"><div align="left"><input name="name" value="<?php echo $row[name];?>" type="text" id="name" tabindex="4" size="15" readonly="1"/>
              </div></td>
              <td rowspan="6" background="/drss/images/table_r2_c3.gif."><img src="/drss/images/spacer.gif" alt="" name="table_r2_c3" width="1" height="1" border="0" id="table_r2_c3" /></td>
            </tr>
            <tr>
              <td width="7">&nbsp;</td>
              <td width="77"><div align="left">
                <div align="left"><strong>Trade</strong></div>
              </div></td>
              <td><div align="left">
               <input name="trade" value="<?php echo $row[trade];?>" type="text" id="trade" tabindex="5"  size="10" readonly="1"/>
              </div></td>
              <td><div align="left"><strong>Unit</strong></div></td>
              <td width="114"><div align="left"><input name="unit" value="<?php echo $row[unit];?>" type="text" id="unit" tabindex="6" size="10" readonly="1"/></div></td>
              <td width="69"><div align="left">status</div></td>
              <td width="110"><div align="left"><input name="status" value="<?php echo $row[status];?>" type="text" size="10" readonly="1" tabindex="7"/></div></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td><div align="left">Movement</div></td>
              <td><div align="left">
                <input name="movcode" type="text" size="7" readonly="1" value="<?php echo $row1[movcode];?>"/>
              </div></td>
              <td><div align="left">SORS </div></td>
              <td width="114"><div align="left"><input name="sors" type="text" size="10" value="<?php echo $row1[sorsdt];?>"  readonly="1"/>
			  </div></td>
              <td width="69">&nbsp;</td>
              <td width="110"></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td><div align="left">Strength</div></td>
              <td><div align="left"><input name="type" type="text" size="10" maxlength="10" value="<?php echo $row[type];?>" readonly="1"/></div></td>
              <td><div align="left">TORS</div></td>
			  <?php  if ($row1[movcode] == 'LEAVE') {?>
			  <td width="114"><div align="left"><input name="torsdt" type="text" size="10" value="<?php echo $row1[torsdt];?>"  readonly="1"/>
			  <input name="Submit" type="button" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frmmovin.torsdt); return false;" value="..."/></div></td>
			  <?php } else {?>
			  <td width="114"><div align="left"><input name="torsdt" type="text" size="10" maxlength="10" readonly="1"/>
			  <input name="Submit" type="button" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frmmovin.torsdt); return false;" value="..."/></div></td>
			  <?php } ?>
			  <td width="69"><div align="left">Mov Date</div></td>
              <td width="110"><div align="left"><input name="indt" type="text" size="10" maxlength="10" readonly="1"/>
			  <input name="Submit" type="button" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frmmovin.indt); return false;" value="..."/></div></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td colspan="2"><div align="right"></div></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td colspan="2"><div align="right">
                <input name="movein" type="hidden" value="submitted" />
               	<img border="0" onclick="addMov();" onmouseout="this.src='/drss/images/btn_save.jpg';" onmouseover="this.src='/drss/images/btn_save_02.jpg';" src="/drss/images/btn_save.jpg" /></div></td>
            </tr>
            <tr>
              <td><img src="/drss/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
              <td colspan="7" background="/drss/images/table_r3_c2.gif"><img src="/drss/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
              <td><img src="/drss/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
            </tr>
          </table>
      </form></th>
    </tr>

    <tr>
      <th align="center" valign="top" scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th align="center" valign="top" scope="col"><p align="center" class="rollmenu">&nbsp;</p></th>
    </tr>
  </table>
</div>
