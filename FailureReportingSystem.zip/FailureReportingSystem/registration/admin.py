from django.contrib import admin
from .models import userdetail, fault, catD, spare

# Register your models here.
@admin.register(userdetail)
class UserAdmin(admin.ModelAdmin):
    list_display = [field.name for field in userdetail._meta.get_fields()]

@admin.register(fault)
class FaultAdmin(admin.ModelAdmin):
    list_display = [field.name for field in fault._meta.get_fields()]

@admin.register(spare)
class SpareAdmin(admin.ModelAdmin):
    list_display = [field.name for field in spare._meta.get_fields()]

@admin.register(catD)
class CatdAdmin(admin.ModelAdmin):
    list_display = [field.name for field in catD._meta.get_fields()]