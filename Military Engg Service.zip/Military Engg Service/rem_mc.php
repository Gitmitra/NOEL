<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>On-line MES Complaint</title>
	<meta http-equiv="Content-Language" content="English" />
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
	<meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="expires" content="-1" />
</script>
    	<link href="mes.css" rel="stylesheet" type="text/css" />

</head>
<body>

<div id="container">
   <div id="container-header"><div id="container-name"><span>On-line </span>MES Complaint </div></div>
   <div id="container-eyecatcher"><img src="images/business_eyecatcher.jpg" width="668" height="138" /></div>
   <div id="container-content">
	
		    <h1>Remarks by Maint Cell</h1>
			<hr/>
<?php
session_start();
$host = $_SERVER['HTTP_HOST'];
$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra = 'index.php';
$username =$_SESSION['username'] ;
if(empty($_SESSION['user_password'] )) 
{
session_destroy();
header("Location: http://$host$uri/$extra");
exit();
}
include_once ("./dao/function.php");
dbconnect();
if(isset($_GET['feedbk']) && $_GET['feedbk'] == 'Submit')
{
$query = "select date_format(comdt,'%d-%b-%Y') `comp dt`,comno,fault,rem_by_user,remarks `rem by MES` from complaint where comdt between str_to_date('$_GET[fdbkfm]','%d-%m-%Y') and str_to_date('$_GET[fdbkto]','%d-%m-%Y') and remarks = 'DONE' and rem_by_user is not null order by comdt";
?>
<form name="form1" method="post" action="./process.php">
<?php
 	ob_start();
  rem_by_users($query,1,2);
	$data=ob_get_contents();
	$fp=fopen("feedback.html","w");
	fwrite($fp,$data);
	fclose($fp);
	ob_end_flush();
		 //Converting HTML file format into PDF format
	include_once("dao/html2fpdf.php");
	$pdf=new HTML2FPDF();
	$pdf->AddPage();
	$fp1 = fopen("feedback.html","r");
	$strContent = fread($fp1, filesize("feedback.html"));
	fclose($fp1);
	$pdf->WriteHTML($strContent);
	$pdf->Output("feedback.pdf");
?><p>
<a href=subdiv.php><img border="0" onmouseout="this.src='images/btn_back.jpg';" onmouseover="this.src='images/btn_back_02.jpg';" src="images/btn_back.jpg" /></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=feedback.pdf>Print</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	
<input type="submit" name="Submit" value="Clear" /></p>
</form>
<?php
dbclose();
}
?>
 	<hr/>
  </div> <!-- END of container-content -->
</div> <!-- END of container -->
</body>
</html>
