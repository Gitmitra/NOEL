<div id="serno">
  <table width="270" border="0" align="center">

    <tr>
      <th width="264" align="center" valign="top" scope="col"><form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" name="frmsearch" id="frmsearch" onsubmit="addsearch();">
          <table width="231" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td width="13" height="12"><img src="../drss/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
              <td colspan="6" background="../drss/images/table_r1_c2.gif"><img src="../drss/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
              <td width="13"><img src="../drss/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
            </tr>
            <tr>
              <td background="../drss/images/table_r2_c1.gif">&nbsp;</td>
              <td colspan="5">Service No </td>
              <td><div align="left"><input name="txtserno" type="text" size="10" maxlength="10" />
              </div></td>
              <td background="../drss/images/table_r2_c3.gif.">&nbsp;</td>
            </tr>
            <tr>
              <td background="../drss/images/table_r2_c1.gif">&nbsp;</td>
              <td colspan="5">Personal Info 
              <input name="radiobutton" type="radio" value="personal" /></td>
              <td>Movement 
              <input name="radiobutton" type="radio" value="movement" /></td>
              <td background="../drss/images/table_r2_c3.gif.">&nbsp;</td>
            </tr>
            <tr>
              <td background="../drss/images/table_r2_c1.gif"><img src="../drss/images/spacer.gif" alt="" name="table_r2_c1" width="1" height="1" border="0" id="table_r2_c1" /></td>
              <td colspan="5">&nbsp;</td>
              <td width="85"><div align="right"><input name="action" type="hidden" value="submitted" /><img onmouseout="this.src='/drss/images/btn_search.jpg';" onmouseover="this.src='/drss/images/btn_search_02.jpg';" src="/drss/images/btn_search.jpg"border="0" onclick="addsearch();"/></div></td>
              <td background="../drss/images/table_r2_c3.gif."><img src="../drss/images/spacer.gif" alt="" name="table_r2_c3" width="1" height="1" border="0" id="table_r2_c3" /></td>
            </tr>
            <tr>
              <td><img src="../drss/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
              <td colspan="6" background="../drss/images/table_r3_c2.gif"><img src="../drss/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
              <td><img src="../drss/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
            </tr>
          </table>
      </form></th>
    </tr>
  </table>
</div>
<table width="100%" height="131" border="0">
  <tr>
    <td height="127" colspan="3">&nbsp;</td>
  </tr>
</table>

