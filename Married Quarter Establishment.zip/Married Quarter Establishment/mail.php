<?php
session_start();
$username=$_SESSION['user_logged'];
if(empty($username)) 
{
$host = $_SERVER['HTTP_HOST'];
$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra = 'login.php';
header("Location: http://$host$uri/$extra");
exit();
}
include_once ('menutest.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link href="stylesheets/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<table width="514" border="0" align="center" cellspacing="1">
  <tr>
    <td><p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td width="522"><form id="form1" name="form1" method="post" action="<?php echo $_SERVER[PHP_SELF]?>">
      <table width="510" border="0" align="left" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="12"><img src="/status/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
          <td colspan="8" background="/status/images/table_r1_c2.gif"><img src="/status/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
          <td width="18"><img src="/status/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
        </tr>
        <tr>
          <td rowspan="13" background="/status/images/table_r2_c1.gif"><img src="/status/images/spacer.gif" alt="" name="table_r2_c1" width="1" height="1" border="0" id="table_r2_c1" /></td>
          <td width="8">&nbsp;</td>
          <td width="55">To</td>
          <td width="4" height="24">:</td>
          <td width="406"><input type="text" name="txtto" value="750150@27wg.iaf.in"/></td>
          <td width="4">&nbsp;</td>
          <td width="4">&nbsp;</td>
          <td width="4">&nbsp;</td>
          <td width="4">&nbsp;</td>
          <td rowspan="13" background="/status/images/table_r2_c3.gif."><img src="/status/images/spacer.gif" alt="" name="table_r2_c3" width="1" height="1" border="0" id="table_r2_c3" /></td>
        </tr>
        <tr></tr>
        <tr></tr>
        <tr></tr>
        <tr></tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>From</td>
          <td>:</td>
          <td><input type="text" name="txtfrom" value="750150@27wg.iaf.in"/></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Subject</td>
          <td>:</td>
          <td><input type="text" name="txtsub" value="Monthly Return"/></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Message</td>
          <td>:</td>
          <td><textarea name="txtmsg" cols="65" rows="10"></textarea></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>        
          <td>&nbsp;</td>
          <td><input name="Submit" type="submit" class="rollmenu" value="Send" /></td>
        </tr>
        <tr>
          <td><img src="/status/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
          <td colspan="8" background="/status/images/table_r3_c2.gif"><img src="/status/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
          <td><img src="/status/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
        </tr>
      </table>
    </form>    </td>
  </tr>
</table>
</body>

</html>
<?php 
if($_POST['Submit']){

//Declarate the necessary variables
$mail_to=$_POST['txtto'];
$mail_from=$_POST['txtfrom'];
$mail_sub=$_POST['txtsub'];
$mail_mesg=$_POST['txtmsg'];
$headers ="From:$mail_from";
//Check for success/failure of delivery 
if(mail($mail_to,$mail_sub,$mail_mesg,$headers))
{echo "E-mail has been sent successfully to $mail_to";}
else
{echo "Failed to send the E-mail to $mail_to";}
}


?> 

