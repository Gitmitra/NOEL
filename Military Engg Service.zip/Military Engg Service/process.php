<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
session_start();
$host = $_SERVER['HTTP_HOST'];
$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra = 'index.php';
if(empty($_SESSION['start'])) 
{
session_destroy();
header("Location: http://$host$uri/$extra");
exit();
}
include_once("dao/function.php"); 
/*if ((!preg_match("/156.84.1./", $_SERVER['REMOTE_ADDR'])) and (!preg_match("/155.83./",$_SERVER['REMOTE_ADDR']))) 
{message("Access denied to Outstations.....!");
exit();
}*/
dbconnect();
?>
<head>
    <title>On-line MES Complaint</title>
	<meta http-equiv="Content-Language" content="English" />
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
    <meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="expires" content="-1" />

<link href="mes.css" rel="stylesheet" type="text/css" />
	 <style type="text/css">
<!--
.style4 {color: #006AC3; font-weight: bold; }
-->
</style>
</head>
<body>
<div id="container">
   <div id="container-header"><div id="container-name"><span>On-line </span>MES Complaint </div></div>
   <div id="container-eyecatcher"><img src="images/business_eyecatcher.jpg" alt="" width="668" height="138" /></div>
   <div id="container-content">
     <div id="border-process">
	 <?php
	if(isset($_POST['Submit']) && $_POST['Submit'] == 'Register') 
	{
		$comdt = date("Y/m/d");
		$serno = $_POST['serno'];
		$area = $_POST['area'];
		$sqn = $_POST['sqn'];
		$location = $_POST['location'];
		$fault = $_POST['fault'];
		$comtype = $_POST['type'];
		  if ($comtype == 'EM')
		  {$subdiv = $_POST['EM'];}
		  else
		  {$subdiv = $_POST['BR'];}
		$reminder = '0';
		$reminderdt = date("Y/m/d");
		$remarks = 'PENDING';
			
			$result = mysql_query("select comdt,no from complaint where cid = (select max(cid) from complaint)");
			$rec = mysql_fetch_array($result);
			$yr = substr($rec[0],2,2);
			$no = $rec[1];
			if (date("y") == $yr)
			{ $no = $no + 1; }
			else
			{ $no = 1;}
			$comno = date("y")."-".$no;
			$array=compact("comdt","no","comno","serno","area","sqn","location","fault","comtype","subdiv","reminder","reminderdt","remarks");
			
			if (insert_row(complaint,$array))
			{
			message("Your complaint is successfully registered...!!", "Your Complaint No is ".$comno);
			}
		   echo "<a href=index.php><img src=images/first.gif width=32 height=32 border=0 /></a>";
		
	}

	if(isset($_POST['hidefld']) && $_POST['hidefld'] == 'Submit')
	{
		if(empty($_POST['txtvalue']))
		{header("Refresh: 0; URL=http://$host$uri/status.php");} /* Redirect browser */
		else
		{
		$val = $_POST['txtvalue'];
			if($_POST['choose'] == 'comno')
			{
			$query = "Select comno `com no`,date_format(comdt,'%d-%b-%Y') `complaint date`,fault `complaint`,remarks,date_format(reminderdt,'%d-%b-%Y') `reminder date`,reminder `remin der` from complaint
				 where comno = '$val'";
			select_to_table($query,1,2);
			}
			if($_POST['choose'] == 'serno')
			{
			$query = "Select comno `com no`,date_format(comdt,'%d-%b-%Y') `complaint date`,fault `complaint`,remarks,date_format(reminderdt,'%d-%b-%Y') `reminder date`,reminder `remin der` from complaint
				 where serno = $val";
			select_to_table($query,1,2);
			}
		echo "<p><a href=index.php><img src=images/first.gif width=32 height=32 border=0 /></a></p>";
		}
	}
	
	if(isset($_GET['reminder']) && $_GET['reminder'] == 'send')
	{
	
	$comno = $_GET['comno'];
	$result = mysql_query("select reminder,reminderdt,subdiv from complaint where comno = '$comno' and remarks in ('PENDING','UNDER PROGRESS','DOOR LOCKED')");
	$rows = mysql_num_rows($result);
	$reminder = mysql_fetch_array($result);
	$result1 = mysql_query("SELECT date_add(date_format('$reminder[1]','%Y-%m-%d'), interval 7 day)");
	$result2 = mysql_query("SELECT date_add(date_format('$reminder[1]','%Y-%m-%d'), interval 2 day)");
	$day1 = mysql_fetch_array($result1);	
	$day2 = mysql_fetch_array($result2);	
	  if($rows == 1) 
	  {  
		if($day1[0] <= date("Y-m-d"))
		{
		  $reminder = $reminder[0] + 1;
		  mysql_query("update complaint set reminderdt = curdate(),reminder = $reminder,remarks = 'PENDING' where comno = '$comno'");
		  message("Reminder is sent for Complaint No - ".$comno);
		  header("Refresh: 4; URL=http://$host$uri/$extra"); /* Redirect browser */
		}
	    else
		{
			if($day2[0] <= date("Y-m-d") && ($reminder[2] == 'EXTERNAL WATER SUPPLY' || $reminder[2] == 'SANITARY/DRAIN/SEWAGE')) 
			{
				$reminder = $reminder[0] + 1;
		  		mysql_query("update complaint set reminderdt = curdate(),reminder = $reminder,remarks = 'PENDING' where comno = '$comno'");
		  		message("Reminder is sent for Complaint No - ".$comno);
		  		header("Refresh: 4; URL=http://$host$uri/$extra"); /* Redirect browser */
			}
			else		
			{
		  		message("Reminder date is not due");
		  		header("Refresh: 2; URL=http://$host$uri/$extra"); /* Redirect browser */
			}
		}
	   }
	   else
	   {
	   		message("Reminder can not be sent");
		  	header("Refresh: 2; URL=http://$host$uri/$extra"); /* Redirect browser */
	   }
	
	}
	
	if(isset($_GET['show']) && $_GET['show'] == 'submitted')
	{
	 if(empty($_SESSION['user_password'])) 
	 {
		session_destroy();
		header("Location: http://$host$uri/$extra");
		exit();
	 }
	 $sqn = $_GET['sqn'];
	 $query = "Select comno `com no`,date_format(comdt,'%d-%b-%Y') `complaint date`,serno `ser no`,fault `complaint`,remarks from complaint where area = 'TECHNICAL' and sqn = '$sqn' and remarks in ('PENDING','UNDER PROGRESS')";
		 //creating an output file in HTML format
		 ob_start();
			select_for_cdr($query,1,2,$sqn);
		 $data=ob_get_contents();
		 $fp=fopen("file.html","w");
		 fwrite($fp,$data);
		 fclose($fp);
		 ob_end_flush();
		 //Converting HTML file format into PDF format
		 include_once("dao/html2fpdf.php");
		$pdf=new HTML2FPDF();
		$pdf->AddPage();
		$fp1 = fopen("file.html","r");
		$strContent = fread($fp1, filesize("file.html"));
		fclose($fp1);
		$pdf->WriteHTML($strContent);
		$pdf->Output("complaint.pdf");
		  
		
	echo "<p><a href=subdiv.php><img src=images/first.gif width=32 height=32 border=0 /></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=complaint.pdf>Print Preview</a></p>";
	}
	
	if(isset($_POST['urremarks']) && $_POST['urremarks'] == 'Submit')
	{
	  $comno = $_GET['comno'];
	  $rem_by_user = $_POST['feedback'];
	  $array = compact("$rem_by_user");
	mysql_query("update complaint set rem_by_user = '$rem_by_user' where comno='$comno'");
	 
			message("Your feedback is submitted to Maintenance Cell...!!");
	
		   echo "<a href=index.php><img src=images/first.gif width=32 height=32 border=0 /></a>";
	}  
	
	if(isset($_POST['Submit']) && $_POST['Submit'] == 'Clear')
	{
		if($_REQUEST[comno]){
		while(list($key,$value) = each($_REQUEST[comno]))
		{
			message("Remarks of user's complaint no  $value  is cleared");
			mysql_query("update complaint set rem_by_user = null where comno = '$value'");
		}}
		else
		{message("Please tick the checkbox ...");}
		echo "<a href=subdiv.php><img src=images/first.gif width=32 height=32 border=0 /></a>";
	}
dbclose();
		?>
	</div>
   </div> 
   <!-- END of container-content -->
</div> <!-- END of container -->
</body>
</html>
