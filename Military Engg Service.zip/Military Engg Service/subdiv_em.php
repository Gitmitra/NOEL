  <div id="container-content">
	
		    <h1 align="left">Sub-Division of E & M Complaint		    </h1>
			<hr/>
	   <form id="form1" method="get" action="./prview.php">
	   <table width="684" border="0" align="center">
  <tr>
    <th width="91" scope="row"><div align="left">Date</div></th>
    <th width="5" scope="row">:</th>
    <td colspan="2"><strong><?php echo date("d-M-Y");?></strong></td>
    <td><strong>Complaints</strong></td>
    <td width="79"><p><strong>Complaints Pending </strong></p>      </td>
    <td width="79"><strong>Complaints Under Prg </strong></td>
  </tr>
  <tr>
    <th scope="row"><div align="left"></div></th>
    <th scope="row">&nbsp;</th>
    <td colspan="2">&nbsp;</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <th scope="row"><div align="left">Sub-Division </div></th>
    <th scope="row">:</th>
    <td colspan="2"><select name="subdiv">
      <option value="ELECTRICAL WORK">ELECTRICAL WORK</option>
      <option value="ACs">ACs</option>
      <option value="EXTERNAL WATER SUPPLY">EXTERNAL WATER SUPPLY</option>
      <option value="GYSER">GYSER</option>
	  <option value="MISCELLANEOUS">MISCELLANEOUS</option>
    </select></td>
    <td width="209">ELECTRICAL WORK</td>
    <td style="color:#FF0000"><div align="center"><strong><?php echo $comp[0][0] ?></strong></div></td>
    <td style="color: #339900"><div align="center"><strong><?php echo $comp[5][0]+$comp[10][0] ?></strong></div></td>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <th scope="row">&nbsp;</th>
    <td colspan="2">&nbsp;</td>
    <td>ACs</td>
    <td style="color:#FF0000"><div align="center"><strong><?php echo $comp[1][0] ?></strong></div></td>
    <td style="color: #339900"><div align="center"><strong><?php echo $comp[6][0]+$comp[11][0] ?></strong></div></td>
  </tr>
  <tr>
    <th valign="top" scope="row">&nbsp;</th>
    <th valign="top" scope="row">&nbsp;</th>
    <td colspan="2"><a href="passwd.php"><img src="images/passwd.gif" width="137" height="20" border="0" /></a></td>
    <td>EXTERNAL WATER SUPPLY</td>
    <td style="color:#FF0000"><div align="center"><strong><?php echo $comp[2][0] ?></strong></div></td>
    <td style="color: #339900"><div align="center"><strong><?php echo $comp[7][0]+$comp[12][0] ?></strong></div></td>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <th scope="row">&nbsp;</th>
    <td colspan="2">&nbsp;</td>
    <td>GYSER</td>
    <td style="color:#FF0000"><div align="center"><strong><?php echo $comp[3][0] ?></strong></div></td>
    <td style="color: #339900"><div align="center"><strong><?php echo $comp[8][0]+$comp[13][0] ?></strong></div></td>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <th scope="row">&nbsp;</th>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>MISCELLANEOUS</td>
    <td style="color:#FF0000"><div align="center"><strong><?php echo $comp[4][0] ?></strong></div></td>
    <td style="color: #339900"><div align="center"><strong><?php echo $comp[9][0]+$comp[14][0] ?></strong></div></td>
  </tr>
  <tr>
    <th scope="row"><a href="logout.php"><img src="images/logout_btn.jpg" alt="" width="58" height="19" border="0" /></a></th>
    <th scope="row">&nbsp;</th>
    <td width="95"><input type="submit" name="Submit" value="Print Preview" /></td>
    <td width="96"><input type="submit" name="Remarks" value="Block Remarks" /></td>
    <td colspan="3"><input name="complaint" type="submit" id="complaint" value="Remarks By Complaint No" /></td>
    </tr>
</table>
       </form>
	 <hr/> 
  </div> <!-- END of container-content -->
	