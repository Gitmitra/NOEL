<?php
session_start();
include_once ('index.php');
include_once ('function.php');

?>
<title>e-mail to SWO,27WG</title>
 <link href="stylesheets/style.css" rel="stylesheet" type="text/css">
<script type="text/JavaScript" src="scripts/test.js"></script>
<body>
<table width="352" border="0" align="center">
  <tr>
    <th width="523" align="center" valign="top" scope="col"><p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p></th>
  </tr>
  <tr>
    <th align="center" valign="top" scope="col"><form name="frmmail" action="/drss/movout1.php" method="post" enctype="multipart/form-data" >
      <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="12"><img src="../drss/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
          <td colspan="4" background="../drss/images/table_r1_c2.gif"><img src="../drss/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
          <td width="13"><img src="../drss/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
        </tr>
        <tr>
          <td height="26" background="../drss/images/table_r2_c1.gif"></td>
          <td width="44"><div align="left">To</div></td>
          <td width="148"><div align="left"><input type="text" name="txtto" value="swo@27wg.iaf.in" /></div></td>
          <td width="53"><div align="left">From</div></td>
          <td width="193"><div align="left">
            <input type="text" name="txtfrom" />
          </div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="28" background="../drss/images/table_r2_c1.gif"></td>
          <td><div align="left">Subject</div></td>
          <td colspan="3"><div align="left">
            <input type="text" name="txtsub" value="DRSS"/>
          </div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="26" background="../drss/images/table_r2_c1.gif"></td>
          <td>Attachment</td>
          <td colspan="3"><div align="left"><input type="file" name="uploaded_file" size="20"/></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="91" background="../drss/images/table_r2_c1.gif"></td>
          <td><div align="left">Message</div></td>
          <td colspan="3"><div align="left"><textarea name="txtmsg" cols="75" rows="5"></textarea></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td background="../drss/images/table_r2_c1.gif"></td>
          <td>&nbsp;</td>
          <td colspan="3"><div align="right"><input name="mail" type="submit" class="rollmenu" value="Send" onClick="mail()"/></div></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        
        <tr>
          <td><img src="../drss/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
          <td colspan="4" background="../drss/images/table_r3_c2.gif"><img src="../drss/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
          <td><img src="../drss/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
        </tr>
      </table>
        </form></th>
  </tr>
</table>
</body>
</html>
 



