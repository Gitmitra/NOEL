 <?php 

include_once ('menutest.php');
include_once ('conn.php');
session_start();
$query = "select * from user where username = '$_SESSION[user_logged]'";
$result = mysql_query($query) or die(mysql_error());
$row = mysql_fetch_array($result);


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Change Password</title>
<link href="stylesheets/style.css" rel="stylesheet" type="text/css" />
<script type="text/JavaScript">
<!--
function clearAll() {
		document.frmpwd.txtop.value= '';
		document.frmpwd.txtnp.value= '';
		document.frmpwd.txtcp.value= '';
			}

function addSave()
	{
 			if(document.frmpwd.txtop.value=='') {
            alert("Please specify the Old Password");
            document.frmpwd.txtop.focus();
            return false;
        }

        if (document.frmpwd.txtnp.value == '') {
            alert ("Please specify the New Password");
            document.frmpwd.txtnp.focus();
			return false;
        }
		if (document.frmpwd.txtcp.value == '') {
            alert ("Please confirm the New Password");
            document.frmpwd.txtcp.focus();
			return false;
        }
			document.frmpwd.submit();
	}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>
<body onLoad="MM_preloadImages('images/btn_save_02.jpg','images/btn_clear_02.jpg')">
<table width="324" border="0" align="center" cellspacing="1">
  <tr>
    <th width="393" scope="col"><p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
    <p>&nbsp;</p></th>
  </tr>
  <tr>
    <td class="welcome"><div align="center">Change your password </div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><table width="320" border="0" cellspacing="1">
      <tr>
        <td width="316"><form id="form1" name="frmpwd" method="post" action="/status/passwd.php?SAVE=subt">
            <table width="314" border="0" align="left" cellpadding="0" cellspacing="0">
              <tr>
                <td width="13" height="12"><img src="/status/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
                <td colspan="8" background="/status/images/table_r1_c2.gif"><img src="/status/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
                <td width="13"><img src="/status/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
              </tr>
              <tr>
                <td rowspan="9" background="/status/images/table_r2_c1.gif"><img src="/status/images/spacer.gif" alt="" name="table_r2_c1" width="1" height="1" border="0" id="table_r2_c1" /></td>
                <td><strong>Username</strong></td>
                <td height="24">&nbsp;</td>
                <td colspan="2"><input name="txtname" type="text" readonly="1" value="<?php echo $_SESSION['user_logged'] ?>" /></td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td rowspan="9" background="/status/images/table_r2_c3.gif."><img src="/status/images/spacer.gif" alt="" name="table_r2_c3" width="1" height="1" border="0" id="table_r2_c3" /></td>
              </tr>
              <tr>
                <td><strong>Old Password </strong></td>
                <td height="24">&nbsp;</td>
                <td colspan="2"><input type="password" name="txtop" /></td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><strong>New Password </strong></td>
                <td height="24">&nbsp;</td>
                <td colspan="2"><input type="password" name="txtnp" /></td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td width="114"><strong>Cnfm Password</strong> </td>
                <td width="4" height="24">&nbsp;</td>
                <td colspan="2"><input type="password" name="txtcp" /></td>
                <td width="4">&nbsp;</td>
                <td width="4">&nbsp;</td>
                <td width="4">&nbsp;</td>
                <td width="4">&nbsp;</td>
              </tr>
              <tr></tr>
              <tr></tr>
              <tr></tr>
              <tr></tr>
              <tr>
                <td></td>
                <td>&nbsp;</td>
                <td width="89"><a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('save','','images/btn_save_02.jpg',1)"><img src="images/btn_save.jpg" name="save" width="61" height="22" border="0" id="save" onclick="addSave();" /></a></td>
                <td width="65"><a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('clear','','images/btn_clear_02.jpg',1)"><img src="images/btn_clear.jpg" name="clear" width="65" height="20" border="0" id="clear" onclick="clearAll();" /></a></td>
              </tr>
              <tr>
                <td><img src="/status/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
                <td colspan="8" background="/status/images/table_r3_c2.gif"><img src="/status/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
                <td><img src="/status/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
              </tr>
            </table>
        </form></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td class="welcome">&nbsp;</td>
  </tr>
</table>
</body>
</html>
<?php

if($_GET['SAVE']) {
	if ($_POST['txtop'] != $row[password])
	{
	echo "<br>\n";
	echo "<br>\n";
	echo "<table align = center>";
	echo "<tr><td><img src=images/27w-final2c-copy.gif width=83 height=50 align=middle/></td><td><strong>Old password is wrong";
	echo "</strong></td></tr></table>";
	}
	else 
	{
		if ($_POST['txtnp'] != $_POST['txtcp'])
		{
		echo "<br>\n";
		echo "<br>\n";
		echo "<table align = center>";
		echo "<tr><td><img src=images/27w-final2c-copy.gif width=83 height=50 align=middle/></td><td><strong>New password is not matched";
		echo "</strong></td></tr></table>";
		}
		else
		{
		mysql_query("update user set password = '$_POST[txtnp]' where username = '$_SESSION[user_logged]'");
		echo "<br>\n";
		echo "<br>\n";
		echo "<table align = center>";
		echo "<tr><td><img src=images/27w-final2c-copy.gif width=83 height=50 align=middle/></td><td><strong>Password changed successfully";
		echo "</strong></td></tr></table>";
		
		header ("Refresh: 2; URL=http://156.84.1.136/status/main.php");
		}
	}
}
?> 