function login()
	{
 			
        if (document.frmlogin.txtPwd.value == '') {
            alert ("Please specify the Password");
            document.frmlogin.txtPwd.focus();
			return false;
        }
		document.frmlogin.submit();
	}

function mail()
{
		if(document.frmmail.txtto.value == '' || document.frmmail.txtfrom.value == '' ||document.frmmail.txtsub.value == '' ||document.frmmail.txtmsg.value == ''){
			alert("Please don't leave any box empty.");
			return false;
		}
		document.frmmail.submit();
}

function addsearch()
{
	 	if (sernoOK() == false) 
		{
			document.frmsearch.action.value = "";
			document.frmsearch.txtserno.focus();
			return false;
		}
/*
		if (!numeric(document.frmsearch.txtserno)) 
		{
			alert("Should Be Numeric !");
			document.frmsearch.txtserno.focus();
			return false;
		}
*/
		if (document.frmsearch.txtserno.value == '') {
            alert ("Please enter service no.");
            document.frmsearch.txtserno.focus();
			return false;
        }
		
			document.frmsearch.submit();
}

function addUpdt()
	{
 					
		 if (document.frmupdt.ldt.value == '') {
            alert ("Please specify the Date");
            document.frmupdt.ldt.focus();
			return false;
        }
		if (document.frmupdt.outdt.value == '') {
            alert ("Please specify the Date");
            document.frmupdt.outdt.focus();
			return false;
        }
		if(dateOK(document.frmupdt.ldt.value,document.frmupdt.outdt.value) == false)
		{
			return false;
		}
		
		document.frmupdt.submit();
	}

function updt()
	{
 					
		 if (document.frmupdt.ldt.value == '') {
            alert ("Please specify the Date");
            document.frmupdt.ldt.focus();
			return false;
        }
		if (document.frmupdt.indt.value == '') {
            alert ("Please specify the Date");
            document.frmupdt.indt.focus();
			return false;
        }
		if(dateOK(document.frmupdt.ldt.value,document.frmupdt.indt.value) == false)
		{
			return false;
		}
		
		document.frmupdt.submit();
	}
	
function addPost()
	{
 		if (document.frmpost.outdt.value == '') {
            alert ("Please specify the Date");
            document.frmpost.outdt.focus();
			return false;
        }	
		
		 if (document.frmpost.p_out_dt.value == '') {
            alert ("Please specify the Date");
            document.frmpost.p_out_dt.focus();
			return false;
        }
		if(dateOK(document.frmpost.p_out_dt.value,document.frmpost.outdt.value) == false)
		{
			return false;
		}
		
			document.frmpost.submit();
	}

function addmovol()
	{
 		if (document.frmmovout.outdt.value == '') {
            alert ("Please specify the Date");
            document.frmmovout.outdt.focus();
			return false;
        }	
		
		 if (document.frmmovout.sorsdt.value == '') {
            alert ("Please specify the Date");
            document.frmmovout.sorsdt.focus();
			return false;
        }
		
		if (document.frmmovout.torsdt.value == '') {
            alert ("Please specify the Date");
            document.frmmovout.torsdt.focus();
			return false;
        }
		
		if(threedates(document.frmmovout.sorsdt.value,document.frmmovout.torsdt.value,document.frmmovout.outdt.value) == false)
		{ 
		return false;
		}
			document.frmmovout.submit();
	}	

function addmovo()
	{
 		if (document.frmmovout.outdt.value == '') {
            alert ("Please specify the Date");
            document.frmmovout.outdt.focus();
			return false;
        }	
		
		 if (document.frmmovout.sorsdt.value == '') {
            alert ("Please specify the Date");
            document.frmmovout.sorsdt.focus();
			return false;
        }
		if(dateOK(document.frmmovout.sorsdt.value,document.frmmovout.outdt.value) == false)
		{
			return false;
		}
		
		document.frmmovout.submit();
	}	


function addSave()
	{
		if(dateOK(document.frmAdd.p_in_dt.value,document.frmAdd.indt.value) == false)
		{
			return false;
		}
 		if(document.frmAdd.chksfx.value=='') {
            alert("Please specify the Check Suffix");
            document.frmAdd.chksfx.focus();
            return false;
        }

		if (!alpha(document.frmAdd.name)) {
			alert("Name Should have alphabets !");
			document.frmAdd.name.focus();
			return false;
		}
		
        if (document.frmAdd.name.value == '') {
            alert ("Please specify the name");
            document.frmAdd.name.focus();
			return false;
        }
		
		if (document.frmAdd.p_in_dt.value == '') {
            alert ("Please specify the Date");
            document.frmAdd.p_in_dt.focus();
			return false;
        }
		if (document.frmAdd.indt.value == '') {
            alert ("Please specify the Date");
            document.frmAdd.indt.focus();
			return false;
        }	
		
			document.frmAdd.submit();
	}
	

function addMov()
	{
 		if (document.frmmovin.indt.value == '') {
            alert ("Please specify the Date");
            document.frmmovin.indt.focus();
			return false;
        }	
		
		 if (document.frmmovin.torsdt.value == '') {
            alert ("Please specify the Date");
            document.frmmovin.torsdt.focus();
			return false;
        }
		if(dateOK(document.frmmovin.torsdt.value,document.frmmovin.indt.value) == false)
		{
			return false;
		}
		
			document.frmmovin.submit();
	}	


function numeric(txt)
{
var flag=true;
var i,code;

if(txt.value=="")
   return false;

for(i=0;txt.value.length>i;i++)
	{
	code=txt.value.charCodeAt(i);
    if(code>=48 && code<=57)
	   flag=true;
	else
	   {
	   flag=false;
	   break;
	   }
	}
return flag;
}

function alpha(txt)
{
var flag=true;
var i,code;

if(txt.value=="")
   return false;

for(i=0;txt.value.length>i;i++)
	{
	code=txt.value.charCodeAt(i);
    if((code>=65 && code<=122) || code==32 || code==46)
	   flag=true;
	else
	   {
	   flag=false;
	   break;
	   }
	}
return flag;
}

function isAllDigits(s)
    {
    for (var k = 0; k < 10; k++)
        {
        var c = s.substring(k, k+1);
        if (isDigit(c) == false)
            {
            return false;
            }
        }
    return true;
    }


function isDigit(c)
{
    
    if (c == 0 || c == 1 || c == 2 || c == 3 || c == 4 || c == 5 || c == 6 || c == 7 || c == 8 || c == 9)
    {
        return true;
    }
    else
	{
		return false;
	}
}

function sernoOK()
{
	var serno = document.frmsearch.txtserno.value;
	if (serno.length == 6 || serno.length == 9 || serno.length == 8)
	{
		var result = isAllDigits(serno);
		if (result == false)
		{
			alert("Invalid character in Service No.");
			return result;
		}
		else
		{
			return true;
		}
	}
	else
	{
		alert("Invalid Service No, Pls re-enter...");
		return false;
	}
}


function dateOK(txt1,txt2)
{
	var tors = txt1;
	var mov =txt2;		
	var torsyr = parseInt(tors.substring(0,4),10);
	var torsmn = parseInt(tors.substring(5,7),10);
	var torsdy = parseInt(tors.substring(8,10),10);
	var movyr =parseInt(mov.substring(0,4),10);
	var movmn =parseInt(mov.substring(5,7),10);
	var movdy =parseInt(mov.substring(8,10),10);
	
	if (movyr > torsyr)
	{
		return true;
	}
	else 
	{
		if (movyr = torsyr)
		{
			if(movmn > torsmn)
			{return true;}
			else 
			{
				if(movmn = torsmn)
				{
					if(movdy >= torsdy)
					{
						return true;
					}
					else
					{
						alert("Pls check the date");
					 return false;
					}
				}
				else
				{alert("Pls check the date");
					return false;
				}
			}
			
		}
		else
		{alert("Pls check the date");
			return false;
		}
	}
}

function lvdateOK(txt1,txt2)
{
	var tors = txt1;
	var mov =txt2;		
	var torsyr = parseInt(tors.substring(0,4),10);
	var torsmn = parseInt(tors.substring(5,7),10);
	var torsdy = parseInt(tors.substring(8,10),10);
	var movyr =parseInt(mov.substring(0,4),10);
	var movmn =parseInt(mov.substring(5,7),10);
	var movdy =parseInt(mov.substring(8,10),10);
	
	if (movyr > torsyr)
	{
		return true;
	}
	else 
	{
		if (movyr = torsyr)
		{
			if(movmn > torsmn)
			{return true;}
			else 
			{
				if(movmn = torsmn)
				{
					if(movdy > torsdy)
					{
						return true;
					}
					else
					{
					 return false;
					}
				}
				else
				{
					return false;
				}
			}
			
		}
		else
		{
			return false;
		}
	}
}

function threedates(dt1,dt2,dt3)
{
	if(lvdateOK(dt1,dt2) == true) 
	{
		if(dateOK(dt1,dt3) == true)
		{
			return true;
		}
		else
		{return false;}
	}
	
	else
	{	alert("Pls Check the SORS and TORS date..");
		return false;
	}
}
	

