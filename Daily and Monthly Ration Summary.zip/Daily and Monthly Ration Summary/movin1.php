<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>27WG:: Movement In</title>

<link href="stylesheets/style.css" rel="stylesheet" type="text/css" >

<?php
session_start();
include_once ("index.php");
include_once ("function.php");
dbconnect();
		switch($_SESSION['unit']) {
			case "27WG":
				$table1 = "personal_info27";
	 	 	 	$table2 = "movement27";
				break;
			case "37SQN":
				$table1 = "personal_info37";
	 	 	 	$table2 = "movement37";
				break;
			case "108SQN":
				$table1 = "personal_info108";
	 	 	 	$table2 = "movement108";
				break;
			case "2201SQN":
				$table1 = "personal_info2201";
	 	 	 	$table2 = "movement2201";
				break;
			case "2224SQN":
				$table1 = "personal_info2224";
	 	 	 	$table2 = "movement2224";
				break;
			case "2254SQN":
				$table1 = "personal_info2254";
	 	 	 	$table2 = "movement2254";
				break;
			case "171SU":
				$table1 = "personal_info171";
	 	 	 	$table2 = "movement171";
				break;
			case "777SU":
				$table1 = "personal_info777";
	 	 	 	$table2 = "movement777";
				break;
			case "853SU":
				$table1 = "personal_info853";
	 	 	 	$table2 = "movement853";
				break;
			case "478MOF":
				$table1 = "personal_info478";
	 	 	 	$table2 = "movement478";
				break;
			case "308TRU":
				$table1 = "personal_info308";
	 	 	 	$table2 = "movement308";
				break;
			case "342TRU":
				$table1 = "personal_info342";
	 	 	 	$table2 = "movement342";
				break;
			case "607GRDFLT":
				$table1 = "personal_info607";
	 	 	 	$table2 = "movement607";
				break;
			}

if(isset($_POST['movein']) && $_POST['movein'] == 'submitted')
{
 	$serno = $_POST['serno'];
	$movcode = $_POST['movcode'];
	$type = $_POST['type'];
	$torsdt = $_POST['torsdt'];
	$movin = 'Y';
	$movout = 'NULL';
	$indt= $_POST['indt'];
		 
	$array=compact("serno","torsdt","movout","movin","indt");

		if (update_row($table2,$array,"serno=$serno and movin is null and movcode = '$movcode'"))
		{
			message("inf.png","$serno is taken on ration strength...!!");
		}
		if ($type == 'TD') 
		{mysql_query("update ".$table1." set movcode = 'ATTACHMENT' where serno = $serno");} 
		else
		{mysql_query("update ".$table1." set movcode = NULL where serno = $serno");}
	// For AWL Cases
		$query2 = "select * from ".$table2." where movin is null and serno = $serno and movcode = 'LEAVE' and movout = 'Y'"; 
		$result2 = mysql_query($query2) or die(mysql_error());
		$rows2 = mysql_num_rows($result2); 
		if ($rows2 == 1)
		{ mysql_query("update ".$table2." set movin = 'Y', movout = NULL where serno = $serno and movcode = 'LEAVE'");} 			

mysql_free_result($result2);
} 

if(isset($_POST['add']) && $_POST['add'] == 'submitted')
{
 	$serno = $_POST['serno'];
	$chksfx = strtoupper($_POST['chksfx']);
	$rank = $_POST['rank'];
	$name = strtoupper($_POST['name']);
	$trade = $_POST['trade'];
	$unit = $_POST['unit'];
	$type = $_POST['type'];
	$status = $_POST['status'];
	$p_in_dt = $_POST['p_in_dt'];
	$torsdt = $_POST['p_in_dt'];
	$sorsdt = $_POST['p_in_dt'];
	$indt = $_POST['indt'];
		
	if ($_POST['type'] == 'ATTACHMENT') 
	{
		$movcode = $_POST['type'];
		$type = 'TD';
			 
		$array=compact("serno","chksfx","rank","name","trade","unit","movcode","type","status","p_in_dt","indt");
		mysql_query("insert into ".$table2." (serno,movcode,torsdt,movin,indt) values ($serno,'$movcode','$p_in_dt','Y','$indt')");
	} 
	else 
	{
		$array=compact("serno","chksfx","rank","name","trade","unit","type","status","p_in_dt","indt");
	}
	
	if (insert_row($table1,$array))
	{
		message("inf.png","$serno is added  in the strength...!!");
	}
	mysql_query("update ".$table1." set rankcode=(select rankcode from rank where rank = '$rank'),category=(select category from rank where rank = '$rank') where serno = $serno");
	mysql_query("insert into ".$table2." (serno,movcode,torsdt) values ($serno,'$status','$torsdt')");
	
}

if(isset($_POST['lin']) && $_POST['lin'] == 'submitted') 
{
	$serno = $_POST['serno'];
	$movcode = $_POST['status'];
	$torsdt = $_POST['ldt'];
	$indt = $_POST['indt'];
	$movin	= 'Y';
			 
	$array=compact("serno","movcode","torsdt","movin","indt");
	if (insert_row($table2,$array))
		{
			message("inf.png","$serno is permitted to Live In...!!");
		}
	mysql_query("update ".$table2." set sorsdt = '$torsdt',outdt = '$indt',movin = null,movout = null where sorsdt is null and serno = $serno and movcode = 'L_OUT'");
	mysql_query("update ".$table1." set status = '$movcode' where serno = $serno");
	
}

if(isset($_POST['awl']) && $_POST['awl'] == 'regularised')
{
	$serno = $_POST['serno'];
	$sorsdt = $_POST['sorsdt'];
	$torsdt = $_POST['torsdt'];
	$regular = $_POST['regular'];
			 
	$query1 = "select * from ".$table2." where serno = $serno and movcode = 'AWL' and sorsdt = '$sorsdt' and torsdt = '$torsdt' and regular is null";
	$result1=mysql_query($query1) or die(mysql_error());
	$row1 = mysql_fetch_array($result1);	
	$rows1 = mysql_num_rows($result1);
	if ($rows1 ==1)
	{
		if($regular == 'Y')
		{
		mysql_query("update ".$table2." set torsdt = '$torsdt',movin = null,outdt=null,indt=null where serno = $serno and movcode = 'LEAVE' and torsdt = '$sorsdt'");
		mysql_query("update ".$table2." set regular = 'Y' where serno = $serno and movcode = 'AWL' and sorsdt = '$sorsdt' and torsdt = '$torsdt' and regular is null");
		message("inf.png","$serno 's AWL is regularised...!!!");
		}
		else
		{message("warn.png","Tick mark for regularisation...!!!");}	
	}
	else
	{message("err.png","Check the AWL period....!!!");}
mysql_free_result($result1);
}

if(isset($_POST['edit']) && $_POST['edit'] == 'edited')
{ 
	$serno = $_POST['serno'];
	$chksfx = strtoupper($_POST['chksfx']);
	$rank= strtoupper($_POST['rank']);
	$name= strtoupper($_POST['name']);
	$trade= strtoupper($_POST['trade']);
	$unit= $_POST['unit'];
	$status = strtoupper($_POST['status']);
	
	$array=compact("serno","chksfx","rank","name","trade","unit","status");

		if (update_row($table1,$array,"serno=$serno"))
		{
			message("inf.png","Record updated  successfully...!!");
		}
		mysql_query("update ".$table1." set rankcode=(select rankcode from rank where rank = '$rank'),category=(select category from rank where rank = '$rank') where serno = $serno");		
}


dbclose();
header("Refresh: 2; URL=http://localhost/drss/index.php"); /* Redirect browser */

?>