<?php
session_start();
$username=$_SESSION['unit'];
if(empty($username)) 
{
session_destroy();
header("Location: http://localhost/drss/login.php");
exit();
}
include_once("function.php");
/*if (!preg_match("/156.84.1./", $_SERVER['REMOTE_ADDR']) && !preg_match("/155.83./", $_SERVER['REMOTE_ADDR']))
{message("Access denied to Outstations.....!");
 exit();
}*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>27WG::On-line DRSS</title>
<link href="stylesheets/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="images/emx_nav_left.css" type="text/css" />
<script type="text/javascript">
<!--
var time = 3000;
var numofitems = 6;

//menu constructor
function menu(allitems,thisitem,startstate){ 
  callname= "gl"+thisitem;
  divname="subglobal"+thisitem;  
  this.numberofmenuitems = allitems;
  this.caller = document.getElementById(callname);
  this.thediv = document.getElementById(divname);
  this.thediv.style.visibility = startstate;
}

//menu methods
function ehandler(event,theobj){
  for (var i=1; i<= theobj.numberofmenuitems; i++){
    var shutdiv =eval( "menuitem"+i+".thediv");
    shutdiv.style.visibility="hidden";
  }
  theobj.thediv.style.visibility="visible";
}
				
function closesubnav(event){
  if ((event.clientY <46)||(event.clientY > 188)){
    for (var i=1; i<= numofitems; i++){
      var shutdiv =eval('menuitem'+i+'.thediv');
      shutdiv.style.visibility='hidden';
    }
  }
}

// -->
</script>
<style type="text/css">
<!--
body {
	background-repeat: repeat;
}
-->
</style></head>
<body onmousemove="closesubnav(event);">
<div id="drsspic"><img src="images/drss.gif" width="504" height="62" /></div>
<div class="skipLinks">skip to: <a href="#content">page content</a> | <a href="#pageNav">links on this page</a> | <a href="#globalNav">site navigation</a> | <a href="#siteInfo">footer (site information)</a> </div>
<div id="masthead">
  <h1 id="siteName"></h1>
  <div id="globalNav"> <img alt="" src="images/gblnav_left.gif" height="32" width="4" id="gnl" /> <img alt="" src="images/glbnav_right.gif" height="32" width="4" id="gnr" />
    <div id="globalLink"> <a href="#" id="gl1" class="glink" onmouseover="ehandler(event,menuitem1);">Personal Info</a><a href="#" id="gl2" class="glink" onmouseover="ehandler(event,menuitem2);">Movement</a><a href="#" id="gl3" class="glink" onmouseover="ehandler(event,menuitem3);">DRSS</a><a href="#" id="gl4" class="glink" onmouseover="ehandler(event,menuitem4);">MRSS</a><a href="#" id="gl5" class="glink" onmouseover="ehandler(event,menuitem5);">Final DRSS </a><a href="#" id="gl6" class="glink" onmouseover="ehandler(event,menuitem6);">Final MRSS </a><a href="mail.php" id="gl7" class="glink">e-mail </a><a href="passwd.php" id="gl7" class="glink">Change Password </a><a href="logout.php" id="gl1" class="glink">Logout</a></div>
    <!--end globalLinks-->
  </div>
  <!-- end globalNav -->
  <div id="subglobal1" class="subglobalNav"> <a href="modify.php">Modify Personal</a> | <a href="view.php">View Personal</a> | <a href="showall.php">Nominal Roll</a> | <a href="record.php">Unit Status</a> | <a href="rankwise.php">Rank Matrix</a> | <a href="tradewise.php">Trade Matrix</a></div> 
  <div id="subglobal2" class="subglobalNav"> <a href="movin.php">Movement In</a> | <a href="movout.php">Movement Out</a> | <a href="regawl.php">Regularize AWL</a></div>
  <div id="subglobal3" class="subglobalNav"> <a href="drssdt.php?url=/drss/drss.php">Generate DRSS</a></div>
  <div id="subglobal4" class="subglobalNav"> <a href="mnth.php?url=/drss/mrss.php">Generate MRSS</a></div>
  <div id="subglobal5" class="subglobalNav">  27 WING, Station Warrant Officer is authorised to : <a href="drssdt.php?url=/drss/fdrss.php">Generate Final DRSS</a> </div>
  <div id="subglobal6" class="subglobalNav"> 27 WING, Station Warrant Officer of  is authorised to : <a href="mnth.php?url=/drss/fmrss.php">Generate Final MRSS</a></div>
</div>
<!-- end masthead -->


<script type="text/javascript">
    <!--
      var menuitem1 = new menu(6,1,"hidden");
			var menuitem2 = new menu(6,2,"hidden");
			var menuitem3 = new menu(6,3,"hidden");
			var menuitem4 = new menu(6,4,"hidden");
			var menuitem5 = new menu(6,5,"hidden");
			var menuitem6 = new menu(6,6,"hidden");
			
    // -->
    </script>
</body>
</html>
