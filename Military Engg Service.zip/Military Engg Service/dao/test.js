
	
function isAllDigits(s)
    {
    for (var k = 0; k < 10; k++)
        {
        var c = s.substring(k, k+1);
        if (isDigit(c) == false)
            {
            return false;
            }
        }
    return true;
    }


function isDigit(c)
{
    
    if (c == 0 || c == 1 || c == 2 || c == 3 || c == 4 || c == 5 || c == 6 || c == 7 || c == 8 || c == 9)
    {
        return true;
    }
    else
	{
		return false;
	}
}

function sernoOK(serno)
{
		if (serno.length == 5 || serno.length == 6 || serno.length == 8)
		{
			var result = isAllDigits(serno);
			if (result == false)
			{
				alert("Invalid character in Service No.");
				return result;
			}
			else
			{
				return true;
			}
		}
		else
		{
			alert("Invalid Service No, Pls re-enter...");
			return false;
		}	
}

function addSave()
	{
		var serno = document.frmreg.serno.value;
 		if(document.frmreg.serno.value=='') 
		{
            alert("Please specify the Service No");
            document.frmreg.serno.focus();
            return false;
        }

		if (sernoOK(serno) == false)
		{
			document.frmreg.serno.focus();
			return false;
		}
		
		if(document.frmreg.area.value == "TECHNICAL" && document.frmreg.sqn.value == '')
		{
			alert ("Please specify the Location");
			document.frmreg.sqn.focus();
			return false;
		}
		if (document.frmreg.location.value == '') {
            alert ("Please specify the Bldg No");
            document.frmreg.location.focus();
			return false;
        }
		
		if (document.frmreg.area.value == '') {
            alert ("Please specify the Area");
            document.frmreg.area.focus();
			return false;
        }
		
		if (document.frmreg.fault.value == '') {
            alert ("Please specify the Complaint");
            document.frmreg.fault.focus();
			return false;
        }
				
			document.frmreg.submit();
	}

function chkval()
	{
		if(document.frmstatus.txtvalue.value=='') {
            alert("Please specify Complaint No");
            document.frmstatus.txtvalue.focus();
            return false;
        }
		document.frmstatus.submit();
	}
	
function chkval1()
	{
		if(document.frmfeed.feedback.value=='') {
            alert("Please enter your remarks");
            document.frmfeed.feedback.focus();
            return false;
        }
		document.frmfeed.submit();
	}