from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm,ValidationError,password_validation
from django import forms
from .models import userdetail, fault, spare, catD
from bootstrap_modal_forms.forms import BSModalModelForm
from datetime import datetime, date


class FRModelForm(BSModalModelForm):
    class Meta:
        model = fault
        exclude = ['iaidocketno', 'repair_analysis', 'approved_by', 'approved_dt']


class UserRegistration(UserCreationForm):
    rank = forms.CharField(max_length=7)
    name = forms.CharField(max_length=25)
    branch = forms.CharField(max_length=20)
    unit = forms.CharField(max_length=7)
    designation = forms.CharField(max_length=15)

    class Meta:
        model = User
        fields = ['username', 'rank', 'name', 'branch', 'unit', 'designation', 'password1', ]
        # labels = {'username': 'Service No', 'rank': 'Rank', 'name': 'Name', 'branch': 'Branch/Trade',
        #           'password1': 'Password', 'unit': 'Unit', 'designation': 'Designation'}
        # widgets = {
        #     'username': forms.TextInput(attrs={'class': 'form-control form-control-sm', 'placeholder': "Enter Service-No"}),
        #     'rank': forms.TextInput(attrs={'class': 'form-control form-control-sm', 'placeholder':"Rank"}),
        #     'name': forms.TextInput(attrs={'class': 'form-control form-control-sm', 'placeholder': "Name"}),
        #     'branch': forms.TextInput(attrs={'class': 'form-control form-control-sm', 'placeholder': "Branch/Trade"}),
        #     'unit': forms.TextInput(attrs={'class': 'form-control form-control-sm', 'placeholder': "Unit"}),
        #     'designation': forms.TextInput(attrs={'class': 'form-control form-control-sm', 'placeholder': "Designation"}),
        # 'password1': forms.PasswordInput(attrs={'class': 'form-control form-control-sm', 'placeholder': "Password"}),
        #    }


class UserUpdate(forms.ModelForm):
    class Meta:
        model = userdetail
        fields = ['username', 'rank', 'name', 'branch', 'unit', 'designation', ]
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control form-control-sm'}),
            'rank': forms.TextInput(attrs={'class': 'form-control form-control-sm'}),
            'name': forms.TextInput(attrs={'class': 'form-control form-control-sm'}),
            'branch': forms.TextInput(attrs={'class': 'form-control form-control-sm'}),
            'unit': forms.TextInput(attrs={'class': 'form-control form-control-sm'}),
            'designation': forms.TextInput(attrs={'class': 'form-control form-control-sm'}),
        }


class LoginForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'password']
        error_messages = {'username': {'required': 'Mandatory Field'}, 'Password': {'required': 'Mandatory Field'}}
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control ', 'placeholder': "Enter Service No"}),
            'password': forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': "Enter Password"})
        }


class RepairForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(RepairForm, self).__init__(*args, **kwargs)
        self.fields['frno'].widget.attrs['readonly'] = True
        self.fields['main_system'].widget.attrs['readonly'] = True

    class Meta:
        model = fault
        exclude = [
            'faultno', 'unit', 'fault_dt', 'fault_nature', 'operating_hr', 'sub_system_desc', 'sub_system_pn',
            'sub_system_sn', 'faulty_part_desc', 'faulty_part_pn', 'faulty_part_sn', 'version', 'oem',
            'other_information',
            'cat_d', 'spares_used', 'fault_desc', 'investigation', 'reported_by', 'reported_dt', 'approved_by',
            'approved_dt','status'
        ]


class CatDrecvdForm(forms.Form):
    id = forms.IntegerField()
    frno = forms.CharField(max_length=13)
    item = forms.CharField(max_length=35)
    system = forms.CharField(max_length=10)
    recvd_dt = forms.DateField()


class FaultForm(forms.ModelForm):
    # this function will be used for the validation
    def clean(self):
        # Get the user submitted names from the cleaned_data dictionary
        cleaned_data = super(FaultForm, self).clean()
        today = datetime.now()
        faultdt = cleaned_data.get("fault_dt")
        reporteddt = cleaned_data.get("reported_dt")
        # conditions to be met for the dates
        if faultdt > date.today():
            raise ValidationError("Please Check Fault Date")
        if reporteddt > date.today():
            raise ValidationError('Please Check Reported Date')
        if reporteddt < faultdt:
            raise ValidationError('Reported date must be later than Fault Date')
        return cleaned_data

    class Meta:
        model = fault
        exclude = ['frno', 'faultno', 'iaidocketno', 'repair_analysis', 'approved_by', 'approved_dt','status']
        widgets = {
            'fault_dt': forms.DateInput(
                format=('%d/%m/%Y'),
                attrs={'class': 'form-control',
                       'placeholder': 'Select a date',
                       'type': 'date',
                       }),
        }




class FaultModalForm(forms.ModelForm):
    # this function will be used for the validation
    def clean(self):
        # Get the user submitted names from the cleaned_data dictionary
        cleaned_data = super(FaultModalForm, self).clean()
        faultdt = cleaned_data.get("fault_dt")
        reporteddt = cleaned_data.get("reported_dt")
        approveddt = cleaned_data.get("approved_dt")
        # conditions to be met for the dates
        if faultdt > date.today():
            raise ValidationError("Please Check Fault Date")
        if reporteddt > date.today():
            raise ValidationError('Please Check Reported Date')
        if reporteddt < faultdt:
            raise ValidationError('Reported date must be later than Fault Date')
        if approveddt < reporteddt:
            raise ValidationError('Approved date must be later than Reported Date')
        return cleaned_data
    class Meta:
        model = fault
        exclude = ['repair_analysis', 'faultno', 'iaidocketno', 'funo','status']
        labels = {
            'frno': 'FR No',
            'unit': 'Unit',
            'fault_dt': 'Fault Date',
            'fault_nature': 'Nature of Fault',
            'main_system': 'Main System',
            'operating_hr': 'Operating Hours',
            'sub_system_desc': 'Sub System',
            'sub_system_pn': 'Sub System Part No',
            'sub_system_sn': 'Sub System Sl No',
            'faulty_part_desc': 'Faulty Part',
            'faulty_part_pn': 'Part No of Faulty Part',
            'faulty_part_sn': 'Sl No of Faulty Part',
            'version': 'Version',
            'oem': 'OEM',
            'other_information': 'Other Information',
            'fault_desc': 'Fault Description',
            'cat_d': 'Cat D',
            'spares_used': 'Spares Used',
            'investigation': 'Investigation',
            'reported_by': 'Reported By',
            'reported_dt': 'Reported Date',
            'approved_by': 'Approved By',
            'approved_dt': 'Approved Date'
        }
        widgets = {
            'approved_dt': forms.DateInput(
                format=('%d/%m/%Y'),
                attrs={'class': 'form-control',
                       'placeholder': 'Select a date',
                       'type': 'date'
                       }),
            'fault_desc': forms.Textarea(attrs={"rows": 3, "cols": 20, 'class': 'form-control'}),
            'investigation': forms.Textarea(attrs={"rows": 3, "cols": 20, 'class': 'form-control'}),
        }


class CatDModalForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(CatDModalForm, self).__init__(*args, **kwargs)
        self.fields['frno'].widget.attrs['readonly'] = True

    class Meta:
        model = catD
        exclude = ['fr_no', 'recvd_dt','unit']
        labels = {'frno': 'Failure Report No', 'system': 'System', 'sub_system': 'Sub System',
                  'item': 'Item Description', 'item_pn': 'Item Part No',
                  'item_sn': 'Item Sl No', 'gig_no': 'GIG No', 'dispatched_dt': 'Dispatched Date'}
        widgets = {
            'dispatched_dt': forms.DateInput(
                format=('%d/%m/%Y'),
                attrs={'class': 'form-control',
                       'placeholder': 'Select a date',
                       'type': 'date'
                       })
        }


class SpareModalForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(SpareModalForm, self).__init__(*args, **kwargs)
        self.fields['frno'].widget.attrs['readonly'] = True

    class Meta:
        model = spare
        exclude = ['fr_no','unit']
        labels = {'frno': 'Failure Report No', 'system': 'System', 'sub_system': 'Sub System',
                  'item': 'Item Description', 'item_pn': 'Item Part No', 'item_sn': 'Item Sl No',
                  'gig_no': 'GIG No'}

