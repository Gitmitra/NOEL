<?php
session_start();

if(!empty($_SESSION['user_logged']))  {
include_once ("menutest.php");
} else {
include_once ("menu.htm");
}
include_once ("conn.php");
include ("function.php");

$_SESSION['state'] = $_POST['radiobutton'];
$_SESSION['rank'] = substr($_POST['txtrank'], 0 , 3);
echo "<table align = center>";
		echo "<tr><td><strong>WAITING LIST";
		echo "</strong></td></tr></table>";

// qtr_view table should always exist in database then only it can be dropped.
	$query1 = "show tables from status";
	$result = mysql_query($query1) or die(mysql_error());
	
	if (!result) 
	{
		mysql_query("create table qtr_view as select * from qtr");
	}
	else 
	{
		$drop = "drop table qtr_view";
		mysql_query($drop);
		mysql_query("create table qtr_view as select * from qtr");
	}

$query = "select slno,serno,rank,name,unit,date_format(dop,'%d-%b-%Y') `dop`,date_format(doe,'%d-%b-%Y') `doe`,date_format(dom,'%d-%b-%Y') `dom`,date_format(dos,'%d-%b-%Y') `dos` from qtr_view order by slno,dos,doe,dom,serno";
$query2 = "select slno,personalno,rank,name,branch,unit,date_format(dop,'%d-%b-%Y') `dop`,date_format(doc,'%d-%b-%Y') `doc`,date_format(dom,'%d-%b-%Y') `dom`,date_format(dos,'%d-%b-%Y') `dos` from qtr_view order by slno,dos,doc,dom,personalno";
$drop = "drop table qtr_view";
mysql_query($drop) or die (mysql_error());

if ($_SESSION['rank']=='AC ') {
mysql_query("create table qtr_view as select serno,rank,name,unit,dop,doe,dom,dos from qtr where rank in ('AC','LAC','L/NK','SEP') order by dos,doe,dom,serno") or die (mysql_error());
mysql_query("alter table qtr_view add slno INT UNSIGNED NOT NULL AUTO_INCREMENT, ADD INDEX(slno)") or die (mysql_error());
select_to_table($query);}

if ($_SESSION['rank']=='CPL') {
mysql_query("create table qtr_view as select serno,rank,name,unit,dop,doe,dom,dos from qtr where rank in ('CPL','NK') order by dos,doe,dom,serno") or die (mysql_error());
mysql_query("alter table qtr_view add slno INT UNSIGNED NOT NULL AUTO_INCREMENT, ADD INDEX(slno)") or die (mysql_error());
select_to_table($query);}

if ($_SESSION['rank']=='WO ') {
mysql_query("create table qtr_view as select serno,rank,name,unit,dop,doe,dom,dos from qtr where rank in ('WO','MWO','SUB') order by dos,doe,dom,serno") or die (mysql_error());
mysql_query("alter table qtr_view add slno INT UNSIGNED NOT NULL AUTO_INCREMENT, ADD INDEX(slno)") or die (mysql_error());
select_to_table($query);}

if ($_SESSION['rank']=='SGT') {
mysql_query("create table qtr_view as select serno,rank,name,unit,dop,doe,dom,dos from qtr where rank in ('SGT','HAV') order by dos,doe,dom,serno") or die (mysql_error());
mysql_query("alter table qtr_view add slno INT UNSIGNED NOT NULL AUTO_INCREMENT, ADD INDEX(slno)") or die (mysql_error());
select_to_table($query);}

if ($_SESSION['rank']=='JWO') {
mysql_query("create table qtr_view as select serno,rank,name,unit,dop,doe,dom,dos from qtr where rank in ('JWO','N/SUB') order by dos,doe,dom,serno") or die (mysql_error());
$alter ="alter table qtr_view add slno INT UNSIGNED NOT NULL AUTO_INCREMENT, ADD INDEX(slno)"; 
mysql_query($alter) or die (mysql_error());
select_to_table($query);}

if ($_SESSION['rank']=='FG ') {
mysql_query("create table qtr_view as select personalno,rank,name,branch,unit,dop,doc,dom,dos from qtr_offr where rank in ('FG OFFR') order by dos,doc,dom,personalno") or die (mysql_error());
$alter ="alter table qtr_view add slno INT UNSIGNED NOT NULL AUTO_INCREMENT, ADD INDEX(slno)"; 
mysql_query($alter) or die (mysql_error());
select_to_table($query2);}

if ($_SESSION['rank']=='FLT') {
mysql_query("create table qtr_view as select personalno,rank,name,branch,unit,dop,doc,dom,dos from qtr_offr where rank in ('FLT LT') order by dos,doc,dom,personalno") or die (mysql_error());
$alter ="alter table qtr_view add slno INT UNSIGNED NOT NULL AUTO_INCREMENT, ADD INDEX(slno)"; 
mysql_query($alter) or die (mysql_error());
select_to_table($query2);}

if ($_SESSION['rank']=='SQN' and $_SESSION['state'] == 'status') {
mysql_query("create table qtr_view as select personalno,rank,name,branch,unit,dop,doc,dom,dos from qtr_offr where rank in ('SQN LDR','MAJOR') order by dos,doc,dom,personalno") or die (mysql_error());
$alter ="alter table qtr_view add slno INT UNSIGNED NOT NULL AUTO_INCREMENT, ADD INDEX(slno)"; 
mysql_query($alter) or die (mysql_error());
select_to_table($query2);}
else {
if ($_SESSION['rank']=='SQN' and $_SESSION['state'] == 'nonstatus') {
mysql_query("create table qtr_view as select personalno,rank,name,branch,unit,dop,doc,dom,dos from qtr_offrnon order by dos,doc,dom,personalno") or die (mysql_error());
$alter ="alter table qtr_view add slno INT UNSIGNED NOT NULL AUTO_INCREMENT, ADD INDEX(slno)"; 
mysql_query($alter) or die (mysql_error());
select_to_table($query2);}}

if ($_SESSION['rank']=='WG ' and $_SESSION['state'] == 'status') {
mysql_query("create table qtr_view as select personalno,rank,name,branch,unit,dop,doc,dom,dos from qtr_offr where rank in ('WG CDR','COL','LT COL') order by dos,doc,dom,personalno") or die (mysql_error());
$alter ="alter table qtr_view add slno INT UNSIGNED NOT NULL AUTO_INCREMENT, ADD INDEX(slno)"; 
mysql_query($alter) or die (mysql_error());
select_to_table($query2);}
else {
if ($_SESSION['rank']=='WG ' and $_SESSION['state'] == 'nonstatus') {
mysql_query("create table qtr_view as select personalno,rank,name,branch,unit,dop,doc,dom,dos from qtr_offrnon order by dos,doc,dom,personalno") or die (mysql_error());
$alter ="alter table qtr_view add slno INT UNSIGNED NOT NULL AUTO_INCREMENT, ADD INDEX(slno)"; 
mysql_query($alter) or die (mysql_error());
select_to_table($query2);}}

?>
