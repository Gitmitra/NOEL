# SQL Manager 2005 for MySQL 3.6.5.1
# ---------------------------------------
# Host     : localhost
# Port     : 3306
# Database : drss


SET FOREIGN_KEY_CHECKS=0;

DROP DATABASE IF EXISTS `drss`;

CREATE DATABASE `drss`
    CHARACTER SET 'latin1'
    COLLATE 'latin1_swedish_ci';

USE `drss`;

#
# Structure for the `movement` table : 
#

DROP TABLE IF EXISTS `movement`;

CREATE TABLE `movement` (
  `serno` int(10) NOT NULL,
  `movcode` varchar(10) default NULL,
  `sorsdt` date default NULL,
  `torsdt` date default NULL,
  `movout` char(1) default NULL,
  `movin` char(1) default NULL,
  `regular` char(1) default NULL,
  `p_t_out` char(1) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Data for the `movement` table  (LIMIT 0,500)
#

INSERT INTO `movement` (`serno`, `movcode`, `sorsdt`, `torsdt`, `movout`, `movin`, `regular`, `p_t_out`) VALUES 
  (100,'LEAVE','2008-06-07','2008-06-22','Y',NULL,NULL,NULL);

COMMIT;

#
# Structure for the `personal_info` table : 
#

DROP TABLE IF EXISTS `personal_info`;

CREATE TABLE `personal_info` (
  `serno` int(10) NOT NULL,
  `chksfx` char(1) default NULL,
  `rank` varchar(10) default NULL,
  `rankcode` int(2) default NULL,
  `category` varchar(10) default NULL,
  `name` varchar(20) default NULL,
  `trade` varchar(15) default NULL,
  `unit` varchar(15) default NULL COMMENT 'Parent unit',
  `movcode` varchar(10) default NULL COMMENT 'Leave, TD, AWL, SSQ',
  `type` varchar(10) default NULL COMMENT 'posted_in,posted_out,TD',
  `status` varchar(5) default NULL COMMENT 'l_in,l_out',
  `p_in_dt` date default NULL COMMENT 'posted or TD in date',
  `p_out_dt` date default NULL COMMENT 'posted out or TD out date',
  PRIMARY KEY  (`serno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Data for the `personal_info` table  (LIMIT 0,500)
#

INSERT INTO `personal_info` (`serno`, `chksfx`, `rank`, `rankcode`, `category`, `name`, `trade`, `unit`, `movcode`, `type`, `status`, `p_in_dt`, `p_out_dt`) VALUES 
  (789456,'H','LAC',1,'AIRMEN','VIKAS','ACHGD','2201SQN','LEAVE','POSTED_IN','L_IN','2008-06-11',NULL);
  

COMMIT;

#
# Structure for the `rank` table : 
#

DROP TABLE IF EXISTS `rank`;

CREATE TABLE `rank` (
  `rank` varchar(10) NOT NULL,
  `rankcode` int(2) default NULL,
  `category` varchar(10) default NULL,
  PRIMARY KEY  (`rank`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Data for the `rank` table  (LIMIT 0,500)
#

INSERT INTO `rank` (`rank`, `rankcode`, `category`) VALUES 
  ('AC',0,'AIRMEN'),
  ('LAC',1,'AIRMEN'),
  ('CPL',2,'AIRMEN'),
  ('SGT',3,'SNCOs'),
  ('JWO',4,'SNCOs'),
  ('WO',5,'SNCOs'),
  ('MWO',6,'SNCOs'),
  ('S/W',7,'NCs(E)'),
  ('COOK',8,'NCs(E)'),
  ('SWEEP',9,'NCs(E)');

COMMIT;

#
# Structure for the `trade` table : 
#

DROP TABLE IF EXISTS `trade`;

CREATE TABLE `trade` (
  `trade` varchar(15) NOT NULL,
  PRIMARY KEY  (`trade`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Structure for the `user` table : 
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `userid` int(3) NOT NULL,
  `username` varchar(15) default NULL,
  `password` varchar(15) default NULL,
  `unit` varchar(15) default NULL,
  `type` varchar(6) default NULL,
  `active` char(1) default NULL,
  PRIMARY KEY  (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Data for the `user` table  (LIMIT 0,500)
#

INSERT INTO `user` (`userid`, `username`, `password`, `unit`, `type`, `active`) VALUES 
  (0,'mitra','mitra','2201SQN','admin','1');

COMMIT;
#
# Definition for the `l_in` view : 
#

DROP VIEW IF EXISTS `l_in`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `l_in` AS 
  select 
    distinct sql_no_cache `a`.`serno` AS `serno`,
    `a`.`sorsdt` AS `sorsdt`,
    `a`.`torsdt` AS `torsdt` 
  from 
    `movement` `a` 
  where 
    (((left(`a`.`sorsdt`,7) = left(curdate(),7)) 
  or 
    (left(`a`.`torsdt`,7) = left(curdate(),7))) and (`a`.`movcode` = _latin1'L_IN')) union 
  select 
    distinct sql_no_cache `a`.`serno` AS `serno`,
    `a`.`sorsdt` AS `sorsdt`,
    `a`.`torsdt` AS `torsdt` 
  from 
    `movement` `a` 
  where 
    ((`a`.`movcode` = _latin1'L_IN') and isnull(`a`.`p_t_out`) and isnull(`a`.`sorsdt`));


#
# Definition for the `awl` view : 
#

DROP VIEW IF EXISTS `awl`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `awl` AS 
  select 
    distinct sql_no_cache `a`.`serno` AS `serno`,
    `a`.`sorsdt` AS `sorsdt`,
    `a`.`torsdt` AS `torsdt` 
  from 
    (`movement` `a` join `l_in` `b`) 
  where 
    (((left(`a`.`sorsdt`,7) = left(curdate(),7)) 
  or 
    (left(`a`.`torsdt`,7) = left(curdate(),7))) and (`a`.`movcode` = _latin1'AWL') and (`a`.`serno` = `b`.`serno`) and isnull(`a`.`regular`));

#
# Definition for the `hosp` view : 
#

DROP VIEW IF EXISTS `hosp`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `hosp` AS 
  select 
    distinct sql_no_cache `a`.`serno` AS `serno`,
    `a`.`sorsdt` AS `sorsdt`,
    `a`.`torsdt` AS `torsdt` 
  from 
    (`movement` `a` join `l_in` `b`) 
  where 
    (((left(`a`.`sorsdt`,7) = left(curdate(),7)) 
  or 
    (left(`a`.`torsdt`,7) = left(curdate(),7))) and (`a`.`movcode` = _latin1'HOSP') and (`a`.`serno` = `b`.`serno`));


#
# Definition for the `leav` view : 
#

DROP VIEW IF EXISTS `leav`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `leav` AS 
  select 
    distinct sql_no_cache `a`.`serno` AS `serno`,
    `a`.`sorsdt` AS `sorsdt`,
    `a`.`torsdt` AS `torsdt` 
  from 
    (`movement` `a` join `l_in` `b`) 
  where 
    (((left(`a`.`sorsdt`,7) = left(curdate(),7)) 
  or 
    (left(`a`.`torsdt`,7) = left(curdate(),7))) and (`a`.`movcode` = _latin1'LEAVE') and (`a`.`serno` = `b`.`serno`));

#
# Definition for the `td` view : 
#

DROP VIEW IF EXISTS `td`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `td` AS 
  select 
    distinct sql_no_cache `a`.`serno` AS `serno`,
    `a`.`sorsdt` AS `sorsdt`,
    `a`.`torsdt` AS `torsdt` 
  from 
    (`movement` `a` join `l_in` `b`) 
  where 
    (((left(`a`.`sorsdt`,7) = left(curdate(),7)) 
  or 
    (left(`a`.`torsdt`,7) = left(curdate(),7))) and (`a`.`movcode` = _latin1'TD') and (`a`.`serno` = `b`.`serno`));

