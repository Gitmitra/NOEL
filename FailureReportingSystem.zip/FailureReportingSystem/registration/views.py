from django.shortcuts import render, HttpResponseRedirect, redirect
from .forms import UserRegistration, UserUpdate,FaultForm,FaultModalForm,CatDModalForm,SpareModalForm,RepairForm,CatDrecvdForm
from .models import userdetail,fault,User,catD,spare
from django.db.models import Sum, Count, F, Q
from django.contrib.auth import authenticate,login,logout,update_session_auth_hash
from django.contrib.auth.forms import AuthenticationForm,SetPasswordForm
from django.contrib import messages
from bootstrap_modal_forms.generic import BSModalCreateView,BSModalUpdateView
from django.urls import reverse_lazy
from django.views import generic
from django.views.generic import View
from datetime import datetime, timedelta, date
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from io import BytesIO
from django.http import HttpResponse
from django.template.loader import get_template, render_to_string
from xhtml2pdf import pisa
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from django.core.exceptions import ObjectDoesNotExist


# Create your views here.

class Profile(generic.ListView):
    model = fault
    context_object_name = 'faults'
    template_name = 'profile.html'

class CatDView(BSModalCreateView):
    form_class = CatDModalForm
    template_name = 'registration/cat_D.html'
    success_message = 'Success: succeeded. You can now dispatch cat D.'
    success_url=reverse_lazy('savefault')

# Update
class FrUpdateView(BSModalUpdateView):
    model = fault
    template_name = 'registration/update_fr.html'
    form_class = FaultModalForm
    success_message = 'Success: FR was updated.'
    success_url = reverse_lazy('profile')

def openFRs_cmd(request):
  unitlist = fault.objects.values('unit').distinct().order_by('unit')
  try:
    if request.method=='POST':
        openfr = fault.objects.filter(unit=request.POST['FU'],status='Open').annotate(days=(date.today()-F('reported_dt'))).order_by('-days')
        selected_unit=request.POST['FU']
        p = Paginator(openfr, 2)  # creating a paginator object
        # getting the desired page number from url
        page_number = request.GET.get('page')
        try:
            page_obj = p.get_page(page_number)  # returns the desired page object
        except PageNotAnInteger:
            # if page_number is not an integer then assign the first page
            page_obj = p.page(1)
        except EmptyPage:
            # if page is empty then return last page
            page_obj = p.page(p.num_pages)
        return render(request, 'registration/openFR_cmd.html', {'unitlist':unitlist,'openfr': page_obj,'selected_unit':selected_unit})
    # if not unitlist:
    #     messages.info(request,'No data available')
    #     return HttpResponseRedirect('/')
    else:
        return render(request, 'registration/openFR_cmd.html', {'unitlist':unitlist})
  except KeyError:
      entry_title = "Guest"
  return HttpResponse('Hello %s' % entry_title)



def fault_compendium(request):
    faultcompobj = fault.objects.values().filter(repair_analysis__isnull=False).order_by('main_system')
    p = Paginator(faultcompobj, 4)  # creating a paginator object
    # getting the desired page number from url
    page_number = request.GET.get('page')
    try:
        page_obj = p.get_page(page_number)  # returns the desired page object
    except PageNotAnInteger:
        # if page_number is not an integer then assign the first page
        page_obj = p.page(1)
    except EmptyPage:
        # if page is empty then return last page
        page_obj = p.page(p.num_pages)

    context = {'faultcompobj': page_obj}
    return render(request, 'registration/compendium.html',context)


def spare_details(request):
    statusobj = spare.objects.values('unit').annotate(consumed=Count('unit')).order_by('unit')
    p = Paginator(statusobj, 5)  # creating a paginator object
    # getting the desired page number from url
    page_number = request.GET.get('page')
    try:
        page_obj = p.get_page(page_number)  # returns the desired page object
    except PageNotAnInteger:
        # if page_number is not an integer then assign the first page
        page_obj = p.page(1)
    except EmptyPage:
        # if page is empty then return last page
        page_obj = p.page(p.num_pages)

    sparesobj = spare.objects.values('unit','system').annotate(consumed=Count('unit'),sys=Count('system')).order_by('unit')
    ps = Paginator(sparesobj, 5)  # creating a paginator object
    # getting the desired page number from url
    page_numbers = request.GET.get('page')
    try:
        page_objs = ps.get_page(page_numbers)  # returns the desired page object
    except PageNotAnInteger:
        # if page_number is not an integer then assign the first page
        page_objs = ps.page(1)
    except EmptyPage:
        # if page is empty then return last page
        page_objs = ps.page(ps.num_pages)
    labels = []
    data = []
    # For making Dough-Chart
    for fr in statusobj:
        labels.append(fr['unit'])
        data.append(fr['consumed'])
    context = {'statusobj': page_obj,'sparesobj': page_objs, 'labels': labels, 'data': data, }
    return render(request, 'registration/sparedetails.html', context)


def catD_details(request):
    unitset = catD.objects.values('unit').annotate(Open=(Count('unit', filter=Q(status='Open'))),
                                                      Close=(Count('unit', filter=Q(status='Close'))),
                                                      Sum=F('Open') + F('Close')).order_by('unit')
    #unitset = catD.objects.values('unit','status').filter(status__in=['Open','Close']).annotate(open=Count('unit')).order_by('unit')
    p = Paginator(unitset, 4)  # creating a paginator object
    # getting the desired page number from url
    page_number = request.GET.get('page')
    try:
        page_obj = p.get_page(page_number)  # returns the desired page object
    except PageNotAnInteger:
        # if page_number is not an integer then assign the first page
        page_obj = p.page(1)
    except EmptyPage:
        # if page is empty then return last page
        page_obj = p.page(p.num_pages)

    catdobj = catD.objects.values('unit', 'system').annotate(consumed=Count('unit'), sys=Count('system')).order_by('unit')
    ps = Paginator(catdobj, 4)  # creating a paginator object
    # getting the desired page number from url
    page_numbers = request.GET.get('page')
    try:
        page_objs = ps.get_page(page_numbers)  # returns the desired page object
    except PageNotAnInteger:
        # if page_number is not an integer then assign the first page
        page_objs = ps.page(1)
    except EmptyPage:
        # if page is empty then return last page
        page_objs = ps.page(ps.num_pages)
    labels = []
    data = []
    # For making Bar-Chart
    opencatD = catD.objects.values('unit','status').filter(status__in=['Open']).annotate(open=Count('unit')).order_by('unit')
    for fr in opencatD:
        labels.append(fr['unit'])
        data.append(fr['open'])

    context = {'unitset': page_obj,'catdobj': page_objs,'labels': labels,'data': data,}
    return render(request, 'registration/catDdetails.html', context)


def fr_details(request):
    statusobj = fault.objects.values('unit').annotate(Open=(Count('unit', filter=Q(status='Open'))),Close=(Count('unit',filter=Q(status='Close'))),Sum=F('Open') + F('Close')).order_by('unit')
    p = Paginator(statusobj, 5)  # creating a paginator object
    # getting the desired page number from url
    page_number = request.GET.get('page')
    try:
        page_obj = p.get_page(page_number)  # returns the desired page object
    except PageNotAnInteger:
        # if page_number is not an integer then assign the first page
        page_obj = p.page(1)
    except EmptyPage:
        # if page is empty then return last page
        page_obj = p.page(p.num_pages)

    labels = []
    data = []
    #For making Pie-Chart
    queryset = fault.objects.values('unit').filter(status = 'Open').annotate(open=Count('unit')).order_by('unit')
    #queryset = fault.objects.all()
    for fr in queryset:
        labels.append(fr['unit'])
        data.append(fr['open'])

    context = {'openobj': page_obj,'labels': labels,'data': data,}
    return render(request, 'registration/frdetails.html',context)



def user_login(request):
    if request.method == 'POST':
        fm = AuthenticationForm(request=request, data=request.POST)
        if fm.is_valid():
            uname = fm.cleaned_data['username']
            upass = fm.cleaned_data['password']
            user = authenticate(username=uname, password=upass)
            mydata = userdetail.objects.get(username=uname)
            if user is not None:
                login(request, user)
                if len(uname)==5:
                    request.session['name']=uname
                    return redirect('faultregistration',username=uname)
                else:
                    fm=SetPasswordForm(user=request.user)
                    request.session['name']=uname
                    #return render(request,'registration/home.html',{'userdata':mydata,'formPwd':fm})
                    return redirect('home')
        else:
            return HttpResponseRedirect('/')
    else:
        fm = AuthenticationForm()
        return render(request, 'registration/userlogin.html', {'form': fm})


def user_change_pass(request):
        if request.method=='POST':
            fm= SetPasswordForm(user=request.user, data=request.POST)
            if fm.is_valid():
                fm.save()
                update_session_auth_hash(request,fm.user)
                messages.success(request,"Password Changed Successfully !!!")
                return HttpResponseRedirect('/home/')
            else:
                messages.success(request, "Please Check, Wrong Input !!!")
                fm=SetPasswordForm(user=request.user)
            return render(request, 'registration/home.html', {'formPwd': fm})


def getfaultno(unit):
    today = datetime.now()
    result = fault.objects.filter(fault_dt__year=today.year, unit=unit).order_by('-faultno').first()
    if result is not None:
        fno = result.faultno
        fno = fno + 1
    else:
        fno = 1
    frno = str(fno) + str(today.year) + unit
    return (fno, frno)


def add_iaidocket(request,username):
    mydata = userdetail.objects.get(username=username)
    iaidocketinfo = fault.objects.filter(unit=mydata.unit, approved_by__isnull=False,iaidocketno__isnull=True).order_by('frno')
    p = Paginator(iaidocketinfo, 5)  # creating a paginator object
    # getting the desired page number from url
    page_number = request.GET.get('page')
    try:
        page_obj = p.get_page(page_number)  # returns the desired page object
    except PageNotAnInteger:
        # if page_number is not an integer then assign the first page
        page_obj = p.page(1)
    except EmptyPage:
        # if page is empty then return last page
        page_obj = p.page(p.num_pages)
    if request.method == 'POST':
        if 'saveIAIdocket' in request.POST:
            obj, created = fault.objects.update_or_create(
                frno=request.POST['frno'], defaults={'iaidocketno': request.POST['iaidocketno']})
            obj.save()
            messages.success(request, "IAI Docket No successfully updated !!!")
            form1 = RepairForm()
            context = {'iaidocketinfo': page_obj, 'formRepair': form1,'userdata':mydata}
            return render(request, 'registration/iaidocketno.html', context)
    else:
        form1 = RepairForm()
        context = {'iaidocketinfo': page_obj, 'formRepair': form1,'userdata':mydata}
        return render(request, 'registration/iaidocketno.html', context)


def add_repair(request,username):
    mydata = userdetail.objects.get(username=username)
    repair_info = fault.objects.filter(unit=mydata.unit, approved_by__isnull=False, repair_analysis__isnull=True).order_by('frno')
    p = Paginator(repair_info, 5)  # creating a paginator object
    # getting the desired page number from url
    page_number = request.GET.get('page')
    try:
        page_obj = p.get_page(page_number)  # returns the desired page object
    except PageNotAnInteger:
        # if page_number is not an integer then assign the first page
        page_obj = p.page(1)
    except EmptyPage:
        # if page is empty then return last page
        page_obj = p.page(p.num_pages)
    if request.method == 'POST':
        if 'saveRepair' in request.POST:
            obj, created = fault.objects.update_or_create(
                frno=request.POST['frno'], defaults={'repair_analysis': request.POST['repair_analysis'],'status':'Close'})
            obj.save()
            messages.success(request, "Repair details updated and FR is Closed  successfully!!!")
            form1 = RepairForm()
            context = {'repairinfo': page_obj, 'formRepair': form1,'userdata':mydata}
            return render(request, 'registration/repairdata.html', context)
    else:
        form1 = RepairForm()
        context = {'repairinfo': page_obj, 'formRepair': form1,'userdata':mydata}
        return render(request, 'registration/repairdata.html', context)


def recv_catD(request,username):
    mydata = userdetail.objects.get(username=username)
    catD_info = catD.objects.filter(recvd_dt__isnull=True,unit = mydata.unit, status='Open').order_by('frno')
    p = Paginator(catD_info, 5)  # creating a paginator object
    # getting the desired page number from url
    page_number = request.GET.get('page')
    try:
        page_obj = p.get_page(page_number)  # returns the desired page object
    except PageNotAnInteger:
        # if page_number is not an integer then assign the first page
        page_obj = p.page(1)
    except EmptyPage:
        # if page is empty then return last page
        page_obj = p.page(p.num_pages)
    if request.method == 'POST':
        if 'saverecvdcatD' in request.POST:
            dispatchdt = catD.objects.get(id=request.POST['id'])
            if str(dispatchdt.dispatched_dt) <= request.POST['recvd_dt']:
                obj, created = catD.objects.update_or_create(
                    id=request.POST['id'], defaults={'recvd_dt': request.POST['recvd_dt'],'status':'Close'})
                obj.save()
                messages.success(request, "Received Date successfully updated !!!")
            else:
                messages.success(request, "Please check the Receive and Dispatch Date !!!")
            form1 = CatDrecvdForm()
            context = {'catDinfo': page_obj, 'formcatD': form1, 'userdata': mydata}
            return render(request, 'registration/recvd_catD.html', context)
    else:
        form1 = CatDrecvdForm()
        context = {'catDinfo': page_obj, 'formcatD': form1,'userdata':mydata}
        return render(request, 'registration/recvd_catD.html', context)


def add_catD(request,username):
    mydata = userdetail.objects.get(username=username)
    #Details of cat D fall between 12 Days from approved date
    catD_info = fault.objects.filter(unit=mydata.unit, approved_by__isnull=False, cat_d=True,approved_dt__gte=datetime.now()-timedelta(days=12)).order_by('approved_dt')
    p = Paginator(catD_info, 5)  # creating a paginator object
    # getting the desired page number from url
    page_number = request.GET.get('page')
    try:
        page_obj = p.get_page(page_number)  # returns the desired page object
    except PageNotAnInteger:
        # if page_number is not an integer then assign the first page
        page_obj = p.page(1)
    except EmptyPage:
        # if page is empty then return last page
        page_obj = p.page(p.num_pages)
    if request.method == 'POST':
        form1 = CatDModalForm(request.POST)
        if form1.is_valid() and 'saveCatD' in request.POST:
            post = form1.save(commit=False)
            post.unit = mydata.unit
            post.status = 'Open'
            post.save()
            messages.success(request, "Cat D details successfully added !!!")
            form1 = CatDModalForm()
            context = {'catDinfo': page_obj, 'formCatD': form1, 'userdata':mydata}
            return render(request, 'registration/cat_D.html', context)
        else:
            form1 = CatDModalForm()
            context = {'catDinfo': page_obj, 'formCatD': form1,'userdata':mydata}
            return render(request, 'registration/cat_D.html', context)
    else:
        form1 = CatDModalForm()
        context = {'catDinfo': page_obj, 'formCatD': form1,'userdata':mydata}
        return render(request, 'registration/cat_D.html', context)


def add_spare(request,username):
    mydata = userdetail.objects.get(username=username)
    spares_info = fault.objects.filter(unit=mydata.unit, approved_by__isnull=False, spares_used=True)
    p = Paginator(spares_info, 5)  # creating a paginator object
    # getting the desired page number from url
    page_number = request.GET.get('page')
    try:
        page_obj = p.get_page(page_number)  # returns the desired page object
    except PageNotAnInteger:
        # if page_number is not an integer then assign the first page
        page_obj = p.page(1)
    except EmptyPage:
        # if page is empty then return last page
        page_obj = p.page(p.num_pages)
    if request.method == 'POST':
        form1 = SpareModalForm(request.POST)
        if form1.is_valid() and 'saveSpares' in request.POST:
            post = form1.save(commit=False)
            post.unit = mydata.unit
            post.save()
            messages.success(request, "Spares successfully added !!!")
            form1 = SpareModalForm()
            context = {'sparesinfo': page_obj, 'formSpares': form1, 'userdata': mydata}
            return render(request, 'registration/spares.html', context)
        else:
            form1 = SpareModalForm()
            context = {'sparesinfo': page_obj, 'formSpares': form1, 'userdata': mydata}
            return render(request, 'registration/spares.html', context)
    else:
        form1 = SpareModalForm()
        context = {'sparesinfo': page_obj, 'formSpares': form1, 'userdata': mydata}
        return render(request, 'registration/spares.html', context)


def add_newfault(request,username):
  if request.user.is_authenticated:
    mydata = userdetail.objects.get(username=username)
    if request.method == 'POST':
        form = FaultForm(request.POST)
        faultdt = request.POST['fault_dt']
        reporteddt = request.POST['reported_dt']
        if reporteddt < faultdt and faultdt > str(date.today()):
            messages.warning(request, "Check the Dates ")
            return render(request, 'registration/fault.html', {'form': form, 'userdata':mydata})
        if form.is_valid() and 'save' in request.POST:
            unit = form.cleaned_data['unit']
            fno, frno = getfaultno(unit)
            post = form.save(commit=False)
            post.faultno=fno
            post.frno = frno
            # Finally write the changes into database
            post.save()
            frno = "Failure Report NO : " + frno + "  " + "Raise Cat D details within 12 Days"
            messages.warning(request, frno)
            form = FaultForm()
            return render(request, 'registration/fault.html', {'form': form, 'userdata':mydata})
        else:
            # Redirect back to the same page if the data is invalid
            return render(request, 'registration/fault.html', {'form': form, 'userdata':mydata})
    else:
        form = FaultForm()
        return render(request, 'registration/fault.html', {'form': form, 'userdata':mydata})
  else:
      return HttpResponseRedirect('/')


def home(request):
    if request.user.is_authenticated:
        mydata = userdetail.objects.get(username=request.user)
        fm = SetPasswordForm(user=request.user)
        context = {'userdata':mydata,'formPwd':fm}
        return render(request,'registration/home.html',context)
    else:
        return HttpResponseRedirect('/')


def user_logout(request):
    if request.method=='POST':
        logout(request)
        request.session.flush()
        request.session.clear_expired()
        return HttpResponseRedirect('/')


def failure_report(request,username):
    mydata = userdetail.objects.get(username=username)
    draftfault = fault.objects.filter(approved_by__isnull=True).filter(unit=mydata.unit)
    p = Paginator(draftfault, 5)  # creating a paginator object
    # getting the desired page number from url
    page_number = request.GET.get('page')
    try:
        page_obj = p.get_page(page_number)  # returns the desired page object
    except PageNotAnInteger:
        # if page_number is not an integer then assign the first page
        page_obj = p.page(1)
    except EmptyPage:
        # if page is empty then return last page
        page_obj = p.page(p.num_pages)
    try:
        if request.method == 'POST':
            if 'approve' in request.POST:
                frinfo = fault.objects.get(pk=request.POST['frno'])
                fm = FaultModalForm(request.POST, instance=frinfo)
                if request.POST['approved_dt']==''or request.POST['approved_by']==''or request.POST['fault_desc']==''or request.POST['investigation']== "":
                    messages.warning(request, "Field can't be left blank")
                    formFR = FaultModalForm()
                    context = {'faults': page_obj, 'userdata': mydata, 'formFR': formFR}
                    return render(request, 'registration/profile.html', context)
                if fm.is_valid():
                    post = fm.save(commit=False)
                    post.status = 'Open'
                    post.save()
                    msg = 'You have successfully approved the FR No: ' + post.frno
                    messages.info(request, msg)
                    formFR = FaultModalForm()
                    context = {'faults': page_obj, 'userdata': mydata, 'formFR': formFR}
                    return render(request, 'registration/profile.html', context)
            if 'delete' in request.POST:
                frinfo = fault.objects.get(pk=request.POST['frno'])
                msg = 'The FR No: ' + frinfo.frno + ' is deleted successfully'
                frinfo.delete()
                messages.info(request, msg)
                formFR = FaultModalForm()
                context = {'faults': page_obj, 'userdata': mydata, 'formFR': formFR}
                return render(request, 'registration/profile.html', context)
        else:
            formFR = FaultModalForm()
            context = {'faults': page_obj, 'userdata':mydata,'formFR':formFR}
            return render(request, 'registration/profile.html', context)
    except ValueError:
        return HttpResponse('Exception: Check for Approved Date')
    return HttpResponse('Exception: Check for Approved Date')

def registration(request):
  if request.user.is_superuser:
      newuser = userdetail.objects.values().order_by('username')
      p = Paginator(newuser, 3)  # creating a paginator object
      # getting the desired page number from url
      page_number = request.GET.get('page')
      try:
          page_obj = p.get_page(page_number)  # returns the desired page object
      except PageNotAnInteger:
          # if page_number is not an integer then assign the first page
          page_obj = p.page(1)
      except EmptyPage:
          # if page is empty then return last page
          page_obj = p.page(p.num_pages)
      if request.method == 'POST' and 'save' in request.POST:
            fm=UserRegistration(request.POST)
            if fm.is_valid():
                user=fm.save()
                # newly added
                userdetail.username = fm.cleaned_data.get('username')
                rank = fm.cleaned_data.get('rank')
                name = fm.cleaned_data.get('name')
                branch = fm.cleaned_data.get('branch')
                unit = fm.cleaned_data.get('unit')
                designation = fm.cleaned_data.get('designation')
                #update or create a record in userdetail corresponding to username in user
                userdetail.objects.update_or_create(
                    user=user, defaults={'username': userdetail.username, 'rank': rank, 'name': name,
                                         'branch': branch, 'unit': unit, 'designation': designation}
                                        )
                user.save()
                messages.success(request, "User successfully added !!!")
                fm = UserRegistration()
                context = {'nuser': page_obj, 'form': fm}
                return render(request, 'registration/registration.html', context)
            else:
                context = {'nuser': page_obj, 'form': fm}
                return render(request, 'registration/registration.html', context)
      else:
        fm = UserRegistration()
        context = {'nuser': page_obj, 'form':fm}
        return render(request,'registration/registration.html',context)
  else:
    return HttpResponseRedirect('/')


def admin_login(request):
     if request.method=='POST':
            fm=AuthenticationForm(request=request, data=request.POST)
            if fm.is_valid():
                uname=fm.cleaned_data['username']
                upass=fm.cleaned_data['password']
                user=authenticate(username=uname, password=upass)
                request.session['name'] = uname
                if user is not None:
                    login(request,user)
                    messages.success(request,"Logged In as Admin")
                    return HttpResponseRedirect('/register/')
            else:
                messages.info(request, "Sorry !! You are not an Authenticated User")
                return HttpResponseRedirect('/uadmin/')
     else:
        fm=AuthenticationForm()
        return render(request, 'registration/login.html',{'form':fm})


def update_user(request,username):
    if request.method == 'POST':
        if 'update' in request.POST:
            userinfo = userdetail.objects.get(pk=request.POST['username'])
            fm = UserUpdate(request.POST,instance=userinfo)
            if fm.is_valid():
                fm.save()
                messages.info(request, 'You have successfully updated the records.')
                return render(request, 'registration/updateuser.html', {'form': fm, 'nuser': userinfo})
    else:
        userinfo=userdetail.objects.get(pk=username)
        data = {'username': userinfo.username, 'rank': userinfo.rank,'name': userinfo.name,'branch': userinfo.branch,'unit': userinfo.unit,'designation': userinfo.designation}
        fm = UserUpdate(initial=data)
        return render(request,'registration/updateuser.html',{'form':fm, 'nuser':userinfo})


def delete_user(request,username):
        user = User.objects.get(username=username)
        if user is not None:
            user.delete()

        fm = UserRegistration()
        alluser = userdetail.objects.all().order_by('username')
        p = Paginator(alluser, 3)  # creating a paginator object
        # getting the desired page number from url
        page_number = request.GET.get('page')
        try:
            page_obj = p.get_page(page_number)  # returns the desired page object
        except PageNotAnInteger:
            # if page_number is not an integer then assign the first page
            page_obj = p.page(1)
        except EmptyPage:
            # if page is empty then return last page
            page_obj = p.page(p.num_pages)
        context = {'nuser': page_obj, 'form': fm}
        return render(request, 'registration/registration.html', context)


# def GeneratePdf2(request):
#         try:
#             fr_db = fault.objects.values_list('frno','main_system','sub_system_desc').get(user=request.username, frno='120232204')  # you can filter using order_id as well
#         except:
#             return HttpResponse("505 Not Found")
#         data = {
#             'frno': fr_db.frno,
#             'main_system': fr_db.main_system,
#             'sub_system_desc': fr_db.sub_system_desc,
#         }
#         pdf = render_to_pdf('registration/reportPDF.html', data)
#         return HttpResponse(pdf, content_type='application/pdf')

        # force download
        # if pdf:
        #     response = HttpResponse(pdf, content_type='application/pdf')
        #     filename = "Invoice_%s.pdf" % (data['order_id'])
        #     content = "inline; filename='%s'" % (filename)
        #     # download = request.GET.get("download")
        #     # if download:
        #     content = "attachment; filename=%s" % (filename)
        #     response['Content-Disposition'] = content
        #     return response
        # return HttpResponse("Not found")

# def GeneratePdf1(request,username):
#     response=HttpResponse(content_type='application/pdf')
#     d=datetime.datetime.today().strftime('%d-%m-%Y')
#     response['Content-Disposition'] = f'inline; filename="{d}.pdf"'
#
#     buffer = BytesIO()
#     p = canvas.Canvas(buffer, pagesize=A4)
#     #Latest approved fault
#     userunit=userdetail.objects.values_list('unit').filter(username=username)
#     today = datetime.datetime.now()
#     fr_db = fault.objects.filter(approved_dt__year=today.year, unit=str(userunit)).order_by('-frno').first()
#
#     #fr_db = fault.objects.values_list('frno','main_system','sub_system_desc').get(frno='120232204')  # you can filter using order_id as well
#     data = {
#             'frno': fr_db.frno,
#             'main_system': fr_db.main_system,
#             'sub_system_desc': fr_db.sub_system_desc,
#         }
#
#    # start writing the PDF here
#     p.setFont("Helvetica", 15, leading=None)
#     p.setFillColorRGB(0.29296875, 0.453125, 0.609375)
#     p.drawString(170, 800, "FAILURE REPORT FORM: MRSAM SYSTEM")
#     p.line(0, 780, 1000, 780)
#     p.line(0, 778, 1000, 778)
#     x1 = 20
#     y1 = 750
#
#     # Render data
#     for key,val in data.items():
#         p.setFont("Helvetica", 15, leading=None)
#         p.drawString(x1, y1 - 20, f"{key} - {val}")
#         y1 = y1 - 60
#
#     p.setTitle(f'Report on {d}')
#     p.showPage()
#     p.save()
#
#     pdf=buffer.getvalue()
#     buffer.close()
#     response.write(pdf)
#     return response

# defining the function to convert an HTML file to a PDF file

def html_to_pdf(template_src, context_dict={}):
     template = get_template(template_src)
     html  = template.render(context_dict)
     result = BytesIO()
     pdf = pisa.pisaDocument(BytesIO(html.encode("ISO-8859-1")), result)
     if not pdf.err:
         return HttpResponse(result.getvalue(), content_type='application/pdf')
     return None

def GeneratePdf(request):
    if request.POST['frs'] is not None:
        fr_db = fault.objects.get(pk=request.POST['frs'])
        #open('registration/temp.html', "w").write(render_to_string('registration/reportPDF.html', {'data': fr_db}))
        # Converting the HTML template into a PDF file
        pdf = html_to_pdf('registration/reportPDFnew.html', {'data': fr_db})
        # rendering the template
        return HttpResponse(pdf, content_type='application/pdf')



def selectFR_pdf(request,username):
    userunit = userdetail.objects.get(username=username)
    fr_db = fault.objects.filter(approved_dt__isnull=False, unit=userunit.unit, repair_analysis__isnull=True).order_by('-frno')
    if not fr_db:
        messages.error(request,"No Approved FR found")
        fm = SetPasswordForm(user=request.user)
        context = {'userdata': userunit, 'formPwd': fm}
        return render(request, 'registration/home.html', context)

    else:
        return render(request, 'registration/selectFR_pdf.html', {'frlist': fr_db})


def open_FRs(request,username):
     #Default value is 0
     mydata = userdetail.objects.get(username=username)
     if request.POST['od'] is not None:
        openfr = fault.objects.filter(unit=mydata.unit, approved_by__isnull=False,reported_dt__lte=datetime.now()-timedelta(days=int(request.POST['od']))).order_by('frno')
        p = Paginator(openfr, 5)  # creating a paginator object
        # getting the desired page number from url
        page_number = request.GET.get('page')
        try:
            page_obj = p.get_page(page_number)  # returns the desired page object
        except PageNotAnInteger:
            # if page_number is not an integer then assign the first page
            page_obj = p.page(1)
        except EmptyPage:
            # if page is empty then return last page
            page_obj = p.page(p.num_pages)
        context = {'openfrinfo': page_obj, 'userdata': mydata}
        return render(request, 'registration/open_FR.html', context)
     else:
        return render(request,'registration/home.html',{'userdata':mydata})
