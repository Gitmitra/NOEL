
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Delete Record</title>
<link href="stylesheets/style.css" rel="stylesheet" type="text/css" />
<script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function back() {
 history.back();
 }

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<?php
session_start();
$username=$_SESSION['user_logged'];
if(empty($username)) 
{
	
$host = $_SERVER['HTTP_HOST'];
$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra = 'login.php';
header("Location: http://$host$uri/$extra");
exit();
}
include_once ("../status/menutest.php");
include_once ("../status/conn.php");
include ("../status/function.php");
session_start();
if($_GET['Submit'] == "Delete")
{
	while (list($key,$_POST['value']) = each($_REQUEST['regno']))
	{
		if($_SESSION['state'] == 'status') 
		{
			mysql_query("delete from qtr_offr where regno = $_POST[value]") or die(mysql_error());
		}
		elseif($_SESSION['state'] == 'nonstatus')
		{
			mysql_query("delete from qtr_offrnon where regno = $_POST[value]") or die(mysql_error());
		}
		else
		{
			mysql_query("delete from qtr where regno = $_POST[value]") or die(mysql_error());
		}
	}
}
 
else 
{
 
?>
<body onload="MM_preloadImages('images/btn_back_02.jpg','images/btn_delete_02.jpg')">
<table width="700" border="0" align="center" cellspacing="1">
  <tr>
    <th scope="col">&nbsp;</th>
    <th scope="col"><p>&nbsp;</p></th>
    <th scope="col">&nbsp;</th>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><form name="form1" method="post" action="../status/delete.php?Submit=Delete">

		<div align="center">
		  <p>
		    <?php
			if($_SESSION['state'] == 'status') 
			{
			$query = "select * from qtr_offr where personalno = '$_SESSION[serno]'";
			delete_from_table($query);
			} 
			else 
			{
				if($_SESSION['state'] == 'nonstatus')
				{
				$query = "select * from qtr_offrnon where personalno = '$_SESSION[serno]'";
				delete_from_table($query);
				}
				else
				{
				$query = "select * from qtr where serno= '$_SESSION[serno]'";
				delete_from_table($query);
				}
			}
		?>
		    </p>
		  <p>&nbsp;</p>
		  <p><a onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Back','','images/btn_back_02.jpg',1)"><img src="images/btn_back.jpg" name="Back" width="65" height="20" border="0" id="Back" onclick="back();"/></a><a onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Submit','','images/btn_delete_02.jpg',1)"><img src="images/btn_delete.jpg" name="Submit" width="65" height="20" border="0" id="Submit" onclick="submit();"/></a></p>
		</div>
    </form>    </td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
<?php
}
if($_GET['Submit'] == "Delete")
{
			echo "<br>\n";
			echo "<br>\n";
			echo "<br>\n";
			echo "<br>\n";
			echo "<br>\n";
			echo "<br>\n";
			echo "<br>\n";
			if($_REQUEST[regno]){
			echo "<table align = center>";
			echo "<tr><td><img src=icons/inf.png align=middle/></td><td><strong>Record of  $_SESSION[serno] is deleted...!!";
			echo "</strong></td></tr></table>";
			}
			else {
			echo "<table align = center>";
			echo "<tr><td><img src=icons/inf.png align=middle/></td><td><strong>Please tick the checkbox for allotment...!!";
			echo "</strong></td></tr></table>";
			}
}
?>
