<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
session_start();
$_SESSION['start'] = 'common';
include_once ("./dao/function.php");
?>
<head>
    <title>On-line MES Complaint</title>
	<meta http-equiv="Content-Language" content="English" />
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
    <meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="expires" content="-1" />
<script language="JavaScript" type="text/JavaScript">
	javascript:window.history.forward(1);
</script>
	<link href="mes.css" rel="stylesheet" type="text/css" />
     <style type="text/css">
<!--
.style4 {color: #006AC3; font-weight: bold; }

-->
     </style>
</head>
<body>

<div id="container">
   <div id="container-header"><div id="container-name"><span>On-line </span>MES Complaint </div></div>
   <div id="container-eyecatcher"><img src="images/business_eyecatcher.jpg" alt="" width="668" height="138" /></div>
   <div id="container-content">
		
		<div id="content">
		    
        	<h1>Stn Cdr &amp; MES  Login</h1>
			<hr/>
			<div id="resources">
        	<form name="mesform" id="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <p><span class="style4">Username</span><br />
  			<input name="Username" type="text" id="textUsername2" style="width:100px" /></p>
            <p><span class="style4" >Password</span><br />
  			<input name="Password" type="password" id="textPassword2" style="width:100px" /></p>
  			<input type="hidden" name="action" value="submitted" />
			<input name="imageField" type="image" src="images/login_btn.jpg" />
			
			</form>
      		</div> <!-- END of resources -->
			<hr/>
		</div> 
		
		<div id="border">
		  <ul id="subnavigation">
		    <div align="left">
		      <p>&nbsp;</p>
		      <p>&nbsp;</p>
		    </div>
			
			<li><strong><a href="./points.php">Register your complaints </a></strong></li>
			<li><strong><a href="./status.php">Status of your complaints  </a></strong></li>
			<li><strong><a href="./feedback.php"> Feedback to Maint Cell </a></strong></li>
		    
		    <li><strong><a href="http://156.84.5.30">Back to Home Page</a></strong></li>
		  </ul>
			
	 </div> <!-- END of border -->
  </div> <!-- END of container-content -->
	<div id="container-footer">
           <div id="footer">
               <div id="footer-copyright">Copyright &copy; 27wg, NET &amp; IT SQN- all rights reserved.</div>
               <div id="footer-meta">Designed &amp; Developed By Sgt S Mitra </div>
           </div>
    </div> <!-- END of container-footer -->

</div> <!-- END of container -->
</body>
</html>
<?php 
if(isset($_POST['action']) && $_POST['action'] == 'submitted')
	{
			  if(empty($_POST['Username']) || empty($_POST['Password']))
			  { echo "<div id=message>";
				echo "<table align = center>";
				echo "<tr><td><strong>Pls enter something";
				echo "</strong></td></tr></table></div>";
				exit();
			  }
			  dbconnect();
			  $uname= $_POST['Username'];
			  $pwd = trim($_POST['Password']);
			  
			  $sql1 = "SELECT * FROM user WHERE username = '$uname'";
			 //execute the SQL statement
			  $result = mysql_query($sql1) or die(mysql_error());
			  $rows =mysql_fetch_array($result);
			  dbclose();
			  if (trim($_POST['Username']) != $rows[username])
			  {
			  echo "<div id=message>";
				echo "<table align = center>";
				echo "<tr><td><strong>Invalid Username";
				echo "</strong></td></tr></table></div>";
			   }
			   else 
			   {
					if ($_POST['Password'] != $rows[password]) 
					{
						echo "<div id=message>";
						echo "<table align = center>";
						echo "<tr><td><strong>Invalid Password";
						echo "</strong></td></tr></table></div>";
					}
					else
					{
			  			$_SESSION['user_password'] = $_POST['Password'];
						$_SESSION['username'] = $_POST['Username'];
		   				echo "<div id=message>";
						echo "<table align = center>";
						echo "<tr><td><strong>Authentication Successfull</strong></td></tr></table></div>"; 
				 		header ('Refresh: 2; url=http://localhost/mes/subdiv.php');
					}
			   }
	}

	?>
