<?php

function insert_row($table="", $atts="")
{
	if(empty($table) || !is_array($atts))
	{return FALSE;}
	else
	{
		while(list($col,$val) = each($atts))
		{
			//if null go to next array item
			if($val=="")
			{continue;}
			$col_str .= $col . ",";
			if(is_int($val) || is_double($val))
			{
				$val_str .= $val . ",";
			}
			else
			{
				$val_str .= "'$val',";
			}
		}
		$query = "insert into $table ($col_str) values ($val_str)";
		//trimming trailing comma from both strings
		$query = str_replace(",)", ")", $query);
		$result=mysql_query($query);
		if(!$result) 
		{message("Don't send same complaint, inspite send a reminder....");}
		else
		{return mysql_affected_rows();}
		
	}
}

function delete_row($table="",$where="")
{
if(empty($table) || empty($where))
{return FALSE;}
$query = "delete from $table where $where";
mysql_query($query) or die(mysql_error());
return mysql_affected_rows();
}


function update_row($table="", $atts="", $where="")
{
	if (empty($table) || !is_array($atts))
	{ return FALSE; }
	else
	{
		while(list($col,$val) = each($atts))
		{
			if($val=="")
			{continue;}
			if(is_int($val) || is_double($val))
			{
			 $str .= $col ."=" .$val .",";
			}
			elseif($val=="NULL" || $val =="null")
			{
			 $str .= $col ."=NULL,";
			}
			else
			{
			 $str .= $col ."='$val',";
			}
			
		}
	 $str = substr($str, 0, -1);
	 $query = "update $table set $str";
	 if(!empty($where))
	 {
	 $query .= "where $where";
	 }
	 $result=mysql_query($query) or die (mysql_error());
	 return mysql_affected_rows();
	}
}

function select_table($query,$b,$s,$sqn)
{
	$result=mysql_query($query);
	$rows = mysql_num_rows($result);
	if($rows == NULL) {
	echo "<br>\n";
	echo "<table align = left>";
	echo "<tr bgcolor=#8ABDFF><td>No records available";
	echo "</td></tr></table>";
	
	} else {
	$number_cols = mysql_num_fields($result);
	echo "<br> \n";
	echo "<table border=$b align = left cellspacing=0 cellpadding=4 bordercolorlight=#000000>";
	echo "<tr align=center bgcolor=#8ABDFF><th colspan=$number_cols><font size=2>$sqn</font></th></tr>\n";
	echo "<tr align=center bgcolor=#8ABDFF>\n";
	for ($i=0; $i<$number_cols; $i++)
	{
		$dbfield = strtoupper(mysql_field_name($result,$i));
		echo "<th><font size=2>".$dbfield. "</font></th>\n";
	}
	echo "</tr>\n";
	while ($row = mysql_fetch_row($result))
	{
		echo "<tr align=left>\n";
		for ($i=0; $i<$number_cols; $i++)
		{
		echo "<td ><font size=$s>";
			if(!isset($row[$i]))
			{echo "--";}
			else
			{echo $row[$i];}
			echo "</font></td>\n";
		}echo "</tr>\n";
	}echo "</table>";
 }
}


function select_to_table($query,$b,$s)
{
	$result=mysql_query($query);
	if($result)
	{$rows = mysql_num_rows($result);}
	if($rows == NULL || !$result) {
	echo "<br>\n";
	echo "<br>\n";
	echo "<br>\n";
	echo "<table align = center>";
	echo "<tr><td><font size=+2>No records available";
	echo "</font></td></tr></table>";
	
	} else {
	$number_cols = mysql_num_fields($result);
	echo "<br> \n";
	echo "<table border=$b align = center cellspacing=0 cellpadding=4 bordercolorlight=#000000>";
	echo "<tr align=center bgcolor=#5899FA>\n";
	for ($i=0; $i<$number_cols; $i++)
	{
		$dbfield = strtoupper(mysql_field_name($result,$i));
		echo "<th><font size=2>".$dbfield. "</font></th>\n";
	}
	echo "<th>";
	echo "SEND";
	echo "</th>\n";
	echo "</tr>\n";
	while ($row = mysql_fetch_row($result))
	{
		echo "<tr align=left>\n";
		for ($i=0; $i<$number_cols; $i++)
		{
			if($i==2||$i==3||$i==4)
			{echo "<td><font size=$s>";}
			else
			{echo "<td nowrap=nowrap><font size=$s>";}
			if(!isset($row[$i]))
			{echo "--";}
			else
			{echo $row[$i];}
			echo "</font></td>\n";
		}
		echo "<td><a href=".process.".".php."?".comno."=".$row[0]."&".reminder."=".send.">Send Reminder</a></td>\n";
		echo "</tr>\n";
	}
	echo "</table>";
	echo "<p><font color=#3300FF size=2>Reminder can be sent only after <font color=#FF0000 size=2><strong>2 days </font></strong>for SANITARY/DRAIN/SWEAGE & EXTERNAL WATER SUPPLY problems and <font color=#FF0000 size=2><strong>6 days </font></strong>for other problems.</font></p>";
 }
}

function select_for_cdr($query,$b,$s,$sqn)
{
	$result=mysql_query($query);
	if($result)
	{$rows = mysql_num_rows($result);}
	if($rows == NULL || !$result) {
	echo "<br>\n";
	echo "<br>\n";
	echo "<br>\n";
	echo "<table align = center>";
	echo "<tr><td><font size=+2>No records available";
	echo "</font></td></tr></table>";
	} else {
	$number_cols = mysql_num_fields($result);
	echo "<br> \n";
	echo "<table border=$b align = center cellspacing=0 cellpadding=4 bordercolorlight=#000000>";
	echo "<tr align=center bgcolor=#8ABDFF><th colspan=$number_cols><font size=2>COMPLAINTS OF $sqn</font></th></tr>\n";
	echo "<tr align=center bgcolor=#8ABDFF>\n";
	for ($i=0; $i<$number_cols; $i++)
	{
		$dbfield = strtoupper(mysql_field_name($result,$i));
		echo "<th><font size=2>".$dbfield. "</font></th>\n";
	}
	echo "</tr>\n";
	while ($row = mysql_fetch_row($result))
	{
		echo "<tr align=left>\n";
		for ($i=0; $i<$number_cols; $i++)
		{
			if($i==3||$i==4)
			{echo "<td><font size=$s>";}
			else
			{echo "<td nowrap=nowrap><font size=$s>";}
			if(!isset($row[$i]))
			{echo "--";}
			else
			{echo $row[$i];}
			echo "</font></td>\n";
		}
		echo "</tr>\n";
	}
	echo "</table>";
  }
}


function select_complaint($query,$b,$s,$subdiv)
{
	$result=mysql_query($query);
	if($result)
	{$rows = mysql_num_rows($result);}
	if($rows == NULL || !$result) {
	echo "<br>\n";
	echo "<br>\n";
	echo "<br>\n";
	echo "<table align = center>";
	echo "<tr><td><font size=+2>No records available";
	echo "</font></td></tr></table>";
	
	} else {
	$number_cols = mysql_num_fields($result);
	echo "<br> \n";
	echo "<table border=$b align = center cellspacing=0 cellpadding=4 bordercolorlight=#000000>";
	echo "<tr align=center bgcolor=#5899FA>\n";
	for ($i=0; $i<$number_cols; $i++)
	{
		$dbfield = strtoupper(mysql_field_name($result,$i));
		echo "<th><font size=2>".$dbfield. "</font></th>\n";
	}
	echo "</tr>\n";
	while ($row = mysql_fetch_array($result))
	{
		echo "<tr align=left>\n";
		for ($i=0; $i<$number_cols; $i++)
		{
			if($i==1)
			{echo "<td><font size=$s>";}
			else
			{echo "<td nowrap=nowrap><font size=$s>";}
			if(!isset($row[$i]))
			{echo "--";}
			else
			{
			 if($i==0)
				{echo "<a href=".$PHP_SELF."?".comno."=".$row[comno]."&".complaint."=".Remarks."+".By."+".Complaint."+".No."&".complaint_no."=".send."&".subdiv."=".preg_replace('/\s+/', '+', $subdiv)."&".remarks."=".preg_replace('/\s+/', '+', $row[remarks]).">".$row[$i]."</a>\n";}
			 else
				{echo $row[$i];}
			}
			echo "</font></td>\n";
		}
		echo "</tr>\n";
	}
	echo "</table>";
	}
print "<p>\n";
	print "<a href=\"subdiv.php\"><strong>&lt;&lt;&nbsp;Back</strong></a>";
print "</p>\n";
}

function select_block_complaint($query,$b,$s,$subdiv)
{
	$result=mysql_query($query);
	if($result)
	{$rows = mysql_num_rows($result);}
	if($rows == NULL || !$result) {
	echo "<br>\n";
	echo "<br>\n";
	echo "<br>\n";
	echo "<table align = center>";
	echo "<tr><td><font size=+2>No records available";
	echo "</font></td></tr></table>";
	
	} else {
	$number_cols = mysql_num_fields($result);
	echo "<br> \n";
	echo "<table border=$b align = center cellspacing=0 cellpadding=4 bordercolorlight=#000000>";
	echo "<tr align=center bgcolor=#5899FA>\n";
	for ($i=0; $i<$number_cols; $i++)
	{
		$dbfield = strtoupper(mysql_field_name($result,$i));
		echo "<th><font size=2>".$dbfield. "</font></th>\n";
	}
	echo "<th>";
	echo "UPDATE";
	echo "</th>\n";
	echo "</tr>\n";
	while ($row = mysql_fetch_array($result))
	{
		echo "<tr align=left>\n";
		for ($i=0; $i<$number_cols; $i++)
		{
			if($i==1)
			{echo "<td><font size=$s>";}
			else
			{echo "<td nowrap=nowrap><font size=$s>";}
			if(!isset($row[$i]))
			{echo "--";}
			else
			{
			 echo $row[$i];
			}
			echo "</font></td>\n";
		}
		echo "<td><input type=checkbox name=comno[] value=".$row[comno]."></td>\n";
		echo "</tr>\n";
	}
	echo "</table>";
	}
print "<p>\n";
	print "<div align=left><a href=\"subdiv.php\"><strong>&lt;&lt;&nbsp;Back</strong></a></div>";
print "</p>\n";
}


function rem_by_users($query,$b,$s)
{
	$result=mysql_query($query);
	if($result)
	{$rows = mysql_num_rows($result);}
	if($rows == NULL || !$result) {
	echo "<br>\n";
	echo "<br>\n";
	echo "<br>\n";
	echo "<table align = center>";
	echo "<tr><td><font size=+2>No records available";
	echo "</font></td></tr></table>";
	
	} else {
	$number_cols = mysql_num_fields($result);
	echo "<br> \n";
	echo "<table border=$b align = center cellspacing=0 cellpadding=4 bordercolorlight=#000000>";
	echo "<tr align=center bgcolor=#5899FA>\n";
	for ($i=0; $i<$number_cols; $i++)
	{
		$dbfield = strtoupper(mysql_field_name($result,$i));
		echo "<th><font size=2>".$dbfield. "</font></th>\n";
	}
	echo "<th>";
	echo "REM BY MAINT CELL";
	echo "</th>\n";
	echo "</tr>\n";
	while ($row = mysql_fetch_row($result))
	{
		echo "<tr align=left>\n";
		for ($i=0; $i<$number_cols; $i++)
		{
			echo "<td><font size=$s>";
			if(!isset($row[$i]))
			{echo "--";}
			else
			{echo $row[$i];}
			echo "</font></td>\n";
		}
		echo "<td><input type=checkbox name=comno[] value=".$row[1].">Clear Comp No  ".$row[1]."</td>\n";
		echo "</tr>\n";
	}
	echo "</table>";
	}
}


function dbconnect()
{
$con=mysql_connect("localhost", "mes", "mes")
  or die(mysql_error());
mysql_select_db("mes",$con)
  or die(mysql_error());
}

function dbclose()
{
$con=mysql_connect("localhost", "mes", "mes")
  or die(mysql_error());
mysql_close($con);
}



function message($str="",$str1="")
{
	for($i=0;$i<5;$i++)
	{
		echo "<br>\n";
	}
	 	echo "<table align = center>";
        echo "<tr><td><p><strong><font color=#333333 size=+2>".$str."</font></strong></p>";
		echo "<p><strong><font color=#FF0000 size=+2>".$str1."</font></strong></p></td></tr></table>";
	for($i=0;$i<5;$i++)
	{
		echo "<br>\n";
	}
}


function safe_query($query = "")
{
 if(empty($query)) { return false; }
 $result = mysql_query($query) or die("ack ! query failed : "
 										."<li>errorno=".mysql_errno()
										."<li>error=".mysql_error()
										."<li>query=".$query
									  );
  return $result;
}	

function fetch_row($table="",$atts="")
{
	if (empty($table) || !is_array($atts))
	{ return false; }
	else
	{
		while(list($col,$val) = each($atts))
		{
			if($val=="")
			{continue;}
			if(is_int($val) || is_double($val))
			{
			 $str .= $col ."=" .$val ." and ";
			}
			elseif($val=="NULL" || $val =="null")
			{
			 $str .= $col ."=NULL,";
			}
			else
			{
			 $str .= $col ."='$val' and ";
			}
		}
		//$str .= "remarks in ('PENDING','UNDER PROGRESS')";
	 	$str = substr($str, 0, -4);
	 	$query = "select count(*) from $table where $str";
	 	$result = safe_query($query);
	 	if(mysql_num_rows($result)>=1)
	 	{
	 		$row = mysql_fetch_row($result);
			return $row;
	 	}
	 }
}

function fetch_row_pen($table="",$atts="",$y="",$m="")
{
	if (empty($table) || !is_array($atts))
	{ return false; }
	else
	{
		while(list($col,$val) = each($atts))
		{
			if($val=="")
			{continue;}
			if(is_int($val) || is_double($val))
			{
			 $str .= $col ."=" .$val ." and ";
			}
			elseif($val=="NULL" || $val =="null")
			{
			 $str .= $col ."=NULL,";
			}
			else
			{
			 $str .= $col ."='$val' and ";
			}
		}
		$str .= "remarks in ('PENDING','UNDER PROGRESS') and left(comdt,7) = left(concat('$y','-','$m','-','01'),7)";
	 	//$str = substr($str, 0, -4);
	 	$query = "select count(*) from $table where $str";
	 	$result = safe_query($query);
	 	if(mysql_num_rows($result)>=1)
	 	{
	 		$row = mysql_fetch_row($result);
			return $row;
	 	}
	 }
}

function fetch_row_clr($table="",$atts="",$y="",$m="")
{
	if (empty($table) || !is_array($atts))
	{ return false; }
	else
	{
		while(list($col,$val) = each($atts))
		{
			if($val=="")
			{continue;}
			if(is_int($val) || is_double($val))
			{
			 $str .= $col ."=" .$val ." and ";
			}
			elseif($val=="NULL" || $val =="null")
			{
			 $str .= $col ."=NULL,";
			}
			else
			{
			 $str .= $col ."='$val' and ";
			}
		}
		$str .= "remarks not in ('PENDING','UNDER PROGRESS','DOOR LOCKED','TEST') and left(comdt,7) = left(concat('$y','-','$m','-','01'),7)";
	 	//$str = substr($str, 0, -4);
	 	$query = "select count(*) from $table where $str";
	 	$result = safe_query($query);
	 	if(mysql_num_rows($result)>=1)
	 	{
	 		$row = mysql_fetch_row($result);
			return $row;
	 	}
	 }
}

function fetch_row_rem($table="",$atts="")
{
	if (empty($table) || !is_array($atts))
	{ return false; }
	else
	{
		while(list($col,$val) = each($atts))
		{
			if($val=="")
			{continue;}
			if(is_int($val) || is_double($val))
			{
			 $str .= $col ."=" .$val ." and ";
			}
			elseif($val=="NULL" || $val =="null")
			{
			 $str .= $col ."=NULL,";
			}
			else
			{
			 $str .= $col ."='$val' and ";
			}
		}
		$str .= "remarks in ('PENDING','UNDER PROGRESS') and reminder > 1";
	 	//$str = substr($str, 0, -4);
	 	$query = "select count(*) from $table where $str";
	 	$result = safe_query($query);
	 	if(mysql_num_rows($result)>=1)
	 	{
	 		$row = mysql_fetch_row($result);
			return $row;
	 	}
	 }
}

//not used
function select_entries($offset=0)
{
	if(empty($offset))
	{$offset=0;}
	$squery = "Select comno,serno,location,fault,comtype,subdiv from complaint order by comno limit $offset, " . 2;
	$result = safe_query($query);
	return $result;
}

function nav($offset,$type,$subdiv,$this_script="")
{
	global $PHP_SELF;
	
	if(empty($this_script))
	{$this_script = $PHP_SELF;}
	if(empty($offset))
	{$offset=0;}
	$result = mysql_query("select count(*) from complaint where comtype='$type' and subdiv = '$subdiv' and remarks = 'PENDING'");
	list($total_rows) = mysql_fetch_array($result);
	print "<p>\n";
	print "<a href=\"subdiv.php\"><strong>&lt;&lt;&nbsp;Back</strong></a>&nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;";
	echo "<img src=images/print.png width=30 height=25 onClick=window.print();> &nbsp;&nbsp;";
	if($offset > 0)
	{
	 print "<a href=\"$this_script?offset=".($offset-3)."&subdiv=".$subdiv."\"><strong>&lt;&lt;&nbsp;Previous Entries</strong></a> &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	}
	if($offset+3 < $total_rows)
	{
	 print "<a href=\"$this_script?offset=".($offset+3)."&subdiv=".$subdiv."\"><strong>Next Entries &nbsp;&gt;&gt;</strong></a> &nbsp; "; 
	}
	
	print "</p>\n";
}
//not used
function cleanup_text($value="",$preserve="",$allowed_tags="")
{
  if(empty($preserve))
  {
  	$value=strip_tags($value, $allowed_tags);
  }
  $value=htmlspecialchars($value);
  return $value;
}
//not used
function print_entry($row,$preserve="")
{
	$numargs = func_num_args();
	for ($i =2; $i < $numargs; $i++)
	{
		$field = func_get_arg($i);
		$dbfield = str_replace(" ", "_", strtolower($field));
		$dbvalue = cleanup_text($row[$dbfield],$preserve);
		$name = ucwords($field);
		print "<tr>\n";
		print "<td valign=top align=right><b>$name : </b></td>\n";
		print "<td valign=top align=left>$dbvalue</td>\n";
		print "</tr>\n\n";
		
	}
}
//not used
function nav1($offset,$subdiv,$Remarks,$this_script="")
{
	global $PHP_SELF;
	
	if(empty($this_script))
	{$this_script = $PHP_SELF;}
	if(empty($offset))
	{$offset=0;}
	$result = mysql_query("select count(*) from complaint where subdiv='$subdiv' and remarks in ('PENDING','UNDER PROGRESS','DOOR LOCKED')");
	list($total_rows) = mysql_fetch_array($result);
	print "<p>\n";
	print "<a href=\"subdiv.php\"><strong>&lt;&lt;&nbsp;Back</strong></a>&nbsp;&nbsp;&nbsp;&nbsp; ";
	if($offset > 0)
	{
	 print "<a href=\"$this_script?offset=".($offset-1)."&subdiv=".$subdiv."&Remarks=".$Remarks."\"><strong>&lt;&lt;&nbsp;Previous Entries</strong></a> &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	}
	if($offset+1 < $total_rows)
	{
	 print "<a href=\"$this_script?offset=".($offset+1)."&subdiv=".$subdiv."&Remarks=".$Remarks."\"><strong>Next Entries&nbsp; &gt;&gt;</strong></a> &nbsp; "; 
	}
	
	print "</p>\n";
}
?>

