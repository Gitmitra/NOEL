<?php
global $_SESSION;

function insert_row($table="", $atts="")
{
	if(empty($table) || !is_array($atts))
	{return FALSE;}
	else
	{
		while(list($col,$val) = each($atts))
		{
			//if null go to next array item
			if($val=="")
			{continue;}
			$col_str .= $col . ",";
			if(is_int($val) || is_double($val))
			{
				$val_str .= $val . ",";
			}
			else
			{
				$val_str .= "'$val',";
			}
		}
		$query = "insert into $table ($col_str) values ($val_str)";
		//trimming trailing comma from both strings
		$query = str_replace(",)", ")", $query);
		$result=mysql_query($query) or die(mysql_error());
		return mysql_affected_rows();
		
	}
}

function delete_row($table="",$where="")
{
if(empty($table) || empty($where))
{return FALSE;}
$query = "delete from $table where $where";
mysql_query($query) or die(mysql_error());
return mysql_affected_rows();
}

function delete_from_table($query)
{
	$result=mysql_query($query);
	$number_cols = mysql_num_fields($result);
	echo "<br> \n";
	echo "<br> \n";
	echo "<br> \n";
	echo "<br> \n";
	echo "<table border = 1 align = center bgcolor=#CCFFFF>";
	echo "<tr align=center bgcolor=#00CCFF>\n";
	for ($i=0; $i<$number_cols; $i++)
	{
		$dbfield = strtoupper(mysql_field_name($result,$i));
		echo "<th>".$dbfield. "</th>\n";
	}
	echo "<th>";
	echo "DELETE";
	echo "</th>\n";
	echo "<th>";
	echo "MODIFY";
	echo "</th>\n";
	echo "</tr>\n";
	while ($row = mysql_fetch_array($result))
	{
		echo "<tr align=left>\n";
		for ($i=0; $i<$number_cols; $i++)
		{
			echo "<td>";
			if(!isset($row[$i]))
			{echo "--";}
			else
			{echo $row[$i];}
			echo "</td>\n";
		}
		echo "<td><input type=radio name=movid value=" .$row[movid]. "> Delete</td>\n";
		echo "<td><a href=" .movedit.".".php."?".movid."=".$row[movid]. "> Edit</a></td>\n";
		echo "</tr>\n";
	}echo "</table>";	
}

function select_row($table="",$where="")
{
if(empty($table) || empty($where))
{return FALSE;}
$query = "select * from $table where $where";
$result = mysql_query($query) or die(mysql_error());
    if (mysql_num_rows($result) == 1)
	{
	  return $result;
	}
}

function update_row($table="", $atts="", $where="")
{
	if (empty($table) || !is_array($atts))
	{ return FALSE; }
	else
	{
		while(list($col,$val) = each($atts))
		{
			if($val=="")
			{continue;}
			if(is_int($val) || is_double($val))
			{
			 $str .= $col ."=" .$val .",";
			}
			elseif($val=="NULL" || $val =="null")
			{
			 $str .= $col ."=NULL,";
			}
			else
			{
			 $str .= $col ."='$val',";
			}
			
		}
	 $str = substr($str, 0, -1);
	 $query = "update $table set $str";
	 if(!empty($where))
	 {
	 $query .= "where $where";
	 }
	 $result=mysql_query($query) or die (mysql_error());
	 return mysql_affected_rows();
	}
}

function select_to_table($query,$b,$s)
{
	$result=mysql_query($query);
	$rows = mysql_num_rows($result);
	if($rows == NULL) {
	echo "<br>\n";
	echo "<table align = center>";
	echo "<tr bgcolor=#CCFFFF><td>No records available";
	echo "</td></tr></table>";
	
	} else {
	$number_cols = mysql_num_fields($result);
	echo "<br> \n";
	echo "<table border=$b align = center cellspacing=0 cellpadding=4 bordercolorlight=#000000>";
	echo "<tr align=center bgcolor=#CCFFFF>\n";
	for ($i=0; $i<$number_cols; $i++)
	{
		$dbfield = strtoupper(mysql_field_name($result,$i));
		echo "<th><font size=2>".$dbfield. "</font></th>\n";
	}
	echo "</tr>\n";
	while ($row = mysql_fetch_row($result))
	{
		echo "<tr align=left>\n";
		for ($i=0; $i<$number_cols; $i++)
		{
		echo "<td nowrap=nowrap><font size=$s>";
			if(!isset($row[$i]))
			{echo "--";}
			else
			{echo $row[$i];}
			echo "</font></td>\n";
		}echo "</tr>\n";
	}echo "</table>";
 }
}

function dbconnect()
{
$con=mysql_connect("localhost", "root", "")
  or die(mysql_error());
mysql_select_db("drss",$con)
  or die(mysql_error());
}

function dbclose()
{
$con=mysql_connect("localhost", "root", "")
  or die(mysql_error());
mysql_close($con);
}


function authenticate($unit="",$pwd="")
{
	
	if(empty($unit) || empty($pwd))
	{return FALSE;}
	else
	{
	dbconnect();
	session_start();
	
	$query  = "select * from user where unit = '$unit' and password = '$pwd'";
	$result = mysql_query($query) or die(mysql_error());
	$rows   = mysql_fetch_array($result);
		if ((trim($unit) == $rows[unit]) && (trim($pwd) == $rows[password]))
		{
		 $_SESSION['unit'] 	= $rows[unit];
	 	 message("inf.png","Authentication Successfull");
		 return TRUE;
		}
		else 
	 	{
	 	 if ($_SESSION['attempts'] < 3) 
		 {
	 	  $_SESSION['attempts'] = $_SESSION['attempts'] + 1;
		  message("warn.png","Invalid Username or Password, Login Attempts :   ",$_SESSION['attempts']);
		 }
	 	 else 
		 { 
	  	  message("err.png","You are not authorised");
	   	  session_destroy();
		  dbclose();
		  header ("Refresh: 2; URL=http://www.27wg.iaf.in");
		 }
	    }
	 }
}

function message($pic="",$str="",$atmpt="")
{
	for($i=0;$i<7;$i++)
	{
		echo "<br>\n";
	}
	 	echo "<table align = center>";
        echo "<tr><td><img src=icons/".$pic." align=middle/></td><td><strong>".$str.$atmpt ;
		echo "</strong></td></tr></table>";
}


function select_to_goodtable($q,$n,$ch)
{
	$r=mysql_query($q);
	$rows = mysql_num_rows($r);
	echo "<link href=stylesheets/style.css rel=stylesheet type=text/css>";
	echo "<table width=700 border=0 align=center>
  		  <tr><th align=left valign=top scope=col><p>&nbsp;</p></th></tr>
  		  <tr><th scope=col >&nbsp;</th></tr>";
  	echo "<tr>";
	for($i=0;$i<$n;$i++)
	{
		echo "<br>\n";
	}
	
	if($rows == NULL) {
	
	echo "<table width=700 border=0 align=center cellpadding=0 cellspacing=0>
         <tr>
          <td width=13 height=12><img src=../drss/images/table_r1_c1.gif  name=table_r1_c1 width=13 height=12 border=0 id=table_r1_c1 /></td>
          <td colspan=9 background=../drss/images/table_r1_c2.gif><img src=../drss/images/spacer.gif name=table_r1_c2 width=1 height=1 border=0 id=table_r1_c2 /></td>
          <td width=13><img src=../drss/images/table_r1_c3.gif  name=table_r1_c3 width=13 height=12 border=0 id=table_r1_c3 /></td>
        </tr> 
		<tr>
          <td background=../drss/images/table_r2_c1.gif><img src=../drss/images/spacer.gif  name=table_r2_c1 width=1 height=1 border=0 id=table_r2_c1 /></td>
          <td>No Records Available</td>
          <td background=../drss/images/table_r2_c3.gif.><img src=../drss/images/spacer.gif  name=table_r2_c3 width=1 height=1 border=0 id=table_r2_c3 /></td>
        </tr>      
        <tr>
          <td><img src=../drss/images/table_r3_c1.gif  name=table_r3_c1 width=13 height=16 border=0 id=table_r3_c1 /></td>
          <td colspan=9 background=../drss/images/table_r3_c2.gif><img src=../drss/images/spacer.gif  name=table_r3_c2 width=1 height=1 border=0 id=table_r3_c2 /></td>
          <td><img src=../drss/images/table_r3_c3.gif  name=table_r3_c3 width=13 height=16 border=0 id=table_r3_c3 /></td>
        </tr>
      </table>";
	
	} else {
	$number_cols = mysql_num_fields($r);
	
	echo "<table width=700 border=0 align=center cellpadding=0 cellspacing=0>
        <tr>
          <td width=13 height=12><img src=../drss/images/table_r1_c1.gif  name=table_r1_c1 width=13 height=12 border=0 id=table_r1_c1 /></td>
          <td colspan=$number_cols background=../drss/images/table_r1_c2.gif><img src=../drss/images/spacer.gif  name=table_r1_c2 width=1 height=1 border=0 id=table_r1_c2 /></td>
          <td width=13><img src=../drss/images/table_r1_c3.gif  name=table_r1_c3 width=13 height=12 border=0 id=table_r1_c3 /></td>
        </tr>      
        <tr>
		  <td background=../drss/images/table_r2_c1.gif></td>";
	for ($i=0; $i<$number_cols; $i++)
	{
		$dbfield = strtoupper(mysql_field_name($r,$i));
		echo "<th align=left>".$dbfield."</th>\n";
	}
	echo "<td background=../drss/images/table_r2_c3.gif.></td>
		</tr>\n";
	echo "<tr align=left>
			<td background=../drss/images/table_r2_c1.gif></td>
			<th colspan=$number_cols align=center valign=top scope=col>&nbsp;</th>
			<td background=../drss/images/table_r2_c3.gif.></td>
		 </tr>\n";
	while ($row = mysql_fetch_row($r))
	{
		echo "<tr align=left>\n";
		echo "<td background=../drss/images/table_r2_c1.gif></td>";
		for ($i=0; $i<$number_cols; $i++)
		{
		echo "<td align=left>";
			if(!isset($row[$i]))
			{echo "$ch";}
			else
			{echo $row[$i];}
			echo "</td>\n";
		}
		echo "<td background=../drss/images/table_r2_c3.gif.></td>";
		echo "</tr>\n";
	}
	echo "<tr>
           <td><img src=../drss/images/table_r3_c1.gif  name=table_r3_c1 width=13 height=16 border=0 id=table_r3_c1 /></td>
           <td colspan=$number_cols background=../drss/images/table_r3_c2.gif><img src=../drss/images/spacer.gif  name=table_r3_c2 width=1 height=1 border=0 id=table_r3_c2 /></td>
           <td><img src=../drss/images/table_r3_c3.gif name=table_r3_c3 width=13 height=16 border=0 id=table_r3_c3 /></td>
         </tr>
	</table>";
 }
echo "</tr>

  	 </table>";
}

/* not used any where in the DRSS application */
function fetch_record($table,$key="",$value="")
{
	$query = "select * from $table ";
	if (!empty($key) && !empty($value))
	{
		if(is_array($key) && is_array($value))
		{
			$query .=" where ";
			$and = " ";
			while(list($i,$v) = each($key))
			{
				$query .= "$and $v = ".$value[$i];
				$and = " and ";
			}
		}
		else
		{
			$query .= " where $key = $value ";
		}
	}
	$result = safe_query($query);
	if (mysql_num_rows($result) >= 1)
	{ 
	$row = mysql_fetch_array($result);
	return $row; 
	}
}


function safe_query($query = "")
{
 if(empty($query)) { return false; }
 $result = mysql_query($query) or die("ack ! query failed : "
 										."<li>errorno=".mysql_errno()
										."<li>error=".mysql_error()
										."<li>query=".$query
									  );
  return $result;
}	

function fetch_row($table="",$atts="")
{
	if (empty($table) || !is_array($atts))
	{ return false; }
	else
	{
		while(list($col,$val) = each($atts))
		{
			if($val=="")
			{continue;}
			if(is_int($val) || is_double($val))
			{
			 $str .= $col ."=" .$val ." and ";
			}
			elseif($val=="NULL" || $val =="null")
			{
			 $str .= $col ."=NULL,";
			}
			else
			{
			 $str .= $col ."='$val' and ";
			}
		}
	//	$str .= "category not like 'NCs(E)'";
	 	$str = substr($str, 0, -4);
	 	$query = "select count(*) from $table where $str";
	 	$result = safe_query($query);
	 	if(mysql_num_rows($result)>=1)
	 	{
	 		$row = mysql_fetch_row($result);
			return $row;
	 	}
	 }
}

function record($table="",$atts="")
{
	if (empty($table) || !is_array($atts))
	{ return false; }
	else
	{
		while(list($col,$val) = each($atts))
		{
			if($val=="")
			{continue;}
			if(is_int($val) || is_double($val))
			{
			 $str .= $col ."=" .$val ." and ";
			}
			elseif($val=="NULL" || $val =="null")
			{
			 $str .= $col ."=NULL,";
			}
			else
			{
			 $str .= $col ."='$val' and ";
			}
		}
		$str .= "category not like 'NCs(E)'";
	 	$query = "select count(*) from $table where $str";
	 	$result = safe_query($query);
	 	if(mysql_num_rows($result)>=1)
	 	{
	 		$row = mysql_fetch_row($result);
			return $row;
	 	}
	 }
}	
?>

