 <?php
if(isset($_POST['Submit']) && $_POST['Submit'] == 'Submit')
{
 if($_POST['Rem'] <> '--Select--')
 {
	$comno = $_POST['comno'];
	$remarks = $_POST['Remarks'];
	$feedback = $_POST['Feedback'];
	$result3=mysql_query("update complaint set rectifydt = curdate(),remarks='$remarks',mc_feedback='$feedback' where comno = '$comno'");
	echo "<table align = center>";
	echo "<tr><td><img src=images/inf.png align=middle/></td><td><strong>Record is updated ...!!";
	echo "</strong></td></tr></table>";
 }
 else
 {
	echo "<table align = center>";
	echo "<tr><td><img src=images/inf.png align=middle/></td><td><strong>Pls choose the remarks ...!!";
	echo "</strong></td></tr></table>";
 }
}
?>
 <form name="form1" id="form1" method="POST" action="<?php $_SERVER['PHP_SELF'] ?>">
	   <table width="526" border="0" align="center">
  <tr>
    <th width="36" scope="row"><div align="left">Date</div></th>
    <th width="168" scope="row"><div align="left">:&nbsp;<strong><?php echo date("d-M-Y");?></strong></div></th>
    <th colspan="2" scope="row"><div align="left"><strong>Complaint No </strong></div></th>
    <th width="46" scope="row"><div align="left">
      <input name="comno" type="text"  value="<?php echo $comno; ?>" maxlength="8"  size="8" readonly="1"/>
    </div></th>
    <th width="160" scope="row"><div align="left">Feed Back</div></th>
  </tr>
  <tr>
    <th colspan="3" valign="top" scope="row"><div align="left"><strong>Choose Remarks </strong></div></th>
    <th colspan="2" valign="top" scope="row"><div align="left">Remarks</div></th>
    <th rowspan="3" valign="top" scope="row"><div align="left"><textarea name="Feedback" rows="4"></textarea></div></th>
  </tr>
  <tr>
    <th height="24" colspan="3" valign="top" scope="row"><div align="left">
      <select name="Rem" onchange="document.form1.Remarks.value = document.form1.Rem.value">
        <option>--Select--</option>
        <option value="CONTRACTOR JOB">CONTRACTOR JOB</option>
        <option value="WRONG COMPLAINT">WRONG COMPLAINT</option>
        <option value="RAISE SEPARATE COMPLAINT">RAISE SEPARATE COMPLAINT</option>
        <option value="STORE N/A">STORE N/A</option>
        <option value="MINOR WORKS">MINOR WORKS</option>
        <option value="BSO">BSO</option>
        <option value="LOCATION NOT CLEAR">LOCATION NOT CLEAR</option>
        <option value="SHO CERTIFICATE REQD">SHO CERTIFICATE REQD</option>
        <option value="DUPLICATE COMPLAINT">DUPLICATE COMPLAINT</option>
        <option value="UNDER PROGRESS">UNDER PROGRESS</option>
        <option value="DOOR LOCKED">DOOR LOCKED</option>
        <option value="DONE">DONE</option>
        <option value="LETTER 2 WKS REQD">LETTER 2 WKS REQD</option>
        <option value="PERIODICAL JOB">PERIODICAL JOB</option>
        <option value="CONTACT US">CONTACT US</option>
      </select>
    </div></th>
    <th colspan="2" valign="top" scope="row"><div align="left">
      <input name="Remarks" type="text" value="<?php echo $remarks; ?>" maxlength="50" size="20" readonly="1" />
    </div></th>
    </tr>
  <tr>
    <th colspan="3" scope="row">&nbsp;</th>
    <th width="91" scope="row"><input type="submit" name="Submit" value="Submit" /></th>
    <td>&nbsp;</td>
    </tr>
</table>
</form>
