# SQL Manager 2005 for MySQL 3.6.5.1
# ---------------------------------------
# Host     : localhost
# Port     : 3306
# Database : mes


SET FOREIGN_KEY_CHECKS=0;

DROP DATABASE IF EXISTS `mes`;

CREATE DATABASE `mes`
    CHARACTER SET 'latin1'
    COLLATE 'latin1_swedish_ci';

USE `mes`;

#
# Structure for the `complaint` table : 
#

DROP TABLE IF EXISTS `complaint`;

CREATE TABLE `complaint` (
  `cid` double(15,0) NOT NULL auto_increment,
  `comdt` date NOT NULL,
  `no` int(11) default NULL,
  `comno` varchar(15) default NULL,
  `serno` int(10) NOT NULL default '0',
  `area` varchar(25) default NULL,
  `sqn` varchar(25) default NULL,
  `location` varchar(25) default NULL,
  `fault` varchar(900) default NULL,
  `comtype` varchar(10) default NULL,
  `subdiv` varchar(50) default NULL,
  `reminder` int(10) default NULL,
  `reminderdt` date default NULL,
  `rectifydt` date default NULL,
  `remarks` varchar(100) default NULL,
  `rem_by_user` varchar(100) default NULL,
  PRIMARY KEY  (`cid`),
  UNIQUE KEY `cid` (`cid`),
  UNIQUE KEY `comp` (`comdt`,`serno`,`fault`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Data for the `complaint` table  (LIMIT 0,500)
#

INSERT INTO `complaint` (`cid`, `comdt`, `no`, `comno`, `serno`, `area`, `sqn`, `location`, `fault`, `comtype`, `subdiv`, `reminder`, `reminderdt`, `rectifydt`, `remarks`, `rem_by_user`) VALUES 
  (1,'2008-11-12',1,'08-1',750150,'RESIDENTIAL',NULL,'918/2','Q','EM',NULL,0,'2008-11-14',NULL,'TEST',NULL);
  
COMMIT;

#
# Structure for the `location` table : 
#

DROP TABLE IF EXISTS `location`;

CREATE TABLE `location` (
  `location` varchar(30) NOT NULL,
  PRIMARY KEY  (`location`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Data for the `location` table  (LIMIT 0,500)
#

INSERT INTO `location` (`location`) VALUES 
  ('108SQN'),
  ('171SU'),
  ('2201SQN'),
  ('2254SQN'),
  ('37SQN'),
  ('478MOF'),
  ('607GDFLT'),
  ('777SU'),
  ('853SU'),
  ('ADMIN SP GP'),
  ('MAINT SP GP'),
  ('OPS SP GP'),
  ('STNHQ');

COMMIT;

#
# Structure for the `user` table : 
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `username` varchar(20) default NULL,
  `password` varchar(20) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Data for the `user` table  (LIMIT 0,500)
#

INSERT INTO `user` (`username`, `password`) VALUES 
  ('BR','123mitra'),
  ('EM','123mitra'),
  ('cdr','123mitra'),
  ('MC','123mitra');

COMMIT;

