<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
session_start();
$host = $_SERVER['HTTP_HOST'];
$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra = 'index.php';
if(empty($_SESSION['user_password'])) 
{
session_destroy();
header("Location: http://$host$uri/$extra");
exit();
}
include_once("dao/function.php");
/*if ((!preg_match("/156.84.1./", $_SERVER['REMOTE_ADDR'])) and (!preg_match("/155.83./",$_SERVER['REMOTE_ADDR']))) 
{message("Access denied to Outstations.....!");
 exit();
}*/
dbconnect();
$query = "select * from user where username = '$_SESSION[username]'";
$result = mysql_query($query) or die(mysql_error());
$row = mysql_fetch_array($result);

?>
<head>
    <title>On-line MES Complaint</title>
	<meta http-equiv="Content-Language" content="English" />
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
	<meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="expires" content="-1" />
<script type="text/JavaScript" src="dao/test.js"></script>
<script language="JavaScript" type="text/JavaScript">
	javascript:window.history.forward(1);
</script>
    	<link href="mes.css" rel="stylesheet" type="text/css" />
<script type="text/JavaScript">
<!--
function addSave()
	{
 			if(document.frmpwd.txtop.value=='') {
            alert("Please specify the Old Password");
            document.frmpwd.txtop.focus();
            return false;
        }

        if (document.frmpwd.txtnp.value == '') {
            alert ("Please specify the New Password");
            document.frmpwd.txtnp.focus();
			return false;
        }
		if (document.frmpwd.txtcp.value == '') {
            alert ("Please confirm the New Password");
            document.frmpwd.txtcp.focus();
			return false;
        }
			document.frmpwd.submit();
	}
//-->
</script>
        
</head>
<body>
<div id="container">
   <div id="container-header"><div id="container-name"><span>On-line </span>MES Complaint </div></div>
   <div id="container-eyecatcher"><img src="images/business_eyecatcher.jpg" width="668" height="138" /></div>
   <div id="container-content">
	
		    <h1>Change Password</h1>
			<hr/>
   	   <form id="form1" name="frmpwd" method="post" action="/mes/passwd.php?SAVE=submit">
	   <table width="341" border="0" align="center">
  <tr>
    <th width="105" scope="row"><div align="left">Date</div></th>
    <th width="10" scope="row">:</th>
    <td colspan="2"><strong><?php echo date("d-M-Y");?></strong></td>
  </tr>
  <tr>
    <th scope="row"><div align="left">Username</div></th>
    <th scope="row">:</th>
    <td colspan="2"><input name="txtname" type="text" readonly="1" value="<?php echo $_SESSION['username'] ?>" /></td>
    </tr>
  <tr>
    <th scope="row"><div align="left">Old Password </div></th>
    <th scope="row">:</th>
    <td colspan="2"><input type="password" name="txtop" /></td>
  </tr>
  <tr>
    <th scope="row"><div align="left">New Password </div></th>
    <th scope="row">:</th>
    <td colspan="2"><input type="password" name="txtnp" /></td>
  </tr>
  <tr>
    <th scope="row"><div align="left">Cnfm Password </div></th>
    <th scope="row">:</th>
    <td colspan="2"><input type="password" name="txtcp" /></td>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <th scope="row">&nbsp;</th>
    <td width="85">
      <img border="0" name="save" onclick="addSave();" onmouseout="this.src='images/btn_submit.gif';" onmouseover="this.src='images/btn_submit_02.gif';" src="images/btn_submit.gif" /></td>
    <td width="123"><a href="subdiv.php"><img border="0" onmouseout="this.src='images/btn_back.jpg';" onmouseover="this.src='images/btn_back_02.jpg';" src="images/btn_back.jpg" /></a></td>
    </tr>
</table>
       </form>
	 <hr/> 
  </div> <!-- END of container-content -->
	<div id="container-footer">
           <div id="footer">
               <div id="footer-copyright">Copyright &copy; 27wg, NET & IT SQN- all rights reserved.</div>
               </div>
    </div> <!-- END of container-footer -->

</div> <!-- END of container -->
</body>
</html>
<?php

if($_GET['SAVE'] && $_GET['SAVE'] == 'submit') {
	if ($_POST['txtop'] != $row[password])
	{
		echo "<div id=message>";
		echo "<table align = center>";
		echo "<tr><td><strong>Invalid Password";
		echo "</strong></td></tr></table></div>";
	}
	else 
	{
		if ($_POST['txtnp'] != $_POST['txtcp'])
		{
			echo "<div id=message>";
			echo "<table align = center>";
			echo "<tr><td><strong>New password is not matched";
			echo "</strong></td></tr></table></div>";
		}
		else
		{
			mysql_query("update user set password = '$_POST[txtnp]' where username = '$_SESSION[username]'");
			echo "<div id=message>";
			echo "<table align = center>";
			echo "<tr><td><strong>Password changed Successfully";
			echo "</strong></td></tr></table></div>";
		
			header ("Refresh: 2; URL=http://localhost/mes/index.php");
		}
	}
}
?> 