<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

 <link href="stylesheets/style.css" rel="stylesheet" type="text/css">
   

<body>
<div id="sortby">
<table width="367" border="0" align="center">
  <tr>
    <th width="361" align="center" valign="top" scope="col">&nbsp;</th>
  </tr>
  <tr>
    <th align="center" valign="top" scope="col"><form name="frmReg" action="<?php echo $_SERVER['PHP_SELF']?>" method="post" >
      <table width="89%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="12"><img src="/drss/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
          <td colspan="3" background="/status/images/table_r1_c2.gif"><img src="/drss/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
          <td width="13"><img src="/status/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
        </tr>
        <tr>
          <td height="28" background="/status/images/table_r2_c1.gif"></td>
          <td>Sort by
            <select name="field">
              <option>--Select--</option>
              <option>SERNO</option>
              <option>RANK</option>
              <option>NAME</option>
              <option>TRADE</option>
              <option>STATUS</option>
            </select></td>
          <td width="74">NCs(E) 
            <input name="radiobutton" type="radio" value="NCs(E)" /></td>
          <td width="78">Airmen 
            <input name="radiobutton" type="radio" value="AIRMEN" /></td>
          <td background="/status/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td background="/status/images/table_r2_c1.gif"></td>
          <td width="143">&nbsp;</td>
          <td colspan="2"><input type="hidden" name="action" value="submitted" />
            <img src="images/btn_submit.gif" name="Image10" width="65" height="20" border="0" onclick="submit();" /></td>
          <td background="/status/images/table_r2_c3.gif."></td>
        </tr>
        
        <tr>
          <td><img src="/drss/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
          <td colspan="3" background="/status/images/table_r3_c2.gif"><img src="/drss/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
          <td><img src="/status/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
        </tr>
      </table>
        </form></th>
  </tr>
   <tr>
    <th align="center" valign="top" scope="col">&nbsp;</th>
  </tr>
</table>
<?php
echo "<a href=$_SESSION[unit].pdf>Print Preview</a>";
?>
</div>
</body>
</html>


