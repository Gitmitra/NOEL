 <?php 
 session_start();
$username=$_SESSION['user_logged'];
if(empty($username)) 
{
	
$host = $_SERVER['HTTP_HOST'];
$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra = 'login.php';
header("Location: http://$host$uri/$extra");
exit();
} 

include_once ("menutest.php");
include_once ("conn.php");
include_once ("function.php");	
	if(!isset($_GET['submit']))
	{
		if($_SESSION['state'] == 'STATUS') 
		{$query = "select * from allot_offr where personalno = '$_SESSION[serno]'";}
		elseif($_SESSION['state'] == 'NON-STATUS')
		{$query = "select * from allot_offrnon where personalno = '$_SESSION[serno]'";}
		
		$result = mysql_query($query) or die (mysql_error());

		while ($row = mysql_fetch_array($result))
		{
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<script>
	
 	function addSave()
	{
		if (document.frmvacateoffr.dov.value == '') {
            alert ("Please specify the Dt of Vacation");
            document.frmvacateoffr.dov.focus();
			return false;
        }
		
 		document.frmvacateoffr.submit();
	}

	function validDate(txt) {
		dateExpression = /^[0-9]{4}-[0-9]{2}-[0-9]{2}$/

		if (!dateExpression.test(txt)) {
			return false;
		}

		return true;
	}
	
</script>

<script type="text/JavaScript">
<!--


function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
 <link href="/status/stylesheets/style.css" rel="stylesheet" type="text/css">
   
<style type="text/css">
    
    br {
        clear: left;
    }

    .version_label {
        display: block;
        float: left;
        width: 150px;
        font-weight: bold;
        margin-left: 10px;
        margin-top: 10px;
    }

    .roundbox {
        margin-top: 50px;
        margin-left: 0px;
    }

    .roundbox_content {
        padding:15px;
    }
    -->
    </style>
</head>

<body>
<table width="600" border="0" align="center">
  <tr class="welcome">
    <th align="center" valign="top" scope="col">Vacation of OMQ </th>
  </tr>
  <tr>
    <th align="center" valign="top" scope="col">&nbsp;</th>
  </tr>
  <tr>
    <th align="center" valign="top" scope="col"><form name="frmvacateoffr" action="/status/vacateoffr.php?submit=add" method="post" >
      <table width="579" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="12"><img src="../status/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
          <td colspan="6" background="../status/images/table_r1_c2.gif"><img src="../status/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
          <td width="13"><img src="../status/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
        </tr>
        <tr>
          <td rowspan="6" background="../status/images/table_r2_c1.gif"><img src="../status/images/spacer.gif" alt="" name="table_r2_c1" width="1" height="1" border="0" id="table_r2_c1" /></td>
          <td height="24">&nbsp;</td>
          <td><div align="left"><strong>Personal No </strong></div></td>
          <td width="150"><div align="left">
            <input name="personalno" type="text" id="personalno" tabindex="1" size="10" readonly="1" value="<?php echo $row[personalno]?>" />
          </div></td>
          <td width="24">&nbsp;</td>
          <td width="129"><div align="left"><strong>OMQ No </strong></div></td>
          <td width="138"><div align="left">
            <input name="omqno" type="text" id="omqno" tabindex="6" size="10" maxlength="10" readonly="1" value="<?php echo $row[omqno]?>"/>
          </div></td>
          <td rowspan="6" background="../status/images/table_r2_c3.gif."><img src="../status/images/spacer.gif" alt="" name="table_r2_c3" width="1" height="1" border="0" id="table_r2_c3" /></td>
        </tr>
        <tr>
          <td width="9">&nbsp;</td>
          <td width="103"><div align="left"><strong>Rank</strong></div></td>
          <td><div align="left">
           <input name="rank" type="text" id="rank" tabindex="2" size="10" readonly="1" value="<?php echo $row[rank]?>"/>
          </div></td>
          <td>&nbsp;</td>
          <td width="129"><div align="left"><strong>Dt of Allotment </strong></div></td>
          <td width="138"><div align="left">
         <input name="doa" type="text" id="doa" tabindex="7" size="10" maxlength="10" readonly="1" value="<?php echo $row[doa]?>"/>
		</div></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><div align="left"><strong>Name</strong></div></td>
          <td><input name="name" type="text" id="name" tabindex="3" size="25" readonly="1" value="<?php echo $row[name]?>"/></td>
          <td>&nbsp;</td>
          <td width="129"><div align="left"><strong>State</strong></div></td>
          <td width="138"><div align="left">
            <input name="state" type="text" id="state" tabindex="8" size="25" readonly="1" value="<?php echo $row[state]?>"/>
          </div></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><div align="left"><strong>Branch</strong></div></td>
          <td><p align="left">
           <input name="branch" type="text" id="branch" tabindex="4" size="10" readonly="1" value="<?php echo $row[branch]?>"/>
          </p></td>
          <td>&nbsp;</td>
          <td width="129"><div align="left"><strong>Grounds</strong></div></td>
          <td width="138"><div align="left">
            <input name="grounds" type="text" id="grounds" tabindex="9" size="25" readonly="1" value="<?php echo $row[grounds]?>"/>
          </div></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><div align="left"><strong>Unit</strong></div></td>
          <td><div align="left">
           <input name="unit" type="text" id="unit" tabindex="5" size="10" readonly="1" value="<?php echo $row[unit]?>"/>
          </div></td>
          <td>&nbsp;</td>
          <td><div align="left"><strong>Dt of Vacation</strong></div></td>
          <td><div align="left">
            <input name="dov" type="text" id="dov" tabindex="10" size="10" maxlength="10" readonly="1"/>
			<input name="Submit" type="button" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frmvacateoffr.dov); return false;" value="..."/>
          </div></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td><img border="0" onclick="addSave();" onmouseout="this.src='../status/images/btn_save.jpg';" onmouseover="this.src='../status/images/btn_save_02.jpg';" src="../status/images/btn_save.jpg" /></td>
        </tr>
        <tr>
          <td><img src="../status/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
          <td colspan="6" background="../status/images/table_r3_c2.gif"><img src="../status/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
          <td><img src="../status/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
        </tr>
      </table>
        </form></th>
  </tr>
  <iframe width=174 height=189 name="gToday:normal:agenda.js" id="gToday:normal:agenda.js" src="/status/scripts/ipopeng.htm" scrolling="no" frameborder="0" style="visibility:visible; z-index:999; position:absolute; top:-500px; left:-500px;"></iframe>
  <tr>
    <th align="center" valign="top" scope="col">&nbsp;</th>
  </tr>
  <tr>
    <th align="center" valign="top" scope="col"><p align="center" class="welcome">&nbsp;</p>    </th>
  </tr>
</table>
</body>
</html>
<?php 
	}
} else {
	$personalno = $_POST['personalno'];
	$rank= $_POST['rank'];
	$name= $_POST['name'];
	$branch= $_POST['branch'];
	$unit= $_POST['unit'];
	$omqno = $_POST['omqno'];
	$doa = $_POST['doa'];
	$state = $_POST['state'];
	$grounds = $_POST['grounds'];
	$dov = $_POST['dov'];
	
	
	$array=compact("personalno","rank","name","branch","unit","omqno","doa", "state", "grounds", "dov");
	
switch($_GET['submit']){
//for inserting row
case "add" :
		if($_SESSION['state'] == 'STATUS') 
		{		
		 	if(insert_row("vacate_offr",$array))	
			{
			echo "<br>\n";
			echo "<table align = center>";
			echo "<tr><td><img src=icons/inf.png align=middle/></td><td><strong>OMQ vacated by '$_SESSION[serno]'...!!";
			echo "</strong></td></tr></table>";
			mysql_query("delete from allot_offr where personalno = '$_POST[personalno]' and rank = '$_POST[rank]'");
			}
		}
		elseif($_SESSION['state'] == 'NON-STATUS')
		{			
			if(insert_row("vacate_offrnon",$array))	
			{
			echo "<br>\n";
			echo "<table align = center>";
			echo "<tr><td><img src=icons/inf.png align=middle/></td><td><strong>OMQ vacated by '$_SESSION[serno]'...!!";
			echo "</strong></td></tr></table>";
			mysql_query("delete from allot_offrnon where personalno = '$_POST[personalno]' and rank = '$_POST[rank]'");
			}
		}
			
		mysql_free_result($result);
		break;
			
	}
}
?>


