<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link href="stylesheets/style.css" rel="stylesheet" type="text/css" />
<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
 function back() {
 history.back();
 }
//-->
</script>
</head>
<?php
include_once ("menutest.php");
include ("conn.php");

session_start();
$username=$_SESSION['user_logged'];
if(empty($username)) 
{
	
$host = $_SERVER['HTTP_HOST'];
$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra = 'login.php';
header("Location: http://$host$uri/$extra");
exit();
} 

$_SESSION['serno'] = $_POST['txtserno'];
$_SESSION['state'] = $_POST['radiobutton']

?>
<body>
<table width="700" border="0" cellspacing="1">
  <tr>
    <th width="179" scope="col">&nbsp;</th>
    <th width="485" scope="col"><p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p></th>
    <th width="26" scope="col">&nbsp;</th>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><table width="269" border="0" cellspacing="1">
      <tr>
        <td width="289"><form id="form1" name="form1" method="post" action="<?php echo $_SERVER[PHP_SELF]?>">
            <table width="258" border="0" align="left" cellpadding="0" cellspacing="0">
              <tr>
                <td width="13" height="12"><img src="../status/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
                <td colspan="7" background="../status/images/table_r1_c2.gif"><img src="../status/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
                <td width="13"><img src="../status/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
              </tr>
              <tr>
                <td rowspan="6" background="../status/images/table_r2_c1.gif"><img src="../status/images/spacer.gif" alt="" name="table_r2_c1" width="1" height="1" border="0" id="table_r2_c1" /></td>
                <td width="69">&nbsp;</td>
                <td width="99" height="24"><strong>Ser No</strong></td>
                <td width="48"><input name="txtserno" type="text" size="8" maxlength="10" /></td>
                <td width="4">&nbsp;</td>
                <td width="4">&nbsp;</td>
                <td width="4">&nbsp;</td>
                <td width="4">&nbsp;</td>
                <td rowspan="6" background="../status/images/table_r2_c3.gif."><img src="../status/images/spacer.gif" alt="" name="table_r2_c3" width="1" height="1" border="0" id="table_r2_c3" /></td>
              </tr>
              <tr></tr>
              <tr></tr>
              <tr></tr>
              <tr></tr>
              <tr>
                <td><input name="radiobutton" type="radio" value="STATUS" />
                  <strong>Status</strong></td>
                <td><input name="radiobutton" type="radio" value="NON-STATUS" />
                  <strong>Non-Status</strong></td>
                <td><input name="Submit" type="submit" class="rollmenu" value="Find" /></td>
              </tr>
              <tr>
                <td><img src="../status/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
                <td colspan="7" background="../status/images/table_r3_c2.gif"><img src="../status/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
                <td><img src="../status/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
              </tr>
            </table>
        </form></td>
      </tr>
    </table></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
<?php 
if($_POST['radiobutton'] == 'STATUS') 
{
	$query = "select * from allot_offr where personalno = '$_POST[txtserno]'";
}
else
{
	if($_POST['radiobutton'] == 'NON-STATUS')
	{
		$query = "select * from allot_offrnon where personalno = '$_POST[txtserno]'";
	}
	else
	{
		$query = "select * from allot where serno= '$_POST[txtserno]'";
	}
}

$result = mysql_query($query) or die (mysql_error());
$rows = mysql_num_rows($result);
if($rows == 1) 
{ 
	if($_POST['radiobutton'] == 'STATUS' or $_POST['radiobutton'] == 'NON-STATUS') 
	{include_once("vacateoffr.php");}
	else
	{include_once("vacate.php");}
} 
 ?>