<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
session_start();
$host = $_SERVER['HTTP_HOST'];
$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra = 'index.php';
if(empty($_SESSION['start'])) 
{
session_destroy();
header("Location: http://$host$uri/$extra");
exit();
}
$_SESSION['points'] = 'null';
include_once("dao/function.php");
/*if ((!preg_match("/156.84.1./", $_SERVER['REMOTE_ADDR'])) and (!preg_match("/155.83./",$_SERVER['REMOTE_ADDR']))) 
{message("Access denied to Outstations.....!");
 exit();
}*/

?>
<head>
    <title>On-line MES Complaint</title>
	<meta http-equiv="Content-Language" content="English" />
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
    <meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="expires" content="-1" />

<link href="mes.css" rel="stylesheet" type="text/css" />
	 
</head>
<body>
<div id="container">
   <div id="container-header"><div id="container-name"><span>On-line </span>MES Complaint </div></div>
   <div id="container-eyecatcher"><img src="images/business_eyecatcher.jpg" alt="" width="668" height="138" /></div>
  <div id="container-content">
     <h1>Points to be remembered </h1>
			<hr/>
		01.	When lodging the complaint, also write whether it is SMQ/OMQ/SECTION with building no.
		<p>02.	Don't mix different nature of complaints in one complaint i.e door broken, water tap leaking.</p>
		<p>03.	Use appropriate words so that MES personnel can understand your complaint while detailing the manpower for job.</p>
		<p>04.	On unseviceability of CFL individual has to collect from MES store on returning of u/s one, need not to lodge complaint.</p>
		<p>05.	Complaints of 2 feet and 4 feet Tubelight and fans to be raised in separate complaint.</p>
		<p>06.	Give the appropriate requirement, of the items i.e tubelight 4 feet Qty-02.</p>
		<p>07.	Give yours or your representative's remarks and signature on both copy of complaint.</p>
				   <a href="index.php"><img src="images/previous.jpg" width="32" height="32" border="0" /></a>&nbsp;
				   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			      <a href="register.php"><img src="images/next.jpg" width="32" height="32" border="0" /></a> </div> 
   <!-- END of container-content -->
</div> <!-- END of container -->
</body>
</html>
