# SQL Manager 2005 for MySQL 3.6.5.1
# ---------------------------------------
# Host     : localhost
# Port     : 3306
# Database : drss


SET FOREIGN_KEY_CHECKS=0;

DROP DATABASE IF EXISTS `drss`;

CREATE DATABASE `drss`
    CHARACTER SET 'latin1'
    COLLATE 'latin1_swedish_ci';

USE `drss`;

#
# Structure for the `movement` table : 
#

DROP TABLE IF EXISTS `movement`;

CREATE TABLE `movement` (
  `movid` int(11) NOT NULL auto_increment,
  `serno` int(10) NOT NULL,
  `movcode` varchar(10) default NULL,
  `sorsdt` date default NULL,
  `torsdt` date default NULL,
  `outdt` date default NULL,
  `indt` date default NULL,
  `movout` char(1) default NULL,
  `movin` char(1) default NULL,
  `regular` char(1) default NULL,
  `p_t_out` char(1) default NULL,
  PRIMARY KEY  (`movid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Data for the `movement` table  (LIMIT 0,500)
#

INSERT INTO `movement` (`movid`, `serno`, `movcode`, `sorsdt`, `torsdt`, `outdt`, `indt`, `movout`, `movin`, `regular`, `p_t_out`) VALUES 
  (59,789789,'L_IN',NULL,'2008-07-18',NULL,NULL,NULL,NULL,NULL,NULL);
  

COMMIT;

#
# Structure for the `movement27` table : 
#

DROP TABLE IF EXISTS `movement27`;

CREATE TABLE `movement27` (
  `movid` int(11) NOT NULL auto_increment,
  `serno` int(10) NOT NULL default '0',
  `movcode` varchar(10) default NULL,
  `sorsdt` date default NULL,
  `torsdt` date default NULL,
  `outdt` date default NULL,
  `indt` date default NULL,
  `movout` char(1) default NULL,
  `movin` char(1) default NULL,
  `regular` char(1) default NULL,
  `p_t_out` char(1) default NULL,
  PRIMARY KEY  (`movid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Data for the `movement27` table  (LIMIT 0,500)
#

INSERT INTO `movement27` (`movid`, `serno`, `movcode`, `sorsdt`, `torsdt`, `outdt`, `indt`, `movout`, `movin`, `regular`, `p_t_out`) VALUES 
  (79,242896,'L_IN',NULL,'2008-06-01',NULL,NULL,NULL,NULL,NULL,NULL);  

COMMIT;

#
# Structure for the `personal_info` table : 
#

DROP TABLE IF EXISTS `personal_info`;

CREATE TABLE `personal_info` (
  `serno` int(10) NOT NULL,
  `chksfx` char(1) default NULL,
  `rank` varchar(10) default NULL,
  `rankcode` int(2) default NULL,
  `category` varchar(10) default NULL,
  `name` varchar(20) default NULL,
  `trade` varchar(15) default NULL,
  `unit` varchar(15) default NULL COMMENT 'Parent unit',
  `movcode` varchar(10) default NULL COMMENT 'Leave, TD, AWL, SSQ',
  `type` varchar(10) default NULL COMMENT 'posted_in,posted_out,TD',
  `status` varchar(5) default NULL COMMENT 'l_in,l_out',
  `p_in_dt` date default NULL COMMENT 'posted or TD in date',
  `indt` date default NULL,
  `p_out_dt` date default NULL COMMENT 'posted out or TD out date',
  `outdt` date default NULL,
  PRIMARY KEY  (`serno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Data for the `personal_info` table  (LIMIT 0,500)
#

INSERT INTO `personal_info` (`serno`, `chksfx`, `rank`, `rankcode`, `category`, `name`, `trade`, `unit`, `movcode`, `type`, `status`, `p_in_dt`, `indt`, `p_out_dt`, `outdt`) VALUES 
  (750000,'A','AC',0,'AIRMEN','SD RAKESH','GTI','2201SQN','DISCHARGE','DISCHARGE','L_IN','2008-07-16','2008-07-17','2008-07-18','2008-07-18');
  

COMMIT;

#
# Structure for the `personal_info27` table : 
#

DROP TABLE IF EXISTS `personal_info27`;

CREATE TABLE `personal_info27` (
  `serno` int(10) NOT NULL default '0',
  `chksfx` char(1) default NULL,
  `rank` varchar(10) default NULL,
  `rankcode` int(2) default NULL,
  `category` varchar(10) default NULL,
  `name` varchar(20) default NULL,
  `trade` varchar(15) default NULL,
  `unit` varchar(15) default NULL COMMENT 'Parent unit',
  `movcode` varchar(10) default NULL COMMENT 'Leave, TD, AWL, SSQ',
  `type` varchar(10) default NULL COMMENT 'posted_in,posted_out,TD',
  `status` varchar(5) default NULL COMMENT 'l_in,l_out',
  `p_in_dt` date default NULL COMMENT 'posted or TD in date',
  `indt` date default NULL,
  `p_out_dt` date default NULL COMMENT 'posted out or TD out date',
  `outdt` date default NULL,
  PRIMARY KEY  (`serno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Data for the `personal_info27` table  (LIMIT 0,500)
#

INSERT INTO `personal_info27` (`serno`, `chksfx`, `rank`, `rankcode`, `category`, `name`, `trade`, `unit`, `movcode`, `type`, `status`, `p_in_dt`, `indt`, `p_out_dt`, `outdt`) VALUES 
  (242896,'A','WO',5,'SNCOs','K Singh','MED ASST','27WG','LEAVE','POSTED_IN','L_IN','2008-06-01','2008-07-18',NULL,NULL);
  

COMMIT;

#
# Structure for the `rank` table : 
#

DROP TABLE IF EXISTS `rank`;

CREATE TABLE `rank` (
  `rank` varchar(10) NOT NULL,
  `rankcode` int(2) default NULL,
  `category` varchar(10) default NULL,
  PRIMARY KEY  (`rank`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Data for the `rank` table  (LIMIT 0,500)
#

INSERT INTO `rank` (`rank`, `rankcode`, `category`) VALUES 
  ('AC',0,'AIRMEN'),
  ('LAC',1,'AIRMEN'),
  ('CPL',2,'AIRMEN'),
  ('SGT',3,'SNCOs'),
  ('JWO',4,'SNCOs'),
  ('WO',5,'SNCOs'),
  ('MWO',6,'SNCOs'),
  ('S/W',7,'NCs(E)'),
  ('COOK',8,'NCs(E)'),
  ('SWEEP',9,'NCs(E)');

COMMIT;

#
# Structure for the `tempmrss` table : 
#

DROP TABLE IF EXISTS `tempmrss`;

CREATE TABLE `tempmrss` (
  `serno` int(11) NOT NULL default '0',
  `rank` varchar(10) default NULL,
  `rankcode` int(11) default NULL,
  `category` varchar(10) default NULL,
  `name` varchar(20) default NULL,
  `trade` varchar(15) default NULL,
  `unit` varchar(15) default NULL,
  `movcode` varchar(10) default NULL,
  `type` varchar(10) default NULL,
  `lin_fm` date default NULL,
  `lin_to` date default NULL,
  `lin_tot` double default NULL,
  `lv_fm` date default NULL,
  `lv_to` date default NULL,
  `lv_tot` double default NULL,
  `td_fm` date default NULL,
  `td_to` date default NULL,
  `td_tot` double default NULL,
  `awl_fm` date default NULL,
  `awl_to` date default NULL,
  `awl_tot` double default NULL,
  `MH_fm` date default NULL,
  `MH_to` date default NULL,
  `MH_tot` double default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Structure for the `trade` table : 
#

DROP TABLE IF EXISTS `trade`;

CREATE TABLE `trade` (
  `trade` varchar(15) NOT NULL,
  PRIMARY KEY  (`trade`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Data for the `trade` table  (LIMIT 0,500)
#

INSERT INTO `trade` (`trade`) VALUES 
  ('ACCT ASST'),
  ('ACH GD'),
  ('ADM ASST'),
  ('ADSO'),
  ('AF FIT'),
  ('AFSO'),
  ('AUTO FIT'),
  ('AUTO TECH'),
  ('BARBER'),
  ('CARP RIG'),
  ('CAT ASST'),
  ('CLK ACCTS'),
  ('CLK EA'),
  ('CLK GD'),
  ('CLK PA'),
  ('COMM TECH'),
  ('COOK'),
  ('CRYPTO'),
  ('DHOBI'),
  ('EDN INST'),
  ('ELEC(E) F'),
  ('ELECT FIT'),
  ('ELECTRO FIT'),
  ('ENG FIT'),
  ('EQPT ASST'),
  ('ESSA'),
  ('FLT ENG'),
  ('FLT GUN'),
  ('FLT SIG'),
  ('GTI'),
  ('GTI(S)'),
  ('IAF(G)'),
  ('IAF(P)'),
  ('IAF(S)'),
  ('INST FIT'),
  ('LASCAR'),
  ('LGS ASST'),
  ('M/WAITER'),
  ('MACH'),
  ('MECH FIT'),
  ('MED ASST'),
  ('MET ASST'),
  ('MF(E)'),
  ('MF(L)'),
  ('MF(M)'),
  ('MOCHI'),
  ('MT FIT'),
  ('MT TECH'),
  ('MTD'),
  ('MUSN'),
  ('OPS ASST'),
  ('PHOTO FIT'),
  ('PHOTO TECH'),
  ('PMF(E)'),
  ('PMF(M)'),
  ('PROP FIT'),
  ('RAD FIT'),
  ('RDO FIT'),
  ('RDO TECH'),
  ('RTO'),
  ('S/WALA'),
  ('SEW'),
  ('STRUC FIT'),
  ('W/CARRIER'),
  ('W/MAN'),
  ('WASHER UP'),
  ('WPN FIT'),
  ('WS FIT(B)'),
  ('WS FIT(C)'),
  ('WS FIT(M)');

COMMIT;

#
# Structure for the `user` table : 
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `userid` int(3) NOT NULL,
  `username` varchar(15) default NULL,
  `password` varchar(15) default NULL,
  `unit` varchar(15) default NULL,
  `type` varchar(6) default NULL,
  `active` char(1) default NULL,
  PRIMARY KEY  (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Data for the `user` table  (LIMIT 0,500)
#

INSERT INTO `user` (`userid`, `username`, `password`, `unit`, `type`, `active`) VALUES 
  (0,'mitra','mitra123','2201SQN','admin','1');
  
COMMIT;

#
# Definition for the `awl` view : 
#

DROP VIEW IF EXISTS `awl`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `awl` AS 
  select 
    distinct `a`.`serno` AS `serno`,
    `a`.`sorsdt` AS `sorsdt`,
    `a`.`torsdt` AS `torsdt` 
  from 
    (`movement27` `a` join `l_in` `b`) 
  where 
    (((left(`a`.`sorsdt`,7) = left(_latin1'2007-01-31',7)) 
  or 
    (left(`a`.`torsdt`,7) = left(_latin1'2007-01-31',7))) and (`a`.`movcode` = _latin1'AWL') and (`a`.`serno` = `b`.`serno`) and isnull(`a`.`regular`));

#
# Definition for the `hosp` view : 
#

DROP VIEW IF EXISTS `hosp`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `hosp` AS 
  select 
    distinct `a`.`serno` AS `serno`,
    `a`.`sorsdt` AS `sorsdt`,
    `a`.`torsdt` AS `torsdt` 
  from 
    (`movement27` `a` join `l_in` `b`) 
  where 
    (((left(`a`.`sorsdt`,7) = left(_latin1'2007-01-31',7)) 
  or 
    (left(`a`.`torsdt`,7) = left(_latin1'2007-01-31',7))) and (`a`.`movcode` = _latin1'HOSP') and (`a`.`serno` = `b`.`serno`));

#
# Definition for the `l_in` view : 
#

DROP VIEW IF EXISTS `l_in`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `l_in` AS 
  select 
    distinct `a`.`serno` AS `serno`,
    `b`.`rank` AS `rank`,
    `b`.`rankcode` AS `rankcode`,
    `b`.`category` AS `category`,
    `b`.`name` AS `name`,
    `b`.`trade` AS `trade`,
    `b`.`movcode` AS `movcode`,
    `b`.`type` AS `type`,
    `a`.`sorsdt` AS `sorsdt`,
    `a`.`torsdt` AS `torsdt`,
    `b`.`unit` AS `unit` 
  from 
    (`movement27` `a` join `personal_info27` `b`) 
  where 
    (((left(`a`.`sorsdt`,7) = left(_latin1'2007-01-31',7)) 
  or 
    (left(`a`.`torsdt`,7) = left(_latin1'2007-01-31',7))) and (`a`.`movcode` = _latin1'L_IN') and (`a`.`serno` = `b`.`serno`)) union 
  select 
    distinct `a`.`serno` AS `serno`,
    `b`.`rank` AS `rank`,
    `b`.`rankcode` AS `rankcode`,
    `b`.`category` AS `category`,
    `b`.`name` AS `name`,
    `b`.`trade` AS `trade`,
    `b`.`movcode` AS `movcode`,
    `b`.`type` AS `type`,
    `a`.`sorsdt` AS `sorsdt`,
    `a`.`torsdt` AS `torsdt`,
    `b`.`unit` AS `unit` 
  from 
    (`movement27` `a` join `personal_info27` `b`) 
  where 
    ((`a`.`movcode` = _latin1'L_IN') and isnull(`a`.`p_t_out`) and isnull(`a`.`sorsdt`) and (`a`.`serno` = `b`.`serno`) and (left(`a`.`torsdt`,7) < left(_latin1'2007-01-31',7)));

#
# Definition for the `leav` view : 
#

DROP VIEW IF EXISTS `leav`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `leav` AS 
  select 
    distinct `a`.`serno` AS `serno`,
    `a`.`sorsdt` AS `sorsdt`,
    `a`.`torsdt` AS `torsdt` 
  from 
    (`movement27` `a` join `l_in` `b`) 
  where 
    (((left(`a`.`sorsdt`,7) = left(_latin1'2007-01-31',7)) 
  or 
    (left(`a`.`torsdt`,7) = left(_latin1'2007-01-31',7))) and (`a`.`movcode` = _latin1'LEAVE') and (`a`.`serno` = `b`.`serno`));

#
# Definition for the `mrss` view : 
#

DROP VIEW IF EXISTS `mrss`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `mrss` AS 
  select 
    `l_in`.`serno` AS `serno`,
    `l_in`.`rank` AS `rank`,
    `l_in`.`rankcode` AS `rankcode`,
    `l_in`.`category` AS `category`,
    `l_in`.`name` AS `name`,
    `l_in`.`trade` AS `trade`,
    `l_in`.`unit` AS `unit`,
    `l_in`.`movcode` AS `movcode`,
    `l_in`.`type` AS `type`,
    `l_in`.`torsdt` AS `lin_fm`,
    `l_in`.`sorsdt` AS `lin_to`,
    (`l_in`.`sorsdt` - `l_in`.`torsdt`) AS `lin_tot`,
    `leav`.`sorsdt` AS `lv_fm`,
    `leav`.`torsdt` AS `lv_to`,
    (`leav`.`torsdt` - `leav`.`sorsdt`) AS `lv_tot`,
    `td`.`sorsdt` AS `td_fm`,
    `td`.`torsdt` AS `td_to`,
    (`td`.`torsdt` - `td`.`sorsdt`) AS `td_tot`,
    `awl`.`sorsdt` AS `awl_fm`,
    `awl`.`torsdt` AS `awl_to`,
    (`awl`.`torsdt` - `awl`.`sorsdt`) AS `awl_tot`,
    `hosp`.`sorsdt` AS `MH_fm`,
    `hosp`.`torsdt` AS `MH_to`,
    (`hosp`.`torsdt` - `hosp`.`sorsdt`) AS `MH_tot` 
  from 
    ((((`l_in` left join `leav` on((`leav`.`serno` = `l_in`.`serno`))) left join `td` on((`td`.`serno` = `l_in`.`serno`))) left join `awl` on((`awl`.`serno` = `l_in`.`serno`))) left join `hosp` on((`hosp`.`serno` = `l_in`.`serno`)));

#
# Definition for the `td` view : 
#

DROP VIEW IF EXISTS `td`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `td` AS 
  select 
    distinct `a`.`serno` AS `serno`,
    `a`.`sorsdt` AS `sorsdt`,
    `a`.`torsdt` AS `torsdt` 
  from 
    (`movement27` `a` join `l_in` `b`) 
  where 
    (((left(`a`.`sorsdt`,7) = left(_latin1'2007-01-31',7)) 
  or 
    (left(`a`.`torsdt`,7) = left(_latin1'2007-01-31',7))) and (`a`.`movcode` = _latin1'TD') and (`a`.`serno` = `b`.`serno`));

