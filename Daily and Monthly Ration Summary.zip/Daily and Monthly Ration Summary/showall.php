<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>27WG:: Movement In</title>

<script type="text/JavaScript" src="scripts/test.js"></script>

 <link href="stylesheets/style.css" rel="stylesheet" type="text/css">

<style type="text/css">
#sortby {
	position:absolute;
	left:11px;
	top:150px;
	width:226px;
	height:85px;
	padding: 0px;
	margin: 0px;
}
</style>

<?php 
include_once ("index.php");
include_once("function.php");
include_once ("sortby.php");
session_start();

dbconnect();
		switch($_SESSION['unit']) {
			case "27WG":
				$table1 = "personal_info27";
	 	 	 	$table2 = "movement27";
				break;
			case "37SQN":
				$table1 = "personal_info37";
	 	 	 	$table2 = "movement37";
				break;
			case "108SQN":
				$table1 = "personal_info108";
	 	 	 	$table2 = "movement108";
				break;
			case "2201SQN":
				$table1 = "personal_info2201";
	 	 	 	$table2 = "movement2201";
				break;
			case "2224SQN":
				$table1 = "personal_info2224";
	 	 	 	$table2 = "movement2224";
				break;
			case "2254SQN":
				$table1 = "personal_info2254";
	 	 	 	$table2 = "movement2254";
				break;
			case "171SU":
				$table1 = "personal_info171";
	 	 	 	$table2 = "movement171";
				break;
			case "777SU":
				$table1 = "personal_info777";
	 	 	 	$table2 = "movement777";
				break;
			case "853SU":
				$table1 = "personal_info853";
	 	 	 	$table2 = "movement853";
				break;
			case "478MOF":
				$table1 = "personal_info478";
	 	 	 	$table2 = "movement478";
				break;
			case "308TRU":
				$table1 = "personal_info308";
	 	 	 	$table2 = "movement308";
				break;
			case "342TRU":
				$table1 = "personal_info342";
	 	 	 	$table2 = "movement342";
				break;
			case "607GRDFLT":
				$table1 = "personal_info607";
	 	 	 	$table2 = "movement607";
				break;
			}
 ob_start();		 
if(isset($_POST['action']) && $_POST['action'] == 'submitted')
{
  if($_POST['radiobutton'] == 'AIRMEN')
  {
	if ($_POST['field'] == 'SERNO')
	{
	$query = "select serno service_no,rank,name,trade,status,movcode attendance,type Strength from ".$table1." where unit = '$_SESSION[unit]' and type in ('TD','POSTED_IN') and category in ('AIRMEN','SNCOs') order by serno";
	select_to_goodtable($query,11,PRESENT);
	}
	elseif($_POST['field'] == 'RANK')
	{
	$query = "select serno service_no,rank,name,trade,status,movcode attendance,type Strength from ".$table1." where unit = '$_SESSION[unit]' and type in ('TD','POSTED_IN') and category in ('AIRMEN','SNCOs') order by rankcode";
	select_to_goodtable($query,11,PRESENT);
	}
	else
	{
	$query = "select serno service_no,rank,name,trade,status,movcode attendance,type Strength from ".$table1." where unit = '$_SESSION[unit]' and type in ('TD','POSTED_IN') and category in ('AIRMEN','SNCOs') order by '$_POST[field]'";
	select_to_goodtable($query,11,PRESENT);
	}
  }
  elseif($_POST['radiobutton'] == 'NCs(E)')
  {
	if ($_POST['field'] == 'SERNO')
	{
	$query = "select serno service_no,rank,name,trade,status,movcode attendance,type Strength from ".$table1." where unit = '$_SESSION[unit]' and type in ('TD','POSTED_IN') and category in ('NCs(E)') order by serno";
	select_to_goodtable($query,11,PRESENT);
	}
	elseif($_POST['field'] == 'RANK')
	{
	$query = "select serno service_no,rank,name,trade,status,movcode attendance,type Strength from ".$table1." where unit = '$_SESSION[unit]' and type in ('TD','POSTED_IN') and category in ('NCs(E)') order by rankcode";
	select_to_goodtable($query,11,PRESENT);
	}
	else
	{
	$query = "select serno service_no,rank,name,trade,status,movcode attendance,type Strength from ".$table1." where unit = '$_SESSION[unit]' and type in ('TD','POSTED_IN') and category in ('NCs(E)') order by '$_POST[field]'";
	select_to_goodtable($query,11,PRESENT);
	}
  }
   		 $data=ob_get_contents();
		 $fp=fopen("$_SESSION[unit].html","w");
		 fwrite($fp,$data);
		 fclose($fp);
		 ob_end_flush();
		 //Converting HTML file format into PDF format
		 include_once("scripts/html2fpdf.php");
		$pdf=new HTML2FPDF();
		$pdf->AddPage();
		$fp1 = fopen("$_SESSION[unit].html","r");
		$strContent = fread($fp1, filesize("$_SESSION[unit].html"));
		fclose($fp1);
		$pdf->WriteHTML($strContent);
		$pdf->Output("$_SESSION[unit].pdf");
}

dbclose();
?>