 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>On-line MES Complaint</title>
	<meta http-equiv="Content-Language" content="English" />
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
	<meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="expires" content="-1" />
<script language="JavaScript" type="text/JavaScript">
	javascript:window.history.forward(1);
</script>
    	<link href="mes.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div id="container">
   <div id="container-header"><div id="container-name"><span>On-line </span>MES Complaint </div></div>
   <div id="container-eyecatcher"><img src="images/business_eyecatcher.jpg" width="668" height="138" /></div>
   <div id="container-content">
	
		    <h1>Remarks on MES Complaint </h1><hr/>
<form name="form1" id="form1" method="POST" action="<?php $_SERVER['PHP_SELF'] ?>">
<div align="center"><p>
<?php
if(isset($_POST['Submit']) && $_POST['Submit'] == 'Submit')
{
 $remarks = $_POST['Remarks'];
 if($_REQUEST['comno'] && $_POST['Remarks'] <> "")
 {
	while (list($key,$_POST['value']) = each($_POST['comno']))
 	{
  	mysql_query("update complaint set rectifydt = curdate(),remarks='$remarks' where comno = '$_POST[value]'") or die(mysql_error());
 	}
			echo "<table align = center>";
			echo "<tr><td><img src=images/inf.png align=middle/></td><td><strong>Records are updated...!!";
			echo "</strong></td></tr></table>";
 }
 else
 {
			echo "<table align = center>";
			echo "<tr><td><img src=images/inf.png align=middle/></td><td><strong>Please tick the checkbox for update...!!";
			echo "</strong></td></tr></table>";
 }
}

			$query = "select comno,fault,remarks from complaint where comtype = '$username' and subdiv = '$subdiv' and remarks in ('PENDING','UNDER PROGRESS','DOOR LOCKED','STORE N/A','SHO CERTIFICATE REQD') order by no";
select_block_complaint($query,1,2,$subdiv);
	?>
	   <table width="382" border="0" align="center">
  <tr>
    <th width="56" scope="row"><div align="left">Date</div></th>
    <th width="88" scope="row"><div align="left">:&nbsp;<strong><?php echo date("d-M-Y");?></strong></div></th>
    <th colspan="2" scope="row">&nbsp;</th>
    <th scope="row">&nbsp;</th>
  </tr>
  <tr>
    <th colspan="3" valign="top" scope="row"><div align="left">Remarks</div></th>
    <th colspan="2" valign="top" scope="row"><div align="left"><strong>Choose Remarks </strong></div></th>
    </tr>
  <tr>
    <th height="24" colspan="3" valign="top" scope="row"><div align="left">
      <input name="Remarks" type="text" value="" maxlength="50" readonly="1" />
    </div></th>
    <th colspan="2" valign="top" scope="row"><div align="left">
      <select name="Rem" onchange="document.form1.Remarks.value = document.form1.Rem.value">
        <option>--Select--</option>
        <option value="CONTRACTOR JOB">CONTRACTOR JOB</option>
        <option value="WRONG COMPLAINT">WRONG COMPLAINT</option>
        <option value="RAISE SEPARATE COMPLAINT">RAISE SEPARATE COMPLAINT</option>
        <option value="STORE N/A">STORE N/A</option>
		<option value="MINOR WORKS">MINOR WORKS</option>
		<option value="BSO">BSO</option>
		<option value="LOCATION NOT CLEAR">LOCATION NOT CLEAR</option>
	    <option value="SHO CERTIFICATE REQD">SHO CERTIFICATE REQD</option>
	    <option value="DUPLICATE COMPLAINT">DUPLICATE COMPLAINT</option>
		<option value="UNDER PROGRESS">UNDER PROGRESS</option>
        <option value="DOOR LOCKED">DOOR LOCKED</option>
		<option value="DONE">DONE</option>
		<option value="LETTER 2 WKS REQD">LETTER 2 WKS REQD</option>
        <option value="PERIODICAL JOB">PERIODICAL JOB</option>
		<option value="CONTACT US">CONTACT US</option>
       </select>
    </div></th>
    </tr>
  <tr>
    <th colspan="3" scope="row">&nbsp;</th>
    <th width="90" scope="row"><input type="submit" name="Submit" value="Submit" /></th>
    <td width="144">&nbsp;</td>
    </tr>
</table></p></div>
</form>
<hr/>
 </div> <!-- END of container-content -->
</div> <!-- END of container -->
</body>
</html>