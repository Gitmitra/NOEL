create or replace view l_in as
select distinct a.serno,rank,rankcode,category,name,trade,sorsdt,torsdt,unit from movement a,personal_info b
where (left(sorsdt,7) = left(curdate(),7) or left(torsdt,7) = left(curdate(),7))
and a.movcode = 'L_IN' and a.serno = b.serno
union
select distinct a.serno,rank,rankcode,category,name,trade,sorsdt,torsdt,unit from movement a,personal_info b
where a.movcode = 'L_IN' and p_t_out is null and sorsdt is null and a.serno = b.serno


create or replace view leav as
select distinct a.serno,a.sorsdt,a.torsdt from movement a,l_in b
where (left(a.sorsdt,7) = left(curdate(),7) or left(a.torsdt,7) = left(curdate(),7))
and a.movcode = 'LEAVE' and a.serno = b.serno

create or replace view td as
select distinct a.serno,a.sorsdt,a.torsdt from movement a,l_in b
where (left(a.sorsdt,7) = left(curdate(),7) or left(a.torsdt,7) = left(curdate(),7))
and a.movcode = 'TD' and a.serno = b.serno


create or replace view hosp as
select distinct a.serno,a.sorsdt,a.torsdt from movement a,l_in b
where (left(a.sorsdt,7) = left(curdate(),7) or left(a.torsdt,7) = left(curdate(),7))
and a.movcode = 'HOSP' and a.serno = b.serno

create or replace view awl as
select distinct a.serno,a.sorsdt,a.torsdt from movement a,l_in b
where (left(a.sorsdt,7) = left(curdate(),7) or left(a.torsdt,7) = left(curdate(),7))
and a.movcode = 'AWL' and a.serno = b.serno and a.regular is null