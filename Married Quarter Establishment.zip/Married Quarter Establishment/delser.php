<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link href="stylesheets/style.css" rel="stylesheet" type="text/css" />
</head>
<?php
include_once ("menutest.php");
include ("conn.php");

session_start();

$_SESSION['serno'] = $_POST[txtserno];
$_SESSION['state'] = $_POST[radiobutton];
if($_POST['radiobutton'] == 'status')
{
$query = "select * from qtr_offr where personalno = '$_POST[txtserno]'";
}
else
{
	if($_POST['radiobutton'] == 'nonstatus')
	{
	$query = "select * from qtr_offrnon where personalno = '$_POST[txtserno]'";
	}
	else
	{
	$query = "select * from qtr where serno= '$_POST[txtserno]'";
	}
}
$result = mysql_query($query) or die (mysql_error());
$rows = mysql_num_rows($result);

if ($rows >= 1)
{
header('Location: http://156.84.1.136/status/delete.php');
}
else {

?>
<body>
<table width="700" border="0" cellspacing="1">
  <tr>
    <th width="179" scope="col">&nbsp;</th>
    <th width="485" scope="col"><p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p></th>
    <th width="26" scope="col">&nbsp;</th>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><table width="253" border="0" cellspacing="1">
      <tr>
        <td width="338"><form id="form1" name="form1" method="post" action="<?php echo $_SERVER[PHP_SELF]?>">
            <table width="249" border="0" align="left" cellpadding="0" cellspacing="0">
              <tr>
                <td width="13" height="12"><img src="/status/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
                <td colspan="7" background="/status/images/table_r1_c2.gif"><img src="/status/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
                <td width="13"><img src="/status/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
              </tr>
              <tr>
                <td rowspan="6" background="/status/images/table_r2_c1.gif"><img src="/status/images/spacer.gif" alt="" name="table_r2_c1" width="1" height="1" border="0" id="table_r2_c1" /></td>
                <td width="67">&nbsp;</td>
                <td width="99" height="24"><div align="justify"><strong>Ser No</strong></div></td>
                <td width="45"><input name="txtserno" type="text" size="8" maxlength="10" /></td>
                <td width="3">&nbsp;</td>
                <td width="3">&nbsp;</td>
                <td width="3">&nbsp;</td>
                <td width="3">&nbsp;</td>
                <td rowspan="6" background="/status/images/table_r2_c3.gif."><img src="/status/images/spacer.gif" alt="" name="table_r2_c3" width="1" height="1" border="0" id="table_r2_c3" /></td>
              </tr>
              <tr></tr>
              <tr></tr>
              <tr></tr>
              <tr></tr>
              <tr>
                <td><input name="radiobutton" type="radio" value="status" />
                  <strong>Status</strong></td>
                <td><input name="radiobutton" type="radio" value="nonstatus" />
                  <strong>Non-Status</strong></td>
                <td><input name="Submit" type="submit" class="rollmenu" value="Find" /></td>
              </tr>
              <tr>
                <td><img src="/status/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
                <td colspan="7" background="/status/images/table_r3_c2.gif"><img src="/status/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
                <td><img src="/status/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
              </tr>
            </table>
        </form></td>
      </tr>
    </table></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
</body>

</html>
<?php } ?>