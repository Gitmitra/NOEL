<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Logout</title>
</head>
<script type="text/javascript">
history.clear()
</script>
<body>
</body>
</html>
<?php
include_once("function.php");
// Unset all of the session variables.
session_start();
$_SESSION = array();

// Finally, destroy the session.
session_destroy();
dbclose();

header("Location: http://156.84.5.30/");

?>