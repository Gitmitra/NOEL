<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Trade Matrix Nominal Roll</title>
</head>
<?php 
session_start();
if(empty($_SESSION['unit'])) 
{
	$host = $_SERVER['HTTP_HOST'];
	$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
	$extra = 'login.php';
	session_destroy();
	header("Location: http://$host$uri/$extra");
	exit();
}

include_once ("function.php");
dbconnect();
$unit = $_SESSION['unit'];
	switch($unit) {
			case "27WG":
				mysql_query("call matrixtrade_27()");
				mysql_query("call matrixtrade1_27()");
				break;
			case "37SQN":
				mysql_query("call matrixtrade_37()");
				mysql_query("call matrixtrade1_37()");
	 	 	 	break;
			case "108SQN":
				mysql_query("call matrixtrade_108()");
				mysql_query("call matrixtrade1_108()");
	 	 	 	break;
			case "2201SQN":
				mysql_query("call matrixtrade_2201()");
				mysql_query("call matrixtrade1_2201()");
				break;
			case "2224SQN":
				mysql_query("call matrixtrade_2224()");
				mysql_query("call matrixtrade1_2224()");
				break;
			case "2254SQN":
				mysql_query("call matrixtrade_2254()");
				mysql_query("call matrixtrade1_2254()");
				break;
			case "171SU":
				mysql_query("call matrixtrade_171()");
				mysql_query("call matrixtrade1_171()");
	 	 	 	break;
			case "777SU":
				mysql_query("call matrixtrade_777()");
				mysql_query("call matrixtrade1_777()");
				break;
			case "853SU":
				mysql_query("call matrixtrade_853()");
				mysql_query("call matrixtrade1_853()");
	 	 	 	break;
			case "478MOF":
				mysql_query("call matrixtrade_478()");
				mysql_query("call matrixtrade1_478()");
				break;
			case "308TRU":
				mysql_query("call matrixtrade_308()");
				mysql_query("call matrixtrade1_308()");
				break;
			case "342TRU":
				mysql_query("call matrixtrade_342()");
				mysql_query("call matrixtrade1_342()");
				break;
			case "607GRDFLT":
				mysql_query("call matrixtrade_607()");
				mysql_query("call matrixtrade1_607()");
				break;
			}

$trade="select trade,pstr,att, (pstr+att) as `TOTAL`,lev as `LEAVE`,td,hosp,awl, (lev+td+hosp+awl) as `NE`, (pstr+att)-(lev+td+hosp+awl) as `PRESENT` from tradematrix order by trade";
				include_once("tradematrix.php");
?>
</html>
