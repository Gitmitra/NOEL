<?php 
$trdresult=mysql_query("select trade from trade");
$rankresult=mysql_query("select rank from rank");
?>
<div id="addrec">
<table width="607" border="0" align="center">
 
  <tr class="welcome">
    <th width="601" align="center" valign="top" class="rollmenu" scope="col"><div align="left"><strong>Personal Information : Add </strong></div></th>
  </tr>
  <tr>
    <th align="center" valign="top" scope="col">&nbsp;</th>
  </tr>
  <tr>
    <th align="center" valign="top" scope="col"><form name="frmAdd" method="post" action="/drss/movin1.php"  >
      <table width="552" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="12"><img src="/drss/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
          <td colspan="6" background="/drss/images/table_r1_c2.gif"><img src="/drss/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
          <td width="13"><img src="/drss/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
        </tr>
        <tr>
          <td rowspan="5" background="/drss/images/table_r2_c1.gif"><img src="/drss/images/spacer.gif" alt="" name="table_r2_c1" width="1" height="1" border="0" id="table_r2_c1" /></td>
          <td width="65" height="24"><div align="left"><strong>Service No </strong></div></td>
          <td width="131"><div align="left">
            <input name="serno" type="text" id="serno" tabindex="1" size="10" readonly="1" value="<?php echo $_REQUEST[txtserno]; ?>"/>
          </div></td>
          <td width="83"><div align="left">Chk Suffix </div></td>
          <td width="92"><div align="left"><input name="chksfx" type="text" tabindex="2" size="1" maxlength="1" /></div></td>
          <td width="42"><div align="left"><strong>Rank</strong></div></td>
          <td width="113"><div align="left"><select name="rank" id="select" tabindex="3"><?php while ($rank=mysql_fetch_array($rankresult)) {
			?>
            <option><?php printf("%s", $rank[0]); ?></option>
            <?php } ?>
          </select></div></td>
          <td rowspan="5" background="/drss/images/table_r2_c3.gif."><img src="/drss/images/spacer.gif" alt="" name="table_r2_c3" width="1" height="1" border="0" id="table_r2_c3" /></td>
        </tr>
        <tr>
          <td><div align="left">Name</div></td>
          <td><div align="left">
            <input name="name" type="text" id="name2" tabindex="4" size="15" maxlength="20"/>
          </div></td>
          <td><div align="left"><strong>Trade</strong></div></td>
          <td width="92"><div align="left"><select name="trade" id="select2" tabindex="5"><?php while ($trade=mysql_fetch_array($trdresult)) {
			?>
            <option><?php printf("%s", $trade[0]);  ?></option>
      		<?php } ?>
          </select></div></td>
          <td width="42"><div align="left"><strong>Unit</strong></div></td>
          <td width="113"><div align="left"><input name="unit" type="text" size="10" maxlength="15" value="<?php echo $_SESSION['unit']; ?>" readonly="1"/>
          </div></td>
        </tr>
        <tr>
          <td><div align="left"><strong>Status</strong></div></td>
          <td><div align="left">
            <select name="status" tabindex="6">
              <option>L_IN</option>
              <option>L_OUT</option>
            </select>
</div></td>
          <td><div align="left">Movement</div></td>
          <td width="92"><div align="left"><input name="type" type="text" id="type" tabindex="7" size="10" readonly="1" value="<?php echo $_REQUEST[movcode]; ?>"/></div></td>
          <td><div align="left">TORS</div></td>
          <td><div align="left"><input name="p_in_dt" type="text" size="10" maxlength="10" readonly="1"/>
            <input name="Submit" type="button" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frmAdd.p_in_dt); return false;" value="..."/></div></td>
        </tr>
        <tr>
          <td><div align="left">Mov Date </div></td>
          <td><div align="left"><input name="indt" type="text" size="10" maxlength="10" readonly="1"/>
            <input name="Submit" type="button" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frmAdd.indt); return false;" value="..."/></div></td>
          <td>&nbsp;</td>
          <td >&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td colspan="2"><div align="right">
            <input type="hidden" name="add" value="submitted">
            <img border="0" onclick="addSave();" onmouseout="this.src='/drss/images/btn_save.jpg';" onmouseover="this.src='/drss/images/btn_save_02.jpg';" src="/drss/images/btn_save.jpg" /></div></td>
        </tr>
        <tr>
          <td><img src="/drss/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
          <td colspan="6" background="/drss/images/table_r3_c2.gif"><img src="/drss/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
          <td><img src="/drss/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
        </tr>
      </table>
        </form></th>
  </tr>
 
  <tr>
    <th align="center" valign="top" scope="col">&nbsp;</th>
  </tr>
  <tr>
    <th align="center" valign="top" scope="col"><p align="center" class="rollmenu">&nbsp;</p>    </th>
  </tr>
</table>
</div>
