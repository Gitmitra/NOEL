<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
include("conn.php");
session_start();
$_SESSION['rank'];
$_SESSION['state'];
$_SESSION['count'] = 1;

$result = mysql_query("select hit from counter");

$_SESSION['count'] = mysql_result($result, 0) + $_SESSION['count'];
mysql_query("update counter set hit = $_SESSION[count]");

$result1 = mysql_query("select last_login from user");
$row = mysql_fetch_array($result1);
?> 


<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Md Accomodation</title>
<style type="text/css">
<!--
.style2 {font-size: 18px}
.style6 {
	color: #CC0000;
	font-weight: bold;
}
.style7 {
	color: #0000FF;
	font-weight: bold;
}
body {
	background-image: url(images/b-052.gif);
}
.style11 {
	color: #FF6600;
	font-size: 18px;
}
.style14 {color: #CC0000; font-size: 18px; }
.style15 {font-size: 24px}
-->
</style>
<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body onload="MM_preloadImages('images/imageset1/icon_team_lock.gif')">
<table width="768" border="0" align="center" cellspacing="1">
  <tr>
    <th colspan="6" scope="col"><p>&nbsp;</p>
      <p><img src="images/mdbox.jpg" width="962" height="78" /></p>
      <p>&nbsp;</p></th>
  </tr>
  <tr>
    <td height="26" colspan="2">&nbsp;</td>
    <td width="163">&nbsp;</td>
    <td width="132" valign="top" class="style11"><div align="right" class="style15">Select Rank </div></td>
    <td width="462"><form id="form1" name="frmMain" method="post" action="/status/view.php">
      <p>
        <select name="txtrank">
          <option>AC ,LAC, SEP &amp; L/NK</option>
          <option>CPL &amp; NK</option>
          <option>SGT &amp; HAV</option>
          <option>JWO &amp; N/SUB</option>
          <option>WO ,MWO &amp; SUB</option>
          <option>FG OFFR</option>
          <option>FLT LT</option>
          <option>SQN LDR</option>
          <option>WG CDR</option>
        </select><input name="radiobutton" type="radio" value="status" />
        <span class="style14">Status 
        <input name="radiobutton" type="radio" value="nonstatus" />
        Non-Status</span>
        <input type="submit" name="Submit" value="Submit" />
      </p>
    </form>    </td>
    <td width="113">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="6">&nbsp;</td>
  </tr>
  <tr>
    <td width="72">&nbsp;</td>
    <td width="19"><img src="images/imageset1/icon_team.gif" alt="Click Me" name="Image2" width="18" height="18" border="0" id="Image2" /></td>
    <td colspan="3" class="style2">To check your married quarter status, select rank and submit ! </td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="6">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><a href="login.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image3','','images/imageset1/icon_team_lock.gif',1)"><img src="images/imageset1/icon_team_owned.gif" alt="For Administrator" name="Image3" width="18" height="18" border="0" id="Image3" /></a></td>
    <td colspan="2" class="style2">To administer, please <a href="login.php">click</a> here !! </td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2" class="style2">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2" class="style2">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><img src="images/rules.gif" alt="Click Me" name="Image2" width="18" height="18" border="0" id="Image2" /></td>
    <td colspan="2" class="style2"><a href="2009 OFFR RULES.pdf">Local Rules for Allotment of Officers </a></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2" class="style2">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><img src="images/rules.gif" alt="Click Me" name="Image2" width="18" height="18" border="0" id="Image2" /></td>
    <td colspan="3" class="style2"><a href="2009 PBORS RULES.pdf">Local Rules for Allotment of PBOR/NC(E) </a></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3" class="style2">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="6"><img src="images/blue.JPG" width="977" height="78" /></td>
  </tr>
  <tr>
    <td height="119" colspan="6">
      <p align="left"><span class="style14">This page is visited </span><span class="style7"><?php echo $_SESSION['count'] ?> </span><span class="style14">times</span></p>
      <p align="left"><span class="style14">Data last updated on</span><span class="style6"> 
      <label><span class="style7"><?php if (ereg ("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})",  $row['last_login'], $regs)) {echo "$regs[3]-$regs[2]-$regs[1]";}  ?></span></label>
      </span></p>
      <p align="right" class="style11">&nbsp;</p>
    </div></td>
  </tr>
</table>
</body>

</html>
