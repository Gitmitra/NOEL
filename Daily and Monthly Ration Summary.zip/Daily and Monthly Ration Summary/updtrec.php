<div id="updtrec">
<table width="550" border="0" align="center">
 
  <tr class="welcome">
    <th width="487" align="center" valign="top" class="rollmenu" scope="col"><div align="left"><strong>Movement In : Living In </strong></div></th>
  </tr>
  <tr>
    <th align="center" valign="top" scope="col">&nbsp;</th>
  </tr>
  <tr>
    <th align="center" valign="top" scope="col"><form name="frmupdt" method="post" action="/drss/movin1.php"  >
      <table width="544" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="12"><img src="/drss/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
          <td colspan="6" background="/drss/images/table_r1_c2.gif"><img src="/drss/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
          <td width="13"><img src="/drss/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
        </tr>
        <tr>
          <td rowspan="5" background="/drss/images/table_r2_c1.gif"><img src="/drss/images/spacer.gif" alt="" name="table_r2_c1" width="1" height="1" border="0" id="table_r2_c1" /></td>
          <td width="71" height="24"><div align="left"><strong>Service No </strong></div></td>
          <td width="93"><div align="left">
            <input name="serno" type="text" id="serno" tabindex="1" size="10" value="<?php echo $row[serno]; ?>" readonly="1" />
          </div></td>
          <td width="71"><div align="left">Chk Suffix </div></td>
          <td width="127"><div align="left"><input name="chksfx" type="text" tabindex="2" size="1" value="<?php echo $row[chksfx]; ?>" readonly="1"/></div></td>
          <td width="66"><div align="left"><strong>Rank</strong></div></td>
          <td width="90"><div align="left">
            <input name="rank" type="text" size="7" value="<?php echo $row[rank]; ?>" readonly="1"/>
          </div></td>
          <td rowspan="5" background="/drss/images/table_r2_c3.gif."><img src="/drss/images/spacer.gif" alt="" name="table_r2_c3" width="1" height="1" border="0" id="table_r2_c3" /></td>
        </tr>
        <tr>
          <td><div align="left">Name</div></td>
          <td><div align="left">
            <input name="name" type="text" tabindex="4" size="15" value="<?php echo $row[name]; ?>" readonly="1"/>
          </div></td>
          <td><div align="left"><strong>Trade</strong></div></td>
          <td width="127"><div align="left">
            <input name="trade" type="text" size="7" value="<?php echo $row[trade]; ?>" readonly="1"/>
          </div></td>
          <td width="66"><div align="left"><strong>Unit</strong></div></td>
          <td width="90"><div align="left"><input name="unit" type="text" size="10" maxlength="15" value="<?php echo $_SESSION['unit']; ?>" readonly="1"/>
          </div></td>
        </tr>
        <tr>
          <td><div align="left"><strong>Status</strong></div></td>
          <td><div align="left">
            <input name="status" type="text" value="L_IN" size="5" maxlength="5" readonly="1"/>
          </div></td>
          <td><div align="left">L/In Date </div></td>
          <td width="127"><div align="left"><input name="ldt" type="text" size="10" maxlength="10" readonly="1" /><input name="Submit" type="button" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frmupdt.ldt); return false;" value="..."/></div></td>
          <td>Mov Date</td>
          <td><div align="left"><input name="indt" type="text" size="10" maxlength="10" readonly="1" /><input name="Submit" type="button" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frmupdt.indt); return false;" value="..."/></div></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td width="127">&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td colspan="2"><div align="right">
            <input type="hidden" name="lin" value="submitted">
            <img border="0" onclick="updt();" onmouseout="this.src='/drss/images/btn_save.jpg';" onmouseover="this.src='/drss/images/btn_save_02.jpg';" src="/drss/images/btn_save.jpg" /></div></td>
        </tr>
        <tr>
          <td><img src="/drss/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
          <td colspan="6" background="/drss/images/table_r3_c2.gif"><img src="/drss/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
          <td><img src="/drss/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
        </tr>
      </table>
        </form></th>
  </tr>
  <tr>
    <th align="center" valign="top" scope="col">&nbsp;</th>
  </tr>
  <tr>
    <th align="center" valign="top" scope="col"><p align="center" class="rollmenu">&nbsp;</p>    </th>
  </tr>
</table>
</div>
