<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link href="stylesheets/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<table width="223" border="0" cellspacing="1">
  <tr>
    <td width="219"><form id="form1" name="form1" method="post" action="">
      <table width="217" border="0" align="left" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="12"><img src="/status/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
          <td colspan="7" background="/status/images/table_r1_c2.gif"><img src="/status/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
          <td width="13"><img src="/status/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
        </tr>
        <tr>
          <td rowspan="6" background="/status/images/table_r2_c1.gif"><img src="/status/images/spacer.gif" alt="" name="table_r2_c1" width="1" height="1" border="0" id="table_r2_c1" /></td>
          <td width="77"><strong>Ser No </strong></td>
          <td width="16" height="24">&nbsp;</td>
          <td width="82"><input name="txtserno" type="text" size="7" maxlength="7" /></td>
          <td width="4">&nbsp;</td>
          <td width="4">&nbsp;</td>
          <td width="4">&nbsp;</td>
          <td width="4">&nbsp;</td>
          <td rowspan="6" background="/status/images/table_r2_c3.gif."><img src="/status/images/spacer.gif" alt="" name="table_r2_c3" width="1" height="1" border="0" id="table_r2_c3" /></td>
        </tr>
        <tr></tr>
        <tr></tr>
        <tr></tr>
        <tr></tr>
        <tr>
          <td>&nbsp;</td>        
          <td>&nbsp;</td>
          <td><input name="Submit" type="submit" class="rollmenu" value="Find" /></td>
        </tr>
        <tr>
          <td><img src="/status/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
          <td colspan="7" background="/status/images/table_r3_c2.gif"><img src="/status/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
          <td><img src="/status/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
        </tr>
      </table>
    </form>    </td>
  </tr>
</table>
</body>
</html>
