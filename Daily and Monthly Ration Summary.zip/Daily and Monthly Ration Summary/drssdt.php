<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

 <link href="stylesheets/style.css" rel="stylesheet" type="text/css">
  <style type="text/css">
#drssdt {
	position:absolute;
	left:09px;
	top:150px;
	width:402px;
	height:85px;
	padding: 0px;
	margin: 0px;
}
</style>
<?php 
include_once ("index.php");
?> 

<body>
 <iframe width=174 height=189 name="gToday:normal:agenda.js" id="gToday:normal:agenda.js" src="/drss/scripts/ipopeng.htm" scrolling="no" frameborder="0" style="visibility:visible; z-index:999; position:absolute; top:-500px; left:-500px;"></iframe>
<div id="drssdt">
<table width="395" border="0" align="center">
  <tr>
    <th width="389" align="center" valign="top" scope="col">&nbsp;</th>
  </tr>
  <tr>
    <th align="center" valign="top" scope="col"><form name="frmdrss" action="<?php echo $_REQUEST['url'];?>" method="post" >
      <table width="88%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="12"><img src="../drss/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
          <td colspan="3" background="../drss/images/table_r1_c2.gif"><img src="../drss/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
          <td width="13"><img src="../drss/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
        </tr>
        <tr>
          <td height="31" background="../drss/images/table_r2_c1.gif"></td>
          <td colspan="2" valign="middle">DRSS for the date <input name="dtdrss" type="text" size="10" maxlength="10" readonly="1"/> 
            <input name="Submit" type="button" onclick="if(self.gfPop)gfPop.fPopCalendar(document.frmdrss.dtdrss); return false;" value="..."/></td>
          <td>&nbsp;</td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td background="../drss/images/table_r2_c1.gif"></td>
          <td width="92"><label>
            <div align="right"> L/IN DRSS
              <input name="radiobtn" type="radio" value="L_IN" />
            </div>
          </label></td>
          <td width="120"><label>
            <div align="right">L/OUT DRSS
              <input name="radiobtn" type="radio" value="L_OUT" />
            </div>
          </label></td>
          <td width="104"><input type="hidden" name="drss" value="submitted"><img src="images/btn_submit.gif" name="Image10" width="65" height="20" border="0" onClick="submit();"></td>
          <td background="../drss/images/table_r2_c3.gif."></td>
        </tr>
        
        <tr>
          <td><img src="../drss/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
          <td colspan="3" background="../drss/images/table_r3_c2.gif"><img src="../drss/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
          <td><img src="../drss/images/table_r3_c3.gif" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
        </tr>
      </table>
        </form></th>
  </tr>
   <tr>
    <th align="center" valign="top" scope="col">&nbsp;</th>
  </tr>
</table>
</div>
</body>
</html>


