 <div id="container-content">
		    <h1>For Stn Cdr's Perusal </h1>
			<hr/>
	  
	   <table width="657" border="0" align="center">
  <tr>
    <th width="62" valign="bottom" scope="row"><div align="left">Date</div></th>
    <th width="5" valign="bottom" scope="row">:</th>
    <td colspan="2" valign="bottom"><strong><?php echo date("d-M-Y");?></strong></td>
    <?php 
	$d = date("Y")-1;
	$e = $d+3;
	?>
	<form id="form1" method="get" action="./subdiv.php">
	<td width="147"><strong>Year</strong>      <select name="yr">
               <?php for($i=$d;$i<$e;$i++)
			 {
			 if($i==$d+1) { ?>
              
			  <option selected="selected"><?php echo $i ?></option>
              <?php } else {?>
			  <option><?php echo $i ?></option>
			  <?php } }?>
      </select></td>
    <td colspan="3"><strong>Month </strong>
      <select name="mnth">
  <option>JAN</option>
  <option>FEB</option>
  <option>MAR</option>
  <option>APR</option>
  <option>MAY</option>
  <option>JUN</option>
  <option>JUL</option>
  <option>AUG</option>
  <option>SEP</option>
  <option>OCT</option>
  <option>NOV</option>
  <option>DEC</option>
</select>
      <label>
      <input type="submit" name="stncdr" value="Submit" />
      </label></td>
      </form>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <th scope="row">&nbsp;</th>
    <td width="12">&nbsp;</td>
    <td width="68">&nbsp;</td>
    <td colspan="2" >&nbsp;</td>
    <td colspan="2" style="color: #3300FF">&nbsp;</td>
  </tr>
  <tr>
    <th colspan="4" bgcolor="#DBDBDB" scope="row"><strong>Complaints</strong></th>
    <td colspan="2" bgcolor="#EBEBEB" ><div align="center"><strong>Monthly Basis</strong></div></td>
    <td width="132" rowspan="2" valign="bottom" bgcolor="#DBDBDB" style="color: #3300FF"><strong>Complaints pending</strong> <strong>after two reminders</strong></td>
    <td width="50" rowspan="2" valign="bottom" style="color: #3300FF">&nbsp;</td>
  </tr>
  <tr>
    <th colspan="4" bgcolor="#DBDBDB" scope="row"><span class="style2">RESIDENTIAL</span></th>
    <td bgcolor="#EBEBEB" style="color:#FF0000"><strong>Complaints Pending </strong></td>
    <td width="147" bgcolor="#EBEBEB" style="color: #009900"><strong>Complaints Cleared</strong></td>
    </tr>
  <tr>
    <th colspan="4" bgcolor="#DBDBDB" scope="row"><div align="center"><strong>BR</strong></div></th>
    <td bgcolor="#EBEBEB" style="color:#FF0000"><div align="center"><strong><?php echo $respen[0][0] ?></strong></div></td>
    <td bgcolor="#EBEBEB" style="color:#009900"><div align="center"><strong><?php echo $resclr[0][0] ?></strong></div></td>
    <td bgcolor="#DBDBDB" style="color:#3300FF"><div align="center"><strong><?php echo $resrem[0][0] ?></strong></div></td>
    <td style="color:#3300FF">&nbsp;</td>
  </tr>
  <tr>
    <th colspan="4" bgcolor="#DBDBDB" scope="row"><div align="center"><strong>EM</strong></div></th>
    <td bgcolor="#EBEBEB" style="color:#FF0000"><div align="center"><strong><?php echo $respen[1][0] ?></strong></div></td>
    <td bgcolor="#EBEBEB" style="color:#009900"><div align="center"><strong><?php echo $resclr[1][0] ?></strong></div></td>
    <td bgcolor="#DBDBDB" style="color:#3300FF"><div align="center"><strong><?php echo $resrem[1][0] ?></strong></div></td>
    <td style="color:#3300FF">&nbsp;</td>
  </tr>
  <tr>
    <th colspan="4" bgcolor="#DBDBDB" scope="row"><span class="style2">TECHNICAL</span></th>
    <td bgcolor="#EBEBEB" style="color:#FF0000">&nbsp;</td>
    <td bgcolor="#EBEBEB" style="color:#009900">&nbsp;</td>
    <td bgcolor="#DBDBDB" style="color:#3300FF">&nbsp;</td>
    <td style="color:#3300FF">&nbsp;</td>
  </tr>
  <tr>
    <th colspan="4" bgcolor="#DBDBDB" scope="row">BR</th>
    <td bgcolor="#EBEBEB" style="color:#FF0000"><div align="center"><strong><?php echo $respen[2][0] ?></strong></div></td>
    <td bgcolor="#EBEBEB" style="color:#009900"><div align="center"><strong><?php echo $resclr[2][0] ?></strong></div></td>
    <td bgcolor="#DBDBDB" style="color:#3300FF"><div align="center"><strong><?php echo $resrem[2][0] ?></strong></div></td>
    <td style="color:#3300FF">&nbsp;</td>
  </tr>
  <tr>
    <th colspan="4" valign="top" bgcolor="#DBDBDB" scope="row">EM</th>
    <td bgcolor="#EBEBEB" style="color:#FF0000"><div align="center"><strong><?php echo $respen[3][0] ?></strong></div></td>
    <td bgcolor="#EBEBEB" style="color:#009900"><div align="center"><strong><?php echo $resclr[3][0] ?></strong></div></td>
    <td bgcolor="#DBDBDB" style="color: #3300FF"><div align="center"><strong><?php echo $resrem[3][0] ?></strong></div></td>
    <td style="color: #3300FF">&nbsp;</td>
  </tr>
  <tr>
    <th valign="top" scope="row">&nbsp;</th>
    <th valign="top" scope="row">&nbsp;</th>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
    <td style="color: #339900">&nbsp;</td>
    <td colspan="2" style="color: #339900">&nbsp;</td>
  </tr>
  <tr>
    <th height="24" valign="middle" scope="row"><a href="logout.php"><img src="images/logout_btn.jpg" alt="" width="58" height="19" border="0" /></a></th>
    <th valign="top" scope="row">&nbsp;</th>
    <td colspan="3"><a href="passwd.php"><img src="images/passwd.gif" width="137" height="20" border="0" /></a></td>
    <form id="form1" method="get" action="./process.php">
	<td colspan="3" align="left" valign="middle" ><select name="sqn" id="select" ><option value="">--Select--</option>
			  <?php while ($location=mysql_fetch_array($locresult)) {
			?>
			
            <option value="<?php printf("%s", $location[0]);?>"><?php printf("%s", $location[0]);?></option>
            <?php } ?>
        </select>
	  <input type="hidden" name="show" value="submitted" />
			<input name="imageField" type="image" src="images/show.jpg" />
    </form></tr>
</table>
      	 <hr/> 
  </div> <!-- END of container-content -->
	
