<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Trade Matrix Nominal Roll</title>
</head>
<?php
ob_start();	
?>
<body>
<table width="647" border="0" align="left">
  <tr>
    <td colspan="11"><div align="center" class="style1">
      <h2>TRADE MATRIX <?php echo date("d-M-Y"); ?></h2>
    </div></td>
  </tr>
  <tr>
    <td width="111"><?php echo $_SESSION['unit'];?></td>
    <td width="55"><img border="0" onclick="history.back();" onmouseout="this.src='/drss/images/btn_back.jpg';" onmouseover="this.src='/drss/images/btn_back_02.jpg';" src="/drss/images/btn_back.jpg" /></td>
    <td width="55">&nbsp;</td>
    <td width="55">&nbsp;</td>
    <td width="55">&nbsp;</td>
    <td width="55">&nbsp;</td>
    <td width="55">&nbsp;</td>
    <td width="55">&nbsp;</td>
    <td width="55">&nbsp;</td>
    <td width="55"><?php echo "<a href=trade$_SESSION[unit].pdf>Print Preview</a>"; ?></td>
    <td width="55">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="11"><?php select_to_table($trade,2,2); ?></td>
  </tr>
  <tr>
    <td colspan="9">&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
</table>
</body>
<?php
$data=ob_get_contents();
		 $fp=fopen("trade$_SESSION[unit].html","w");
		 fwrite($fp,$data);
		 fclose($fp);
		 ob_end_flush();
		 //Converting HTML file format into PDF format
		 include_once("scripts/html2fpdf.php");
		$pdf=new HTML2FPDF();
		$pdf->AddPage();
		$fp1 = fopen("trade$_SESSION[unit].html","r");
		$strContent = fread($fp1, filesize("trade$_SESSION[unit].html"));
		fclose($fp1);
		$pdf->WriteHTML($strContent);
		$pdf->Output("trade$_SESSION[unit].pdf");
?>

</html>
