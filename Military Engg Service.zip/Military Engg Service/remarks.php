<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>On-line MES Complaint</title>
	<meta http-equiv="Content-Language" content="English" />
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
	<meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="expires" content="-1" />
<script language="JavaScript" type="text/JavaScript">
	javascript:window.history.forward(1);
</script>
    	<link href="mes.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div id="container">
   <div id="container-header"><div id="container-name"><span>On-line </span>MES Complaint </div></div>
   <div id="container-eyecatcher"><img src="images/business_eyecatcher.jpg" width="668" height="138" /></div>
   <div id="container-content">
	
		    <h1>Remarks on MES Complaint </h1>
			<hr/>
<?php
if(empty($_GET['offset']))
{$offset=0;}
else
{$offset=$_GET['offset'];}
 
$subdiv=$_GET['subdiv'];

$result = mysql_query("select comno,fault,remarks from complaint where comtype = '$username' and subdiv = '$_GET[subdiv]' and remarks = 'PENDING' order by no limit $offset, ". 1);
while($row = mysql_fetch_array($result))
{
?>   	    
	   <form name="form1" id="form1" method="POST" action="<?php $_SERVER['PHP_SELF'] ?>">
	   <table width="579" border="0" align="center">
  <tr>
    <th width="59" scope="row"><div align="left">Date</div></th>
    <th width="50" scope="row">:</th>
    <td><strong><?php echo date("d-M-Y");?></strong></td>
    <td><div align="left"><strong>Complaint No </strong></div></td>
    <td><input type="text" name="comno"  value="<?php echo $row['comno']; ?>" readonly="1"/></td>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <th scope="row">&nbsp;</th>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <th valign="top" scope="row"><div align="left">Fault</div></th>
    <th valign="top" scope="row">:</th>
    <td colspan="2" valign="top"><textarea name="fault" cols="30" rows="4" readonly="readonly"><?php echo $row['fault'];?></textarea></td>
    <td valign="bottom"><strong>Choose Remarks </strong></td>
  </tr>
  <tr>
    <th height="36" valign="top" scope="row"><div align="left">Remarks</div></th>
    <th valign="top" scope="row">:</th>
    <td colspan="2" valign="top"><input name="Remarks" type="text" value="<?php echo $row['remarks'];?>" size="40" readonly="readonly" /></td>
    <td height="36" valign="top"><select name="Rem" onchange="document.form1.Remarks.value = document.form1.Rem.value">
      <option>--Select--</option>
	  <option value="CONTRACTOR JOB">CONTRACTOR JOB</option>
      <option value="WRONG COMPLAINT">WRONG COMPLAINT</option>
      <option value="RAISE SEPARATE COMPLAINT">RAISE SEPARATE COMPLAINT</option>
	  <option value="STORE N/A">STORE N/A</option>
	  <option value="MINOR WORKS">MINOR WORKS</option>
	  <option value="BSO">BSO</option>
	  <option value="LOCATION NOT CLEAR">LOCATION NOT CLEAR</option>
	  <option value="SHO CERTIFICATE REQD">SHO CERTIFICATE REQD</option>
	  <option value="DUPLICATE COMPLAINT">DUPLICATE COMPLAINT</option>
      <option value="UNDER PROGRESS">UNDER PROGRESS</option>
	  <option value="DOOR LOCKED">DOOR LOCKED</option>
	  <option value="DONE">DONE</option>
	  <option value="LETTER 2 WKS REQD">LETTER 2 WKS REQD</option>
      <option value="PERIODICAL JOB">PERIODICAL JOB</option>
	  <option value="CONTACT US">CONTACT US</option>
    </select></td>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <th scope="row">&nbsp;</th>
    <td width="92">&nbsp;</td>
    <td width="93">&nbsp;</td>
    <td width="263"><label>
      <input type="submit" name="Submit" value="Submit" />
    </label></td>
  </tr>
</table>
       </form>
<?php
}
nav1($offset,$subdiv,$_GET['Remarks']);

if(isset($_POST['Submit']) && $_POST['Submit'] == 'Submit')
{
$comno = $_POST['comno'];
$remarks = $_POST['Remarks'];
$result3=mysql_query("update complaint set rectifydt = curdate(),remarks='$remarks' where comno = '$comno'");
}

?>
 	<hr/>
  </div> <!-- END of container-content -->
</div> <!-- END of container -->
</body>
</html>
