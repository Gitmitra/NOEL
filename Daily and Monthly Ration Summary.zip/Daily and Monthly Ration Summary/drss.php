<?php 
session_start();
if(empty($_SESSION['unit'])) 
{
	$host = $_SERVER['HTTP_HOST'];
	$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
	$extra = 'login.php';
	session_destroy();
	header("Location: http://$host$uri/$extra");
	exit();
}

include_once ("function.php");
dbconnect();

if(isset($_POST['drss']) && $_POST['drss'] == 'submitted')
{
$drss_dt = $_POST['dtdrss'];
$type1 = array('POSTED_IN','TD');
$movcode1 = array('LEAVE','TD','HOSP','AWL');
$category1 = array('SNCOs','AIRMEN','NCs(E)');

$unit = $_SESSION['unit'];
	switch($unit) {
			case "27WG":
				$table1 = "personal_info27";
	 	 	 	$table2 = "movement27";
				break;
			case "37SQN":
				$table1 = "personal_info37";
	 	 	 	$table2 = "movement37";
				break;
			case "108SQN":
				$table1 = "personal_info108";
	 	 	 	$table2 = "movement108";
				break;
			case "2201SQN":
				$table1 = "personal_info2201";
	 	 	 	$table2 = "movement2201";
				break;
			case "2224SQN":
				$table1 = "personal_info2224";
	 	 	 	$table2 = "movement2224";
				break;
			case "2254SQN":
				$table1 = "personal_info2254";
	 	 	 	$table2 = "movement2254";
				break;
			case "171SU":
				$table1 = "personal_info171";
	 	 	 	$table2 = "movement171";
				break;
			case "777SU":
				$table1 = "personal_info777";
	 	 	 	$table2 = "movement777";
				break;
			case "853SU":
				$table1 = "personal_info853";
	 	 	 	$table2 = "movement853";
				break;
			case "478MOF":
				$table1 = "personal_info478";
	 	 	 	$table2 = "movement478";
				break;
			case "308TRU":
				$table1 = "personal_info308";
	 	 	 	$table2 = "movement308";
				break;
			case "342TRU":
				$table1 = "personal_info342";
	 	 	 	$table2 = "movement342";
				break;
			case "607GRDFLT":
				$table1 = "personal_info607";
	 	 	 	$table2 = "movement607";
				break;
			}

$status = $_POST['radiobtn'];

foreach($type1 as $value)
{	
	$type = $value;
	foreach($category1 as $value)
	{
		$category = $value;
		$array = compact("type","unit","category","status");
		$sncot[]= fetch_row($table1,$array);
	}
}

foreach($movcode1 as $value)
{
	$movcode = $value;
	foreach($category1 as $value)
	{
		$category = $value;
		$array1 = compact("movcode","unit","category","status");
		$sncom[] = fetch_row($table1,$array1);
	}
}

$stot =$sncot[0][0] + $sncot[3][0];
$sne = $sncom[0][0] + $sncom[3][0] + $sncom[6][0] + $sncom[9][0];
$seff = $stot - $sne;

$atot = $sncot[1][0] + $sncot[4][0];
$ane = $sncom[1][0] + $sncom[4][0] + $sncom[7][0] + $sncom[10][0];
$aeff = $atot - $ane;

$ntot = $sncot[2][0] + $sncot[5][0];
$nne = $sncom[2][0] + $sncom[5][0] + $sncom[8][0] + $sncom[11][0];
$neff = $ntot - $nne;

if($status=='L_IN')
{
$movin= "select distinct a.movcode as movement,b.serno,rank,name,trade from ".$table2." a, ".$table1." b
where a.serno = b.serno and b.unit = '$_SESSION[unit]' and status = '$_POST[radiobtn]'
and a.indt = '$drss_dt' 
union
select distinct a.movcode as movement,b.serno,rank,name,trade from ".$table2." a, discard b
where a.serno = b.serno and b.unit = '$_SESSION[unit]' and status = '$_POST[radiobtn]'
and a.indt = '$drss_dt' 
union
select type as movement,serno,rank,name,trade from ".$table1." where indt='$drss_dt' and unit='$_SESSION[unit]' and type='POSTED_IN' and status = '$_POST[radiobtn]' order by 1";

$movout= "select distinct a.movcode as movement,b.serno,rank,name,trade from ".$table2." a, ".$table1." b
where a.serno = b.serno and b.unit = '$_SESSION[unit]' and status = '$_POST[radiobtn]'
and a.outdt = '$drss_dt' 
union
select type as movement,serno,rank,name,trade from discard where outdt = '$drss_dt' and unit = '$_SESSION[unit]' and type in ('POSTED_OUT','CTD','DISCHARGE') and status = '$_POST[radiobtn]'
union 
select distinct a.movcode as movement,b.serno,rank,name,trade from ".$table2." a, ".$table1." b
where a.serno = b.serno and b.unit = '$_SESSION[unit]' and a.movcode = 'L_IN'
and a.outdt = '$drss_dt' order by 1";
}
elseif ($status=='L_OUT')
{
$movin= "select distinct a.movcode as movement,b.serno,rank,name,trade from ".$table2." a, ".$table1." b
where a.serno = b.serno and b.unit = '$_SESSION[unit]' and status = '$_POST[radiobtn]'
and a.indt = '$drss_dt' 
union
select distinct a.movcode as movement,b.serno,rank,name,trade from ".$table2." a, discard b
where a.serno = b.serno and b.unit = '$_SESSION[unit]' and status = '$_POST[radiobtn]'
and a.indt = '$drss_dt' 
union
select type as movement,serno,rank,name,trade from ".$table1." where indt = '$drss_dt' and unit = '$_SESSION[unit]' and type = 'POSTED_IN' and status = '$_POST[radiobtn]' order by 1";

$movout= "select distinct a.movcode as movement,b.serno,rank,name,trade from ".$table2." a, ".$table1." b
where a.serno = b.serno and b.unit = '$_SESSION[unit]' and status = '$_POST[radiobtn]'
and a.outdt = '$drss_dt' 
union
select type as movement,serno,rank,name,trade from discard where outdt = '$drss_dt' and unit = '$_SESSION[unit]' and type in ('POSTED_OUT','CTD','DISCHARGE') and status = '$_POST[radiobtn]' 
union
select distinct a.movcode as movement,b.serno,rank,name,trade from ".$table2." a, ".$table1." b
where a.serno = b.serno and b.unit = '$_SESSION[unit]' and a.movcode = 'L_OUT'
and a.outdt = '$drss_dt' order by 1";

}
?>
<title>DRSS</title>
<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	left:7px;
	top:306px;
	width:707px;
	height:45px;
	z-index:1;
}
-->
</style>
<body>
<div id="Layer1">
  <table width="705" border="0" align="left">
  <tr>
    <td><div align="center"><strong><u>MOV IN</u></strong> </div></td>
    <td>&nbsp;</td>
    <td><div align="center"><strong><u>MOV OUT</u></strong></div></td>
  </tr>
  <tr>
    <td valign="top"><?php select_to_table($movin,0,2);?></td>
    <td valign="top">&nbsp;</td>
    <td valign="top"><?php select_to_table($movout,0,2);?></td>
  </tr>
  <tr>
    <td valign="top">&nbsp;</td>
    <td valign="top">&nbsp;</td>
    <td valign="top">&nbsp;</td>
  </tr>
  <tr>
    <td width="342"><img border="0" onClick="history.back();" onMouseOut="this.src='/drss/images/btn_back.jpg';" onMouseOver="this.src='/drss/images/btn_back_02.jpg';" src="/drss/images/btn_back.jpg" /></td>
    <td width="10">&nbsp;</td>
    <td width="348">
      <div align="left"><img src="icons/print.png" width="32" height="27" onClick="window.print();"><strong>Print</strong></div></td></tr>
</table>
</div>
 <table width="664" border="0" align="left">
  
  <tr>
    <th height="21" colspan="2" align="center" valign="top" scope="col">&nbsp;</th>
  </tr>
  <tr>
    <th colspan="2" align="center" valign="top" scope="col"><p><u>DRSS : SNCOs / AIRMEN / NCs(E):</u><u><?php echo $_POST['radiobtn']; ?></u></p>    </th>
  </tr>
  <tr>
    <th colspan="2" align="center" valign="top" scope="col"></th>
  </tr>
  <tr>
    <th width="529" align="center" valign="top" scope="col"><div align="left"><ul><?php echo $_SESSION['unit']; ?></ul></div></th>
    <th width="231" align="center" valign="top" scope="col"><p align="left">Date: <?php echo $drss_dt; ?></p>
      <p align="left">POR:</p></th>
  </tr>
  <tr>
    <th height="167" colspan="2" align="center" valign="top" scope="col">
      <table width="100%" border="0" align="left" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="12"><img src="../status/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
          <td colspan="10" background="../status/images/table_r1_c2.gif"><img src="../status/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
          <td width="13"><img src="../status/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
        </tr>
        <tr>
          <td height="29" background="../status/images/table_r2_c1.gif"></td>
          <td width="77"><div align="center"><strong>DETAILS</strong></div></td>
          <td width="60"><div align="center"><strong>P / STR </strong></div></td>
          <td width="60"><div align="center"><strong>ATT</strong></div></td>
          <td width="60"><div align="center"><strong>TOTAL</strong></div></td>
          <td width="70"><div align="center"><strong>LEAVE</strong></div></td>
          <td width="57"><div align="center"><strong>TD</strong></div></td>
          <td width="54"><div align="center"><strong>HOSP</strong></div></td>
          <td width="50"><div align="center"><strong>AWL</strong></div></td>
          <td width="50"><div align="center"><strong>NE</strong></div></td>
          <td width="94"><div align="center"><strong>EFFECTIVE</strong></div></td>
          <td background="../status/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="27" background="../status/images/table_r2_c1.gif"></td>
          <td>SNCOs</td>
          <td><div align="center"><?php echo $sncot[0][0];?></div></td>
          <td><div align="center"><?php echo $sncot[3][0];?></div></td>
          <td><div align="center"><?php echo $stot;?></div></td>
          <td><div align="center"><?php echo $sncom[0][0];?></div></td>
          <td><div align="center"><?php echo $sncom[3][0];?></div></td>
          <td><div align="center"><?php echo $sncom[6][0];?></div></td>
          <td><div align="center"><?php echo $sncom[9][0];?></div></td>
          <td><div align="center"><?php echo $sne;?></div></td>
          <td><div align="center"><?php echo $seff;?></div></td>
          <td background="../status/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="26" background="../status/images/table_r2_c1.gif"></td>
          <td>AIRMEN</td>
          <td><div align="center"><?php echo $sncot[1][0];?></div></td>
          <td><div align="center"><?php echo $sncot[4][0];?></div></td>
          <td><div align="center"><?php echo $atot;?></div></td>
          <td><div align="center"><?php echo $sncom[1][0];?></div></td>
          <td><div align="center"><?php echo $sncom[4][0];?></div></td>
          <td><div align="center"><?php echo $sncom[7][0];?></div></td>
          <td><div align="center"><?php echo $sncom[10][0];?></div></td>
          <td><div align="center"><?php echo $ane;?></div></td>
          <td><div align="center"><?php echo $aeff;?></div></td>
          <td background="../status/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="26" background="../status/images/table_r2_c1.gif"></td>
          <td>NCs(E)</td>
          <td><div align="center"><?php echo $sncot[2][0];?></div></td>
          <td><div align="center"><?php echo $sncot[5][0];?></div></td>
          <td><div align="center"><?php echo $ntot;?></div></td>
          <td><div align="center"><?php echo $sncom[2][0];?></div></td>
          <td><div align="center"><?php echo $sncom[5][0];?></div></td>
          <td><div align="center"><?php echo $sncom[8][0];?></div></td>
          <td><div align="center"><?php echo $sncom[11][0];?></div></td>
          <td><div align="center"><?php echo $nne;?></div></td>
          <td><div align="center"><?php echo $neff;?></div></td>
          <td background="../status/images/table_r2_c3.gif."></td>
        </tr>
        <tr>
          <td height="29" background="../status/images/table_r2_c1.gif"></td>
          <td>TOTAL</td>
          <td><div align="center"><?php echo $sncot[0][0] + $sncot[1][0] + $sncot[2][0];?></div></td>
          <td><div align="center"><?php echo $sncot[3][0] + $sncot[4][0] + $sncot[5][0];?></div></td>
          <td><div align="center"><?php echo $stot + $atot + $ntot ;?></div></td>
          <td><div align="center"><?php echo $sncom[0][0] + $sncom[1][0] + $sncom[2][0];?></div></td>
          <td><div align="center"><?php echo $sncom[3][0] + $sncom[4][0] + $sncom[5][0];?></div></td>
          <td><div align="center"><?php echo $sncom[6][0] + $sncom[7][0] + $sncom[8][0];?></div></td>
          <td><div align="center"><?php echo $sncom[9][0] + $sncom[10][0] + $sncom[11][0];?></div></td>
          <td><div align="center"><?php echo $sne + $ane + $nne;?></div></td>
          <td><div align="center"><?php echo $seff + $aeff + $neff;?></div></td>
          <td background="../status/images/table_r2_c3.gif."></td>
        </tr>
        
        <tr>
          <td><img src="../status/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
          <td colspan="10" background="../status/images/table_r3_c2.gif"><img src="../status/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
          <td><img src="../status/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
        </tr>
      </table>    </th>
  </tr>
</table>

<?php
} 
dbclose();
?>
</body>