<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>View your status</title>
<link href="stylesheets/style.css" rel="stylesheet" type="text/css" />
</head>
<?php
session_start();
$username=$_SESSION['user_logged'];
if(empty($username)) 
{
	
$host = $_SERVER['HTTP_HOST'];
$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra = 'login.php';
header("Location: http://$host$uri/$extra");
exit();
}
include_once ("menutest.php");
?>
<body>
<table width="700" border="0" cellspacing="1">
  <tr>
    <th width="179" scope="col">&nbsp;</th>
    <th width="485" scope="col"><p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p></th>
    <th width="26" scope="col">&nbsp;</th>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><table width="336" border="0" cellspacing="1">
      <tr>
        <td width="332"><form id="form1" name="form1" method="post" action="/status/view.php">
            <table width="334" border="0" align="left" cellpadding="0" cellspacing="0">
              <tr>
                <td width="13" height="12"><img src="/status/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
                <td colspan="7" background="/status/images/table_r1_c2.gif"><img src="/status/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
                <td width="13"><img src="/status/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
              </tr>
              <tr>
                <td rowspan="6" background="/status/images/table_r2_c1.gif"><img src="/status/images/spacer.gif" alt="" name="table_r2_c1" width="1" height="1" border="0" id="table_r2_c1" /></td>
                <td width="180"><div align="right"><strong>Rank </strong></div></td>
                <td width="4" height="24">&nbsp;</td>
                <td width="106"><select name="txtrank">
                  <option>AC ,LAC,SEP &amp; L/NK</option>
                  <option>CPL &amp; NK</option>
                  <option>SGT &amp; HAV</option>
                  <option>JWO  N/SUB</option>
                  <option>WO , MWO &amp; SUB</option>
                  <option>FG OFFR</option>
                  <option>FLT LT</option>
                  <option>SQN LDR</option>
                  <option>WG CDR</option>
                </select>
                </td>
                <td width="4">&nbsp;</td>
                <td width="4">&nbsp;</td>
                <td width="4">&nbsp;</td>
                <td width="4">&nbsp;</td>
                <td rowspan="6" background="/status/images/table_r2_c3.gif."><img src="/status/images/spacer.gif" alt="" name="table_r2_c3" width="1" height="1" border="0" id="table_r2_c3" /></td>
              </tr>
              <tr></tr>
              <tr></tr>
              <tr></tr>
              <tr></tr>
              <tr>
                <td><input name="radiobutton" type="radio" value="status" />
                  <strong>Status</strong> 
                    <input name="radiobutton" type="radio" value="nonstatus" />
                    <strong>Non-Status</strong></td>
                <td>&nbsp;</td>
                <td><input name="Submit" type="submit" class="rollmenu" value="View" /></td>
              </tr>
              <tr>
                <td><img src="/status/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
                <td colspan="7" background="/status/images/table_r3_c2.gif"><img src="/status/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
                <td><img src="/status/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
              </tr>
            </table>
        </form></td>
      </tr>
    </table></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
</body>

</html>
