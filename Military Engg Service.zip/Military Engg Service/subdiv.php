<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
session_start();
$host = $_SERVER['HTTP_HOST'];
$uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra = 'index.php';
$username =$_SESSION['username'] ;
if(empty($_SESSION['user_password'] )) 
{
session_destroy();
header("Location: http://$host$uri/$extra");
exit();
}

include_once ("./dao/function.php");
dbconnect();
?>
<head>
    <title>On-line MES Complaint</title>
	<meta http-equiv="Content-Language" content="English" />
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
	<meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="expires" content="-1" />
<script language="JavaScript" type="text/JavaScript">
	javascript:window.history.forward(1);
</script>
    	<link href="mes.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="container">
   <div id="container-header"><div id="container-name"><span>On-line </span>MES Complaint </div></div>
   <div id="container-eyecatcher"><img src="images/business_eyecatcher.jpg" width="668" height="138" /></div>
<?php 

if($username == 'BR')
{
$remarks1 = array('PENDING','UNDER PROGRESS','DOOR LOCKED');
$subdiv1 = array('PLASTER WORK','CARPENTER WORK','WELDING WORK','PERIODICAL SERVICES','SANITARY/DRAIN/SEWAGE','INTERNAL WATER SUPPLY','MISCELLANEOUS');
$comtype = $username;
	foreach($remarks1 as $value)
	{
		$remarks = $value;
		foreach($subdiv1 as $value)
		{
		 $subdiv = $value;
		 $array = compact("comtype","subdiv","remarks");
		 $comp[]= fetch_row(complaint,$array);
		}
	}
 include_once("subdiv_br.php");
}

if ($username == 'EM')
{
 $remarks1 = array('PENDING','UNDER PROGRESS','DOOR LOCKED');
 $subdiv1 = array('ELECTRICAL WORK','ACs','EXTERNAL WATER SUPPLY','GYSER','MISCELLANEOUS');
 $comtype = $username;
	foreach($remarks1 as $value)
	{
		$remarks = $value;
		foreach($subdiv1 as $value)
		{
		 $subdiv = $value;
		 $array = compact("comtype","subdiv","remarks");
		 $comp[]= fetch_row(complaint,$array);
		}
	}
 include_once("subdiv_em.php");
}

if ($username == 'cdr')
{
$locresult=mysql_query("select * from location");

 	if(isset($_GET['stncdr']) && $_GET['stncdr'] == 'Submit')
	{
 		$mon = array('01'=>'JAN','02'=>'FEB','03'=>'MAR','04'=>'APR','05'=>'MAY','06'=>'JUN','07'=>'JUL','08'=>'AUG','09'=>'SEP','10'=>'OCT','11'=>'NOV','12'=>'DEC');
		foreach($mon as $key => $value)
		{
			if ($_GET['mnth'] == $value)
			{$m = "$key";}
		}
 	$y = $_GET['yr'];
	}
 $loc1 = array('RESIDENTIAL','TECHNICAL');
 $type1 = array('BR','EM');
 foreach($loc1 as $value)
 {
     $area = $value;
	 foreach($type1 as $value)
	 {
		$comtype = $value;
		$array = compact("area","comtype");
		$respen[]= fetch_row_pen(complaint,$array,$y,$m);
		$resclr[]= fetch_row_clr(complaint,$array,$y,$m);
		$resrem[]= fetch_row_rem(complaint,$array);
	 }
 }
 include_once("stncdr.php");
}

if($username == 'MC')
{
  if(isset($_GET['Summary']) && $_GET['Summary'] == 'Submit')
  {
  mysql_query("create temporary table if not exists summary SELECT complaint.comtype,complaint.remarks FROM
  complaint where comdt between str_to_date('$_GET[sumryfm]','%d-%m-%Y') and str_to_date('$_GET[sumryto]','%d-%m-%Y') order by remarks");
  $type1 = array('BR','EM');
  $remark = array('DONE','CONTRACTOR JOB','WRONG COMPLAINT','STORE N/A','PENDING','UNDER PROGRESS','DOOR LOCKED');
 		foreach($type1 as $value)
 		{
			$comtype = $value;
  			foreach($remark as $value)
    		{
      			$remarks = $value;
	  			$array = compact("comtype","remarks");
	  			$resrem[] = fetch_row(summary,$array);
    		}
 		}
   } 
  if(isset($_GET['Summary']) && $_GET['Summary'] == 'Preview')
  {header("Location: http://$host$uri/summary.php?fm=$_GET[sumryfm]&to=$_GET[sumryto]");}
 include_once("subdiv_mc.php");
}
?> 
	<div id="container-footer">
           <div id="footer">
               <div id="footer-copyright">Copyright &copy; 27wg, NET & IT SQN- all rights reserved.</div>
      </div>
	</div> <!-- END of container-footer -->

</div> <!-- END of container -->
</body>
</html>
