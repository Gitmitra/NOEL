<?php 
session_start();
include_once ("index.php");
include_once ("function.php");
dbconnect();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>27WG:: Movement In</title>

<script type="text/JavaScript" src="scripts/test.js"></script>
<link href="stylesheets/style.css" rel="stylesheet" type="text/css">
   
<style type="text/css">
 <!--
 #omovement {
	position:absolute;
	left:278px;
	top:179px;
	width:458px;
	height:217px;
	padding: 0px;
	margin: 0px;
}

#moleave {
	position:absolute;
	left:278px;
	top:179px;
	width:458px;
	height:217px;
	padding: 0px;
	margin: 0px;
}

#osrchserno {
	position:absolute;
	left:11px;
	top:172px;
	width:226px;
	height:85px;
	padding: 0px;
	margin: 0px;
}

#oupdtrec {
	position:absolute;
	left:279px;
	top:180px;
	width:552px;
	height:120px;
	z-index:2;
}

#poupdtrec {
	position:absolute;
	left:279px;
	top:180px;
	width:552px;
	height:120px;
	z-index:2;
}
 -->
</style>
</head>

<body >
  <iframe width=174 height=189 name="gToday:normal:agenda.js" id="gToday:normal:agenda.js" src="/drss/scripts/ipopeng.htm" scrolling="no" frameborder="0" style="visibility:visible; z-index:999; position:absolute; top:-500px; left:-500px;"></iframe>
<?php

include_once("osrchserno.php");
if(isset($_POST['action']) && $_POST['action'] == 'submitted')
{
		switch($_SESSION['unit']) {
			case "27WG":
				$table1 = "personal_info27";
	 	 	 	$table2 = "movement27";
				break;
			case "37SQN":
				$table1 = "personal_info37";
	 	 	 	$table2 = "movement37";
				break;
			case "108SQN":
				$table1 = "personal_info108";
	 	 	 	$table2 = "movement108";
				break;
			case "2201SQN":
				$table1 = "personal_info2201";
	 	 	 	$table2 = "movement2201";
				break;
			case "2224SQN":
				$table1 = "personal_info2224";
	 	 	 	$table2 = "movement2224";
				break;
			case "2254SQN":
				$table1 = "personal_info2254";
	 	 	 	$table2 = "movement2254";
				break;
			case "171SU":
				$table1 = "personal_info171";
	 	 	 	$table2 = "movement171";
				break;
			case "777SU":
				$table1 = "personal_info777";
	 	 	 	$table2 = "movement777";
				break;
			case "853SU":
				$table1 = "personal_info853";
	 	 	 	$table2 = "movement853";
				break;
			case "478MOF":
				$table1 = "personal_info478";
	 	 	 	$table2 = "movement478";
				break;
			case "308TRU":
				$table1 = "personal_info308";
	 	 	 	$table2 = "movement308";
				break;
			case "342TRU":
				$table1 = "personal_info342";
	 	 	 	$table2 = "movement342";
				break;
			case "607GRDFLT":
				$table1 = "personal_info607";
	 	 	 	$table2 = "movement607";
				break;
			}
		 
$query = "select * from ".$table1." where serno = $_POST[txtserno] and unit = '$_SESSION[unit]' and type in ('TD','POSTED_IN')";
$result = mysql_query($query) or die(mysql_error());
$row = mysql_fetch_array($result);	
$rows = mysql_num_rows($result);

$query1 = "select * from ".$table2." where movin is null and serno = $_POST[txtserno] and movcode = 'LEAVE' and torsdt < date_add(curdate(),INTERVAL 1 DAY)"; 
$result1 = mysql_query($query1) or die(mysql_error());
$rows1 = mysql_num_rows($result1);  
  
  if ($rows == 1)
  {
  	switch ($_POST['movcode']) 
	{
	case "DISCHARGE":
  	case "POSTED_OUT":
			if($row[type] == 'POSTED_IN' && $row[movcode] == NULL)
			{ include_once("poupdtrec.php"); }
			else
			{ message("err.png","Check the Service Number....!!"); }
			break;
	case "L_OUT":
			if ($_POST['movcode'] != $row[movcode])
			{
				if($row[status] == 'L_IN')
				{ include_once("oupdtrec.php"); }
				else
				{ message("warn.png","Personnel is L/OUT....!!"); }
			}
			break;
	case "CTD":
			if ($row[movcode] == 'ATTACHMENT' && $row[type] == 'TD')
			{ include_once("omovement.php"); }
			else
			{ message("err.png","Check the Service Number....!!"); }
			break;
	case "LEAVE":
			if ($row[movcode] == NULL || ($row[movcode] == 'ATTACHMENT' && $row[type] == 'TD')) 
			{ include_once("moleave.php"); }
			break;
	default:
			if (($row[movcode] == 'LEAVE' && $rows1 == 1) || $row[movcode] == NULL || ($row[movcode] == 'ATTACHMENT' && $row[type] == 'TD')) 		
			{ include_once("omovement.php"); }
			else
			{ message("err.png","Check the Service Number....!!"); }
    }
  }
  else 
  { message("err.png","$_POST[txtserno] is not in the strength....!!"); }
mysql_free_result($result);
mysql_free_result($result1);
}	 
dbclose();
?>
</body>
</html>

