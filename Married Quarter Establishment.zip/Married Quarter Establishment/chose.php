<?php 
include_once ("conn.php");
include_once ("menutest.php");
session_start();


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link href="stylesheets/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<table width="295" border="0" align="center" cellspacing="1">
  <tr>
    <td><p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p></td>
  </tr>
  <tr><td width="291">
 <?php if($_POST['radiobutton'] == 'offr') {?>
	<form id="form1" name="form1" method="post" action="../status/Regoffr.php">
<?php } else {?>
<form id="form1" name="form1" method="post" action="../status/Reg.php">
<?php }?>
      <table width="317" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="12"><img src="/status/images/table_r1_c1.gif" alt="" name="table_r1_c1" width="13" height="12" border="0" id="table_r1_c1" /></td>
          <td colspan="7" background="/status/images/table_r1_c2.gif"><img src="/status/images/spacer.gif" alt="" name="table_r1_c2" width="1" height="1" border="0" id="table_r1_c2" /></td>
          <td width="13"><img src="/status/images/table_r1_c3.gif" alt="" name="table_r1_c3" width="13" height="12" border="0" id="table_r1_c3" /></td>
        </tr>
        <tr>
          <td rowspan="6" background="/status/images/table_r2_c1.gif"><img src="/status/images/spacer.gif" alt="" name="table_r2_c1" width="1" height="1" border="0" id="table_r2_c1" /></td>
          <td width="77"><strong>PBOR </strong></td>
          <td width="58" height="24"><input name="radiobutton" type="radio" value="pbor" /></td>
          <td width="45"><strong>OFFR</strong></td>
          <td width="43"><input name="radiobutton" type="radio" value="offr" /></td>
          <td width="4">&nbsp;</td>
          <td width="55"><input name="submit" type="submit" class="rollmenu" value="Select" /></td>
          <td width="9">&nbsp;</td>
          <td rowspan="6" background="/status/images/table_r2_c3.gif."><img src="/status/images/spacer.gif" alt="" name="table_r2_c3" width="1" height="1" border="0" id="table_r2_c3" /></td>
        </tr>
        <tr></tr>
        <tr></tr>
        <tr></tr>
        <tr></tr>
        <tr>
          
        </tr>
        <tr>
          <td><img src="/status/images/table_r3_c1.gif" alt="" name="table_r3_c1" width="13" height="16" border="0" id="table_r3_c1" /></td>
          <td colspan="7" background="/status/images/table_r3_c2.gif"><img src="/status/images/spacer.gif" alt="" name="table_r3_c2" width="1" height="1" border="0" id="table_r3_c2" /></td>
          <td><img src="/status/images/table_r3_c3.gif" alt="" name="table_r3_c3" width="13" height="16" border="0" id="table_r3_c3" /></td>
        </tr>
      </table>
      </form></td>
  </tr>
</table>
</body>
</html>
